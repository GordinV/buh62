CREATE FUNCTION trigiu_vanemtasu3_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 



	v_userid record;



	lresult int;



	lcNotice varchar;



begin



	perform sp_register_oper(new.rekvid,new.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, new.rekvid));



	return null;



end;


$$;

ALTER FUNCTION trigiu_vanemtasu3_after() OWNER TO vlad;

