CREATE FUNCTION tsk(character varying, integer, integer, date) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
DECLARE tcKontogrupp alias for $1;

	tnTunnusid alias for $2;

	tnrekvid alias for $3;

	tdKpv alias for $4;

begin



	return -1 * tsd(tcKontogrupp, tnTunnusId, tnRekvId, tdKpv);

end;


$$;

ALTER FUNCTION tsk(VARCHAR, INTEGER, INTEGER, DATE) OWNER TO vlad;

