CREATE FUNCTION trigu_palk_kaart_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare lnCount int;



begin



	if  new.libId <> old.libId and new.lepingId <> old.libId then
/*

		-- ŠæŃ€Š¾Š²ŠµŃ€ŠŗŠ° Š½Š° Š½Š°Š»ŠøŃ‡ŠøŠµ Š´Š°Š½Š½Ń‹Ń…

		select count (*) into lnCount from palk_oper where lepingid = old.lepingId and libid = old.libId;

		if ifnull(lnCount,0) > 0 then 		

			raise notice ' Ei saa kustuta, andmed kasutatakse';

		end if;


		return null;
*/

		return new;

	end if;




	return new;

end;

$$;

ALTER FUNCTION trigu_palk_kaart_before() OWNER TO vlad;

