CREATE FUNCTION tmp_restore_pv_oper_lausend() RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare 



	v_dokument record;

	lnCount int4;



BEGIN

lnCount := 0;



--korderid

	for v_dokument in 

		select id, journalid, liik from pv_oper 

			where journalid > 0 

			and liik in (1,2,3)

			and id in (select dokid from raamat where left(cast(aeg as varchar),7) = '2006-05' and dokument = 'pv_oper')

			and journalid not in (select id from curJournal)

	loop

		-- check for lausend

		raise notice 'v_dokumen.id %',v_dokument.id;

		if (select count(*) from journalId where journalId = v_dokument.journalId) = 0 then

			-- puudub lausendi number

			raise notice 'puudub number';

			if (select count(*) from journal1 where parentId = v_dokument.journalId) = 0 then

				-- puudub dok.details

				raise notice 'puudub detail';

				if v_dokument.liik = 1 then

					perform gen_lausend_paigutus(v_dokument.id);

				end if;

				if v_dokument.liik = 2 then

					perform gen_lausend_kulum(v_dokument.id);

				end if;

				if v_dokument.liik = 3 then

					perform gen_lausend_parandus(v_dokument.id);

				end if;

				if v_dokument.liik = 4 then

					perform gen_lausend_mahakandmine(v_dokument.id);

				end if;



				lnCount := lnCount + 1;

			end if;



		end if;



	end loop;



	return lnCount;



end;


$$;

ALTER FUNCTION tmp_restore_pv_oper_lausend() OWNER TO vlad;

