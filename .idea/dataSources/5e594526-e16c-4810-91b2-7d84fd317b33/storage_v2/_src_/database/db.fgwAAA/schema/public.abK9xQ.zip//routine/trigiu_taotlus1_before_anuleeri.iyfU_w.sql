CREATE FUNCTION trigiu_taotlus1_before_anuleeri() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	lresult int;

	lcNotice varchar;

begin


	if old.eelarveid > 0  then
	
		raise exception 'Taotlus juba aktsepteeritud';
--		raise notice 'Taotlus juba aktsepteeritud';
		return null;

--		delete from eelarve where id = new.eelarveid;

--		new.eelarveid = 0;


	end if;



--	perform sp_register_oper(0,new.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, 0));

	return new;

end;

$$;

ALTER FUNCTION trigiu_taotlus1_before_anuleeri() OWNER TO vlad;

