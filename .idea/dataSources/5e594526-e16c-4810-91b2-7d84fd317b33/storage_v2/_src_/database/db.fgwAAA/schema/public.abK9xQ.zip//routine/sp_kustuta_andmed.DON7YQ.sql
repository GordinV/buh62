CREATE FUNCTION sp_kustuta_andmed(integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare 

	tnRekvId alias for $1;

begin

	raise notice ' tnrekvid %',tnrekvid;

--	update pg_trigger set tgenabled = false;



	-- kontrollime taabelid



		raise notice ' kustuta arved .. ';

		ALTER TABLE arv DISABLE TRIGGER ALL;

		ALTER TABLE arv1 DISABLE TRIGGER ALL;

		ALTER TABLE arvtasu DISABLE TRIGGER ALL;



		delete from arv1 where parentid in (select id from arv where kpv < date(2009,01,01) and rekvid = tnrekvId);

		delete from arv where kpv < date(2009,01,01) and rekvid = tnrekvId;

		delete from arvtasu where rekvid = tnrekvId;



		ALTER TABLE arv enABLE TRIGGER ALL;

		ALTER TABLE arv1 enABLE TRIGGER ALL;

		ALTER TABLE arvtasu enABLE TRIGGER ALL;



		raise notice ' kustuta eelarve .. ';

		ALTER TABLE eelarve DISABLE TRIGGER ALL;



		delete from eelarve where rekvid = tnrekvId;



		ALTER TABLE eelarve enABLE TRIGGER ALL;



		raise notice ' kustuta algsaldo .. ';

		ALTER TABLE kontoinf DISABLE TRIGGER ALL;

		ALTER TABLE subkonto DISABLE TRIGGER ALL;

		ALTER TABLE eelarveinf DISABLE TRIGGER ALL;



		delete from kontoinf where rekvid = tnrekvId;

		delete from subkonto where rekvid = tnrekvId;

		delete from eelarveinf where rekvid = tnrekvId;



		ALTER TABLE kontoinf enABLE TRIGGER ALL;

		ALTER TABLE subkonto enABLE TRIGGER ALL;

		ALTER TABLE eelarveinf enABLE TRIGGER ALL;





		raise notice ' kustuta mk .. ';

		ALTER TABLE mk DISABLE TRIGGER ALL;

		ALTER TABLE mk1 DISABLE TRIGGER ALL;

		delete from mk1 where parentid in (select id from mk where kpv < date(2009,01,01) and rekvid = tnrekvId);

		delete from mk where kpv < date(2009,01,01) and rekvid = tnrekvId;

		ALTER TABLE mk ENABLE TRIGGER ALL;

		ALTER TABLE mk1 ENABLE TRIGGER ALL;



		raise notice ' kustuta korder1 .. ';

		ALTER TABLE korder1 DISABLE TRIGGER ALL;

		ALTER TABLE korder2 DISABLE TRIGGER ALL;

		delete from korder2 where parentid in (select id from korder1 where kpv < date(2009,01,01)and rekvid = tnrekvId);

		delete from korder1 where kpv < date(2009,01,01)and rekvid = tnrekvId;

		ALTER TABLE korder1 ENABLE TRIGGER ALL;

		ALTER TABLE korder2 ENABLE TRIGGER ALL;



		raise notice ' kustuta palk_oper .. ';

		ALTER TABLE palk_oper DISABLE TRIGGER ALL;

		ALTER TABLE palk_jaak DISABLE TRIGGER ALL;

		ALTER TABLE palk_kaart DISABLE TRIGGER ALL;

		ALTER TABLE tooleping DISABLE TRIGGER ALL;

		ALTER TABLE palk_taabel1 DISABLE TRIGGER ALL;



		delete from palk_oper where kpv < date(2009,01,01)and rekvid = tnrekvId;

		delete from palk_jaak where lepingid in (select id from tooleping where rekvid  = tnrekvId);

		delete from palk_kaart where lepingid in (select id from tooleping where rekvid  = tnrekvId);

		delete from palk_taabel1 where toolepingid in (select id from tooleping where rekvid  = tnrekvId);

		delete from tooleping where rekvid  = tnrekvId;	



		ALTER TABLE palk_oper ENABLE TRIGGER ALL;

		ALTER TABLE palk_jaak enABLE TRIGGER ALL;

		ALTER TABLE palk_kaart enABLE TRIGGER ALL;

		ALTER TABLE tooleping enABLE TRIGGER ALL;

		ALTER TABLE palk_taabel1 enABLE TRIGGER ALL;



		raise notice ' kustuta avansiaruianned .. ';

		ALTER TABLE avans1 DISABLE TRIGGER ALL;

		delete from avans1 where kpv < date(2009,01,01) and rekvid = tnrekvId;

		ALTER TABLE avans1 ENABLE TRIGGER ALL;





		raise notice ' vaba pv_oper .. ';

		ALTER TABLE pv_oper DISABLE TRIGGER ALL;

		ALTER TABLE pv_kaart DISABLE TRIGGER ALL;

		ALTER TABLE library DISABLE TRIGGER ALL;

		

		delete from pv_oper where parentid in (select id from library where rekvid = tnrekvId and library = 'POHIVARA');

		delete from pv_kaart where parentid in (select id from library where rekvid = tnrekvId and library = 'POHIVARA');

		delete from library where rekvid = tnrekvId and library = 'POHIVARA';



		ALTER TABLE pv_oper ENABLE TRIGGER ALL;

		ALTER TABLE pv_kaart enABLE TRIGGER ALL;

		ALTER TABLE library enABLE TRIGGER ALL;



		raise notice ' vaba vanemtasu3 .. ';

		ALTER TABLE vanemtasu3 DISABLE TRIGGER ALL;

		ALTER TABLE vanemtasu4 DISABLE TRIGGER ALL;



		delete from vanemtasu4 where parentid in (select id from vanemtasu3 where kpv < date(2009,1,1) and rekvid = tnrekvId);

		delete from vanemtasu3 where kpv < date(2009,1,1) and rekvid = tnrekvId;



		ALTER TABLE vanemtasu3 ENABLE TRIGGER ALL;

		ALTER TABLE vanemtasu4 ENABLE TRIGGER ALL;



		raise notice ' kustuta journal .. ';

		ALTER TABLE journal DISABLE TRIGGER ALL;

		ALTER TABLE journal1 DISABLE TRIGGER ALL;

		ALTER TABLE journalid DISABLE TRIGGER ALL;



		delete from journal1 where parentid in (select id from journal where kpv < date(2009,1,1) and rekvid = tnrekvId );



		delete from journalid where journalid in (select id from journal where kpv < date(2009,1,1) and rekvid = tnrekvId  );



		delete from journal where kpv < date(2009,1,1) and rekvid = tnrekvId;



--		raise notice ' kustuta journal1 .. ';



--		raise notice ' kustuta journalid .. ';



		ALTER TABLE journal ENABLE TRIGGER ALL;

		ALTER TABLE journal1 ENABLE TRIGGER ALL;

		ALTER TABLE journalid ENABLE TRIGGER ALL;





--	update pg_trigger set tgenabled = true;





	return 1;

end;

$$;

ALTER FUNCTION sp_kustuta_andmed(INTEGER) OWNER TO vlad;

