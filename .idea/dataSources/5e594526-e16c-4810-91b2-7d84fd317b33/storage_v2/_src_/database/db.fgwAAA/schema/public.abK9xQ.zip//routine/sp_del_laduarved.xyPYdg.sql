CREATE FUNCTION sp_del_laduarved(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 


	tnId alias for $1;


begin


	Return sp_del_arved(tnid,1);


end;


$$;

ALTER FUNCTION sp_del_laduarved(INTEGER, INTEGER) OWNER TO vlad;

