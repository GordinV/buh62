CREATE FUNCTION trigiu_palk_oper_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	v_userid record;

	lresult int;

	lcNotice varchar;

begin

	-- muudetud 18/02/2005

	if year(new.kpv) > 2005 then

		perform sp_register_oper(new.rekvid,new.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, new.rekvid));

	end if;

	return null;

end;

$$;

ALTER FUNCTION trigiu_palk_oper_after() OWNER TO vlad;

