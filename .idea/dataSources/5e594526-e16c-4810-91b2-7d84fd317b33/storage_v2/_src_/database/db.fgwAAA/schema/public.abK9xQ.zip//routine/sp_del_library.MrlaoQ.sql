CREATE FUNCTION sp_del_library(integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 


	tnId alias for $1;


begin

	Delete From library Where Id = tnid;


	if found then 


		Return 1;


	else


		return 0;


	end if;


end;

$$;

ALTER FUNCTION sp_del_library(INTEGER) OWNER TO vlad;

