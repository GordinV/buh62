CREATE FUNCTION getdate() RETURNS date
    LANGUAGE plpgsql
AS
$$
begin

         return  current_date;

end;

$$;

ALTER FUNCTION getdate() OWNER TO vlad;

