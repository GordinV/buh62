CREATE FUNCTION fncteenusehind(integer, integer) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
DECLARE tnObjektId alias for $1;
	tnNomId alias for $2;


	lnHind numeric (14,4);

begin	
	lnHind = 0;

	select hind into lnHind from leping2 inner join leping1 on leping1.id = leping2.parentid where objektid = tnObjektId and leping2.nomid = tnNomId order by leping1.id desc limit 1;

	lnHind = ifnull(lnHind,0);
	

	return lnHind;

end;

$$;

ALTER FUNCTION fncteenusehind(INTEGER, INTEGER) OWNER TO vlad;

