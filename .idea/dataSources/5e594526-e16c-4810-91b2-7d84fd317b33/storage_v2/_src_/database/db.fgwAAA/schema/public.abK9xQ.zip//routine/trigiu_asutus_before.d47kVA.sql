CREATE FUNCTION trigiu_asutus_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	lresult int;

	lcNotice varchar;

begin

/*	
if new.id = 315 then

		-- kultuurikeskus

		raise exception 'Ei saa muudata, Narva Kultuuriosakond keelatud';

		return null;

	end if;



	select count(*) into lresult from userid where kasutaja = CURRENT_USER::varchar and peakasutaja_ = 1;

	if (new.tp <> '800599' or new.tp <> '800699' or new.tp <> '800399') and ifnull(lresult,0) = 0 then

		raise exception 'Ei saa lisada/muudata kui tp kood <> 800599, 800699,800399 Narva Rahandusamet keelatud';

		return null;

	end if;

*/	

	return new;

end;

$$;

ALTER FUNCTION trigiu_asutus_before() OWNER TO vlad;

