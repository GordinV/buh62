CREATE FUNCTION sp_parandada_palkastruktuur(integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare

	tnid alias for $1;

	lcKood varchar(20);

	v_klassiflib record;

	v_palk_lib record;

	lnLibId int;



begin







select kood into lcKood from library where id = tnId;



-- kontrolin kas on sama kood juba

if (select count(id) from palk_lib where parentid = tnId) = 0 then

	-- puudub, otsime

	raise notice 'puudub, lisame';

	select id into lnLibId from library where rekvid = 62 and library = 'PALK' and kood = lcKood order by id desc limit 1;

	if ifnull(lnLibId,0) > 0 then		

		raise notice 'lnLibId %',lnLibId;

		select * into v_palk_lib from palk_lib where parentid = lnLibId order by id limit 1;

		if ifnull(v_palk_lib.id,0) > 0 then

		raise notice 'v_palk_lib.id %',v_palk_lib.id;



		insert into palk_lib (parentid, liik, tund, maks, palgafond , asutusest , lausendid , algoritm, muud , round,

			sots, konto,  elatis, tululiik ) values (

			tnId, v_palk_lib.liik, v_palk_lib.tund, v_palk_lib.maks, v_palk_lib.palgafond , v_palk_lib.asutusest , 

			v_palk_lib.lausendid , v_palk_lib.algoritm, v_palk_lib.muud , v_palk_lib.round,

			v_palk_lib.sots, v_palk_lib.konto,  v_palk_lib.elatis, v_palk_lib.tululiik);

		else

			raise notice 'palk_lib ei leidnud';

		end if;

	end if;

end if;





if (select count(*) from klassiflib where libid = tnid) = 0 then

	select * into v_klassiflib from klassiflib where libId in (select id from library where library = 'PALK' and kood = lckood) order by konto desc limit 1;

	if ifnull(v_klassiflib.id,0) > 0 then 

		insert into klassiflib (libid,tyyp, tunnusid, kood1, kood2, kood3, kood4, kood5, konto, proj) values 

		(tnid,ifnull(v_klassiflib.tyyp,0), v_klassiflib.tunnusid, v_klassiflib.kood1, v_klassiflib.kood2, v_klassiflib.kood3, v_klassiflib.kood4, v_klassiflib.kood5, v_klassiflib.konto, v_klassiflib.proj);

	end if;	

end if;



         return  tnId;

end;

$$;

ALTER FUNCTION sp_parandada_palkastruktuur(INTEGER) OWNER TO vlad;

