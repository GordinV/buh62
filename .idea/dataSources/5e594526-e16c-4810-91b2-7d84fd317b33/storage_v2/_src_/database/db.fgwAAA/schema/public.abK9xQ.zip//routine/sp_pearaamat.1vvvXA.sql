CREATE FUNCTION sp_pearaamat(character varying, integer, date, date) RETURNS character varying
    LANGUAGE plpgsql
AS
$$
DECLARE tcKonto alias for $1;

	tnrekvid alias for $2;

	tdKpv1 alias for $3;

	tdKpv2 alias for $4;

	lcReturn varchar;

	lcString varchar;

	lcPnimi varchar;

	lnAlg numeric(14,2);

	lnLopp numeric (14,2);

begin

/*

	lcReturn := ' tmp_'+to_char(now(), 'YYYYMMDDMISS');

	raise notice 'lcReturn %',lcReturn;



	lcString := ' create temp table  '+lcreturn +' (konto varchar(20), korkonto varchar(20), algsaldo numeric(14,2), deebet numeric(14,2),  kreedit numeric(14,2), dbkokku numeric(14,2), krkokku numeric(14,2)) ';

	raise notice 'lcString %',lcString;



		

	execute lcstring;

*/



	lnAlg := sd(tcKonto, tnrekvid, tdKpv1);



	create temp table tmp_pearaamat as

	SELECT konto,  korkonto, sum(deebet) as deebet, sum (kreedit) as kreedit, lnAlg as algsaldo from 

		(SELECT deebet As konto, lisa_d As tp, kood1 As tegev, kood2 As allikas, kood3 As rahavoo, 	

		Summa As deebet, 0 As kreedit, rekvid, tunnus, kpv, kreedit as korkonto  

		FROM curJournal 

		UNION All 

		SELECT kreedit As konto, lisa_d As tp, kood1 As tegev, kood2 As allikas, kood3 As rahavoo, 0  As deebet,  

		Summa As kreedit, rekvid, tunnus, kpv, deebet as korkonto  FROM curJournal ) qrySaldoaruanne  

		WHERE rekvid = tnrekvId AND kpv >= tdKpv1 and kpv <= tdKpv2 and  konto = tcKonto 

		group BY konto, korkonto ;





/*

	

	select sum(deebet) - sum(kreedit) into lnLopp from tmp_pearaamat;

	update tmp_pearaamat set aldsaldo = lnAlg,

	lsaldo = lnAlg+lnLopp;

*/
	return LCRETURN;

end;


$$;

ALTER FUNCTION sp_pearaamat(VARCHAR, INTEGER, DATE, DATE) OWNER TO vlad;

