CREATE FUNCTION trigu_pv_kaart_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:=

	case when old.parentid <> new.parentid then 

		'parentid:' + old.parentid::text + '

'  else ''

	end +

	

	case when old.vastisikid <> new.vastisikid then 

		'vastisikid:' + old.vastisikid::text + '

'  else ''

	end +

	

	case when old.soetmaks <> new.soetmaks then 

		'soetmaks:' + old.soetmaks::text + '

'  else ''

	end +

	

	case when old.soetkpv <> new.soetkpv then 

		'soetkpv:' + dtoc(old.soetkpv) + '

'  else ''

	end +

	

	case when old.kulum <> new.kulum then 

		'kulum:' + old.kulum::text + '

'  else ''

	end +

	

	case when old.algkulum <> new.algkulum then 

		'algkulum:' + old.algkulum::text + '

'  else ''

	end +

	

	case when old.gruppid <> new.gruppid then 

		'gruppid:' + old.gruppid::text + '

'  else ''

	end +

	

	case when old.konto <> new.konto then 

		'konto:' + old.konto::text + '

'  else ''

	end +

	

	case when old.tunnus <> new.tunnus then 

		'tunnus:' + old.tunnus::text + '

'  else ''

	end +

	

	case when old.mahakantud <> new.mahakantud or (IfNull(old.mahakantud,date(1900,01,01)) <> IfNull(new.mahakantud,date(1900,01,01))) then 

		'mahakantud:' + case when ifNull(old.mahakantud,date(1900,01,01)) = date(1900,01,01) then space(1) + '

'  else dtoc(old.mahakantud) +  '

'  end else ''

	end +

	

	case when old.otsus <> new.otsus or (IfNull(old.otsus,space(1)) <> IfNull(new.otsus,space(1))) then 

		'otsus:' + case when ifNull(old.otsus,space(1)) = space(1) then space(1) + '

'  else old.otsus::text + '

'  end else ''

	end +

	

	case when old.muud <> new.muud or (IfNull(old.muud,space(1)) <> IfNull(new.muud,space(1))) then 

		'muud:' + case when ifNull(old.muud,space(1)) = space(1) then space(1) + '

'  else old.muud::text + '

'  end else ''

	end;

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (0,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,new.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigu_pv_kaart_after_r() OWNER TO vlad;

