CREATE FUNCTION trigi_vanemtasu4_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 



	v_userid record;



	lresult int;



	lcNotice varchar;

	ldKpv date;



	lcNumber varchar;



	v_vanemtasu3 record;



begin



	select * into v_vanemtasu3 from vanemtasu3 where id = new.parentId;





	--  otsime laps selles dokumendis







	select number into lcNumber from vanemtasu4 inner join vanemtasu3 on vanemtasu3.id = vanemtasu4.parentid 



		where  vanemtasu3.rekvid = v_vanemtasu3.rekvid and vanemtasu4.isikId = new.isikId order by val(ltrim(rtrim(number))) desc limit 1; 







	lcNumber := ifnull(lcNumber,'0');





	if lcNumber = '0' then



		-- laps puudub, teeme uus arve



		select number into lcNumber from vanemtasu4 inner join vanemtasu3 on vanemtasu3.id = vanemtasu4.parentid 



			where  vanemtasu3.rekvid = v_vanemtasu3.rekvid order by val(ltrim(rtrim(number))) desc limit 1; 



		lcNumber := ifnull(ltrim(rtrim(lcNumber)),'0');



		lcNumber := str(val(lcNumber)+1);		



	end if;













	new.number := lcNumber;





	if new.isikId > 0 then



		return new;



	else

		return null;

	end if;



end;


$$;

ALTER FUNCTION trigi_vanemtasu4_before() OWNER TO vlad;

