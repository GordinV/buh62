CREATE FUNCTION sp_uut_enumerators(integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare 

	tnRekvId ALIAS FOR $1;

	lnKinni int;

	lcstatus bpchar;

	lnNumber int;

	lcAsutus bpchar;

	lcNimi char(40);

	lcStr char(240);

	lnMaxNumber int;

	

begin

	-- kas on seq

		lcNimi := ' journalid_number_2016_' + ltrim(rtrim(str(tnrekvid)));



--		if (select count(*) from pg_statio_user_sequences where ltrim(rtrim(relname)) = ltrim(rtrim(lcNimi))::varchar) = 0 then

	--	max number

			select max(number) into lnmaxNumber from journalid where rekvid = tnrekvid and aasta = 2016;

	--	lisame sequence



				raise notice 'lisame seq';

				lcStr := 'CREATE SEQUENCE ' +space(1) + lcNimi + ' INCREMENT 1 START ' || space(1)::char(1) + left(str(ifnull(lnMaxNumber,0) + 1),9);

				raise notice 'lcStr %',lcStr;

				execute lcStr;

				lcStr := 'ALTER TABLE ' + lcNimi + ' OWNER TO vlad';

				execute lcStr;

				raise notice 'lcStr %',lcStr;

				lcStr := 'ALTER TABLE ' + lcNimi + ' OWNER TO vlad';

				execute  lcStr;







				lcStr := 'GRANT SELECT, UPDATE, INSERT ON TABLE ' + lcNimi + ' TO GROUP dbpeakasutaja';

				execute lcStr;

				lcStr := 'GRANT SELECT, UPDATE, INSERT ON TABLE ' + lcNimi + ' TO GROUP dbkasutaja';

				execute lcStr;

--		end if;





			return 1;

end;

$$;

ALTER FUNCTION sp_uut_enumerators(INTEGER) OWNER TO vlad;

