CREATE FUNCTION trigd_avans1_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:='rekvid:' + old.rekvid::TEXT + '

' +

	'userid:' + old.userid::TEXT + '

' +

	'asutusid:' + old.asutusid::TEXT + '

' +

	'kpv:'+ old.kpv::TEXT + '

' +

	'number:' + old.number + '

' +

	'selg:' + old.selg + '

' +

	'journalid:' + old.journalid::TEXT + '

' +

	'dokpropid:' + old.dokpropid::TEXT + '

' +

	'muud:' + case when ifnull(old.muud,space(1))<>space(1) then 

		old.muud::TEXT + '

' else ' ' end;

	

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (old.rekvid,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,old.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigd_avans1_after_r() OWNER TO vlad;

