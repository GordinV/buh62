CREATE FUNCTION tmp_restore_korder_lausend() RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare 



	v_dokument record;

	lnCount int4;



BEGIN

lnCount := 0;



--korderid

	for v_dokument in 

		select id, journalid from korder1 

			where journalid > 0 

			and id in (select dokid from raamat where left(cast(aeg as varchar),7) = '2006-05' and dokument = 'korder1')

			and journalid not in (select id from curJournal)

	loop

		-- check for lausend

		raise notice 'v_dokumen.id %',v_dokument.id;

		if (select count(*) from journalId where journalId = v_dokument.journalId) = 0 then

			-- puudub lausendi number

			raise notice 'puudub number';

			if (select count(*) from journal1 where parentId = v_dokument.journalId) = 0 then

				-- puudub dok.details

				raise notice 'puudub detail';

				perform gen_lausend_korder(v_dokument.id);

				lnCount := lnCount + 1;

			end if;



		end if;



	end loop;



	return lnCount;



end;


$$;

ALTER FUNCTION tmp_restore_korder_lausend() OWNER TO vlad;

