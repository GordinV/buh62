CREATE FUNCTION sp_salvesta_pv_oper(integer, integer, integer, integer, integer, date, numeric, text, character varying, character varying, character varying, character varying, character varying, character varying, character varying, integer, character varying, character varying) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare

	tnid alias for $1;

	tnparentid alias for $2;

	tnnomid alias for $3;

	tndoklausid alias for $4;

	tnliik alias for $5;

	tdkpv alias for $6;

	tnsumma alias for $7;

	ttmuud alias for $8;

	tckood1 alias for $9;

	tckood2 alias for $10;

	tckood3 alias for $11;

	tckood4 alias for $12;

	tckood5 alias for $13;

	tckonto alias for $14;

	tctp alias for $15;

	tnasutusid alias for $16;

	tctunnus alias for $17;

	tcProj alias for $18;

	lnpv_operId int;

	lnId int; 

	lnSumma numeric(12,2);

	v_pv_kaart record;

	lrCurRec record;

	lnPvElu numeric(6,2);

	lnKulum numeric(12,2);



	lnParandatudSumma numeric (12,4);

	lnUmberhindatudSumma numeric (12,4);

	lcString varchar;



	ldKpv date;





begin



if tnId = 0 then

	-- uus kiri

	insert into pv_oper (parentid,nomid,doklausid,liik,kpv,summa,muud,kood1,kood2,kood3,kood4,kood5,konto,tp,asutusid,tunnus, proj) 

		values (tnparentid,tnnomid,tndoklausid,tnliik,tdkpv,tnsumma,ttmuud,tckood1,tckood2,tckood3,tckood4,tckood5,tckonto,tctp,tnasutusid,tctunnus, tcProj);



	lnpv_operId:= cast(CURRVAL('public.pv_oper_id_seq') as int4);



else

	-- muuda 

	select * into lrCurRec from pv_oper where id = tnId;

	if lrCurRec.parentid <> tnparentid or lrCurRec.nomid <> tnnomid or lrCurRec.doklausid <> tndoklausid or lrCurRec.liik <> tnliik or lrCurRec.kpv <> tdkpv or lrCurRec.summa <> tnsumma or ifnull(lrCurRec.muud,space(1)) <> ifnull(ttmuud,space(1)) or lrCurRec.kood1 <> tckood1 or lrCurRec.kood2 <> tckood2 or lrCurRec.kood3 <> tckood3 or lrCurRec.kood4 <> tckood4 or lrCurRec.kood5 <> tckood5 or lrCurRec.konto <> tckonto or lrCurRec.tp <> tctp or lrCurRec.asutusid <> tnasutusid or lrCurRec.tunnus <> tctunnus then 







	update pv_oper set 

		parentid = tnparentid,

		nomid = tnnomid,

		doklausid = tndoklausid,

		liik = tnliik,

		kpv = tdkpv,

		summa = tnsumma,

		muud = ttmuud,

		kood1 = tckood1,

		kood2 = tckood2,

		kood3 = tckood3,

		kood4 = tckood4,

		kood5 = tckood5,

		konto = tckonto,

		tp = tctp,

		asutusid = tnasutusid,

		proj = tcProj,

		tunnus = tctunnus

	where id = tnId;

	end if;



	lnpv_operId := tnId;

end if;





	select soetmaks, parhind, kulum, soetkpv into v_pv_kaart from pv_kaart where parentId = tnparentid;



	lnKulum := v_pv_kaart.kulum;

	ldKpv := v_pv_kaart.soetkpv;



	-- PARANDAME PARANDATUD SUMMA.



--	lnSumma = get_pv_summa(tnparentid);



	if tnLiik = 5 then

		ldKpv := tdKpv;

		lnUmberhindatudSumma := tnSumma;



		-- parandame pv kulum

		raise notice 'v_pv_kaart.kulum %',v_pv_kaart.kulum;

		if v_pv_kaart.kulum > 0 then

			lnPvElu := (100 / v_pv_kaart.kulum);

		else

			lnPvElu := 10;

		end if;

		raise notice 'lnPvElu %',lnPvElu;

		lnPvElu := lnPvElu - (year(tdkpv) - year(v_pv_kaart.soetkpv));

		if lnPvElu > 0 then

			lnKulum := 100 / lnPvElu;

		else

			lnKulum := 20;

		end if;

		raise notice 'lnPvElu %',lnPvElu;

		raise notice 'lnKulum %',lnKulum;



		lcString = 'update pv_kaart set kulum = ' + lnKulum::varchar; 



	else

		select sum(summa) into lnUmberhindatudSumma from pv_oper

			where parentId = tnparentid and liik = 5;



		lnUmberhindatudSumma := ifnull(lnUmberhindatudSumma,0);

		if lnUmberhindatudSumma > 0 then

			select kpv into ldKpv from pv_oper where liik = 5 and parentId = tnParentId order by kpv desc limit 1;

		else

			lnUmberhindatudSumma := v_pv_kaart.soetmaks;

		end if;

	end if;



	select sum(summa) into lnParandatudSumma from pv_oper

			where parentId = tnparentid and liik = 3 and kpv > ldKpv;



	lnParandatudSumma := ifnull(lnParandatudSumma,0) + lnUmberhindatudSumma;





		raise notice 'lnParandatudSumma %',lnParandatudSumma;



	if v_pv_kaart.parhind <> lnParandatudSumma then



		if lcString = '' then 

			lcString = 'update pv_kaart set ';

		else

			lcString = lcString + ', parhind = ' + lnParandatudSumma::varchar; 

		end if;

		raise notice 'lcString %',lcString;



	end if;



	if len(lcString) > 0 then

		lcString = lcString + 	' where parentId = ' + str(tnparentid);

		execute lcString;

	end if;

		raise notice 'lcString %',lcString;



         return  lnpv_operId;

end;
$$;

ALTER FUNCTION sp_salvesta_pv_oper(INTEGER, INTEGER, INTEGER, INTEGER, INTEGER, DATE, NUMERIC, TEXT, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, INTEGER, VARCHAR, VARCHAR) OWNER TO vlad;

