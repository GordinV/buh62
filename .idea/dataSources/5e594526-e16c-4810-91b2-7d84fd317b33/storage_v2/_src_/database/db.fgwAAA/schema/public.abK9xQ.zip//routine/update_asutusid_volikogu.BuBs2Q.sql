CREATE FUNCTION update_asutusid_volikogu() RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare 

	lnReturn int;

	v_journal record;

	

begin

	for v_journal in

		select journal.id, tooleping.parentid as asutusid

		from palk_oper inner join journal on palk_oper.journalid = journal.id

		inner join tooleping on palk_oper.lepingid = tooleping.id

		where journal.rekvid = 10

		AND journal.asutusid = 3799

	loop

		update journal set asutusId = v_journal.asutusId where id = v_journal.id and rekvid = 10;

		raise notice 'Journal.id %',v_journal.id;

	end loop;

	lnreturn := 1;



         return  lnreturn;

end;

$$;

ALTER FUNCTION update_asutusid_volikogu() OWNER TO vlad;

