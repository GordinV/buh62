CREATE FUNCTION space(integer) RETURNS character
    LANGUAGE plpgsql
AS
$$
begin
         return  lpad(chr(32),$1);
end;
$$;

ALTER FUNCTION space(INTEGER) OWNER TO vlad;

