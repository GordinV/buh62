CREATE FUNCTION trigi_vorder2_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin

	UPDATE DBASE SET LASTNUM = NEW.ID WHERE id = 149;	 

	return NULL;

end;

$$;

ALTER FUNCTION trigi_vorder2_after() OWNER TO vlad;

