CREATE FUNCTION trigu_library_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:=

	case when old.rekvid <> new.rekvid then 

		'rekvid:' + old.rekvid::text + '

'  else ''

	end +

	

	case when old.kood <> new.kood then 

		'kood:' + old.kood::text + '

'  else ''

	end +

	

	case when old.nimetus <> new.nimetus then 

		'nimetus:' + old.nimetus::text + '

'  else ''

	end +

	

	case when old.library <> new.library then 

		'library:' + old.library::text + '

'  else ''

	end +

	

	case when old.muud <> new.muud or (IfNull(old.muud,space(1)) <> IfNull(new.muud,space(1))) then 

		'muud:' + case when ifNull(old.muud,space(1)) = space(1) then space(1) + '

'  else old.muud::text + '

'  end else ''

	end +

	

	case when old.tun1 <> new.tun1 then 

		'tun1:' + old.tun1::text + '

'  else ''

	end +

	

	case when old.tun2 <> new.tun2 then 

		'tun2:' + old.tun2::text + '

'  else ''

	end +

	

	case when old.tun3 <> new.tun3 then 

		'tun3:' + old.tun3::text + '

'  else ''

	end +

	

	case when old.tun4 <> new.tun4 then 

		'tun4:' + old.tun4::text + '

'  else ''

	end +

	

	case when old.tun5 <> new.tun5 then 

		'tun5:' + old.tun5::text + '

'  else ''

	end;

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	lnUsrId = ifnull(lnUsrid,0);



	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (new.rekvid,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,new.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigu_library_after_r() OWNER TO vlad;

