CREATE FUNCTION trigi_doklausheader_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin

	UPDATE DBASE SET LASTNUM = NEW.ID WHERE id = 92;	 

	return NULL;

end;

$$;

ALTER FUNCTION trigi_doklausheader_after() OWNER TO vlad;

