CREATE FUNCTION sp_salvesta_toiming(integer, integer, integer, date, character varying, character varying, date, numeric, integer, character varying, text, integer, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare

	tnid alias for $1;

	tnParentid alias for $2;

	tnLubaid alias for $3;

	tdKpv alias for $4;

	tcAlus alias for $5;

	tcEttekirjutus alias for $6;

	tdTahtaeg alias for $7;

	tnSumma alias for $8;

	tnStaatus alias for $9;

	tcTyyp alias for $10;

	ttMuud alias for $11;

	tnFailid alias for $12;

	tnDokPropid alias for $13;



	v_avans record;

	lnSumma numeric(12,2);

	lnId int; 

	v_vanadekl record;

	lInsert int;

	lnParentid int;

	lnStaatus int;

	ldSaadetud date;

	lnDokpropId int;

begin

lnDokpropId = tnDokpropId;

lnparentId = tnparentId;



if ifnull(tnParentid,0) = 0 then

	select parentId into lnParentId from luba where id = tnLubaId;

end if;

if tnDokPropid = 0 and tcTyyp = 'INTRESS' then

	lnDokPropid = 934;	

end if;





if tnId = 0 then

	lInsert = 1;

	if tcTyyp = 'DEKL' then



		select id into lnId from toiming where lubaid = tnLubaId and kpv = tdKpv and empty (saadetud) ;

		lnId = ifnull(lnId,0);

		if  lnId > 0 then 

			-- on eelmine deklaratsiooni versioonid, kustame

		

			perform sp_del_toiming(lnId);

		end if;

		-- check for saadetud dekl

		select count(id) into lnid from toiming  

			WHERE  lubaid = tnLubaId and kpv = tdKpv and not empty (saadetud);

		lnid = ifnull(lnId,0);

		if lnId > 0 then

			-- saadetud dekl. on

			lInsert = 0;

		end if;



		lnid = 0;

	end if;

	if linsert = 1 then

	-- uus kiri

		insert into toiming (parentid,lubaid, kpv,alus, ettekirjutus, tahtaeg, summa, staatus, tyyp, muud, failid, dokpropId) 

			values (lnparentid,tnlubaid, tdkpv, tcalus, tcettekirjutus, tdtahtaeg, round(tnsumma,0), tnstaatus, tctyyp, ttmuud, tnFailid, lnDokpropId);



		lnId:= cast(CURRVAL('public.toiming_id_seq') as int4);



	end if;

else

	-- muuda 

	update toiming set 

		parentid = lnParentId,

		lubaid = tnLubaId, 

		kpv = tdKpv,

		alus = tcAlus, 

		ettekirjutus = tcettekirjutus, 

		tahtaeg = tdtahtaeg, 

		summa = round(tnSumma,0), 

		staatus = tnStaatus, 

		tyyp = tcTyyp, 

		failid = tnFailid,

		dokpropId = lnDokPropId,

		muud = ttMuud	

	where id = tnId;



	lnId := tnId;



end if;



select staatus into lnStaatus from toiming where id = lnId;





-- recalc luba jaak

perform sp_recalc_rekljaak(tnLubaId);







-- lausend

select saadetud into ldSaadetud from toiming where id = lnId;



if tcTyyp = 'DEKL' and ifnull(lnStaatus,0) > 0 and not empty (ldSaadetud) then

	perform gen_lausend_reklmaks(lnId);

end if;



if  tcTyyp = 'INTRESS' and ifnull(lnStaatus,0) > 0 then

	perform gen_lausend_reklintress(lnId);

end if;

if  tcTyyp = 'PIKENDUS' and ifnull(lnStaatus,0) > 0 then

	update luba set loppkpv = ifnull(ldSaadetud,date()+365) where id = tnLubaId;

	perform sp_muuda_deklstaatus(lnId, 1);

end if;



         return  lnId;

end;

$$;

ALTER FUNCTION sp_salvesta_toiming(INTEGER, INTEGER, INTEGER, DATE, VARCHAR, VARCHAR, DATE, NUMERIC, INTEGER, VARCHAR, TEXT, INTEGER, INTEGER) OWNER TO vlad;

