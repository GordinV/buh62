CREATE FUNCTION trigd_mk1_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	lnId int;
begin
if old.JournalId > 0 then
	lnId :=sp_del_journal (old.JournalId,1);
end if;
return null;

end;
$$;

ALTER FUNCTION trigd_mk1_after() OWNER TO vlad;

