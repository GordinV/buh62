CREATE FUNCTION str(integer, integer) RETURNS character
    LANGUAGE plpgsql
AS
$$
begin

         return  left(ltrim(rtrim(cast($1 as bpchar))),$2);

end;

$$;

ALTER FUNCTION str(INTEGER, INTEGER) OWNER TO vlad;

