CREATE FUNCTION trigd_autod_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	lnCount int4;	


begin


	select count(id) into lnCount from arv where objektId = old.id;


	if lnCount > 0 then


		raise exception 'Ei saa kustuta';


		return NULL;


	else


		return OLD;


	end if;

end;

$$;

ALTER FUNCTION trigd_autod_before() OWNER TO vlad;

