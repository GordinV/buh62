CREATE FUNCTION sd(character varying, integer, date, integer) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
DECLARE tcKontogrupp alias for $1;
	tnrekvid alias for $2;
	tdKpv alias for $3;
	tnKond alias for $4;
	lnAlg numeric (18,6);
	lnDb numeric (18,6);
	lnKr numeric (18,6);
begin
	-- arv algsaldo
--	select sum(algsaldo) into lnAlg from library l inner join kontoinf k on l.id = k.parentId 
--		where k.rekvId = tnRekvId and l.kood = ltrim(rtrim(tcKontogrupp));

	-- arv. deebet kaibed

	select sum(summa * ifnull(dokvaluuta1.kuurs,1)) into lnDb from journal1 left outer join dokvaluuta1 on (journal1.id = dokvaluuta1.dokid and dokvaluuta1.dokliik = 1)
		where ltrim(rtrim(deebet)) = ltrim(rtrim(tcKontogrupp))
		and parentid in (select id from journal 
		where (rekvId in (SELECT id FROM rekv where fnc_get_asutuse_staatus(rekv.id, tnRekvId) > tnKond) or  rekvid = tnRekvId)
		and kpv <= tdKpv);

	-- arv. kreedit kaibed
	select sum(summa * ifnull(dokvaluuta1.kuurs,1)) into lnKr from journal1 left outer join dokvaluuta1 on (journal1.id = dokvaluuta1.dokid and  dokvaluuta1.dokliik = 1)
		where ltrim(rtrim(kreedit)) = ltrim(rtrim(tcKontogrupp))
		and parentid in (select id from journal 
		where (rekvId in (SELECT id FROM rekv where fnc_get_asutuse_staatus(rekv.id, tnRekvId) > tnKond) or  rekvid = tnRekvId)
		and kpv <= tdKpv);
	return ifnull(lnAlg,0) + ifnull(lnDb,0) - ifnull(lnKr,0);
end;

$$;

ALTER FUNCTION sd(VARCHAR, INTEGER, DATE, INTEGER) OWNER TO vlad;

