CREATE FUNCTION trigu_dokvaluuta1_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare
	lcSql text;
	lnUsrID int;
	lnRekvId int;
begin
	raise notice 'updated new.id %', new.id;

lcSql:=
	case when old.dokid <> new.dokid then 
		'dokid:' + old.dokid::text + '
'  else ''
	end +
	
	case when old.dokliik <> new.dokliik then 
		'dokliik:' + old.dokliik::text + '
'  else ''
	end +
	
	case when old.valuuta <> new.valuuta then 
		'valuuta:' + old.valuuta::text + '
'  else ''
	end +
	
	case when old.kuurs <> new.kuurs then 
		'kuurs:' + old.kuurs::text + '
'  else ''
	end +
	
	case when old.muud <> new.muud or (IfNull(old.muud,space(1)) <> IfNull(new.muud,space(1))) then 
		'muud:' + case when ifNull(old.muud,space(1)) = space(1) then space(1) + '
'  else old.muud::text + '
'  end else ''
	end;
	SELECT id, rekvid INTO lnUsrID, lnRekvId from userid WHERE kasutaja = CURRENT_USER::VARCHAR;
	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 
		VALUES (lnRekvId,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,new.id,lcSql);
	return null;
end;
$$;

ALTER FUNCTION trigu_dokvaluuta1_after_r() OWNER TO vlad;

