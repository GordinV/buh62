CREATE FUNCTION trigu_vanemtasu3_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	v_vt record;

begin

	select id into v_vt from vanemtasu5 where arveid = new.id;

	if ifnull(v_vt.Id,0) > 0 then

		raise exception 'arve on suletud';

		return null;

	end if;

	return new;

	

end;

$$;

ALTER FUNCTION trigu_vanemtasu3_before() OWNER TO vlad;

