CREATE FUNCTION sp_create_vt_arved(integer, integer, date, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare

	tnid alias for $1;

	tnVT3id alias for $2;

	tdKpv alias for $3;

	tnDokpropId alias for $4;

	lnReturn int;

	lcKonto varchar;

	qryVanemtasu5 record;

	qryVanemtasu6 record;

	qryVanemtasu1 record;

	qryVanemtasu3 record;

	v_klassiflib record;



	lnVT3id int4;

begin



lnVT3id := tnVT3id;



IF EMPTY(tnId) then

	RETURN 0;

END IF;



IF tnDokpropId > 0 then

	SELECT * into lcKonto from dokprop WHERE id = tnDokpropId;	

ELSE

	lcKonto = space(1);

END IF;





SELECT * into qryVanemtasu5 from vanemtasu5  WHERE isikid = tnid AND kuu = MONTH(tdkpv) 

	and aasta = YEAR(tdkpv) AND arveId = 0;



if ifnull(qryVanemtasu5.id,0) = 0 then

	return 0;

end if; 





SELECT * into qryVanemtasu1 from vanemtasu1  WHERE id = tnid;



raise notice 'qryVanemtasu5.rekvid %',qryVanemtasu5.rekvid;

raise notice 'qryVanemtasu5.id %',qryVanemtasu5.id;



IF lnVT3Id > 0 then

	--	vanemtasu3 oli created, just insert into vt6

	SELECT id into qryVanemtasu3 FROM vanemtasu3 WHERE id = lnVT3Id ;

ELSE

	-- uus arve

		INSERT INTO vanemtasu3 (rekvid, userid, opt, kpv, summa, tunnus, dokpropId, konto)

			VALUES (qryVanemtasu5.rekvid, qryVanemtasu5.userid,2, tdKpv,qryvanemtasu5.summa, qryvanemtasu5.tunnus, tnDokpropId, lcKonto);



		lnVT3id = cast(CURRVAL('public.vanemtasu3_id_seq') as int4);		

END IF;



lnreturn := lnVT3id ;



IF EMPTY(lnVT3id )  then

	RETURN 0;

END IF;







for qryVanemtasu6 in 

	SELECT * from vanemtasu6  WHERE parentid = qryVanemtasu5.id

loop

	SELECT * into v_klassiflib from klassiflib where nomid = qryVanemtasu6.nomid;

	

	INSERT INTO vanemtasu4 (parentid, isikId, maksjakood, maksjanimi, nomId, kogus, hind, summa, konto, tp, kood1, kood2, kood3, kood4, kood5) values

		(lnreturn, qryVanemtasu5.isikid, qryVanemtasu1.vanemkood,qryVanemtasu1.vanemnimi, qryVanemtasu6.nomid,

		 qryVanemtasu6.kogus, qryVanemtasu6.hind, qryVanemtasu6.summa,ifnull(v_klassiflib.konto,space(1)), '800699',

		ifnull(v_klassiflib.kood1,space(1)), ifnull(v_klassiflib.kood2,space(1)),ifnull(v_klassiflib.kood3,space(1)),

		ifnull(v_klassiflib.kood4,space(1)), ifnull(v_klassiflib.kood5,space(1)) );



	UPDATE vanemtasu5 SET arveid = lnVT3Id WHERE id = qryVanemtasu5.id;



END loop;



RETURN lnReturn;



end;

$$;

ALTER FUNCTION sp_create_vt_arved(INTEGER, INTEGER, DATE, INTEGER) OWNER TO vlad;

