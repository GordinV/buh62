CREATE FUNCTION sp_viimanepaev(integer, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare 
	lnKuu alias for $1;
	lnAasta alias for $2;
BEGIN


RETURN DAY(GOMONTH(DATE(lnAasta, lnKuu, 1), 1)-1);
end;

$$;

ALTER FUNCTION sp_viimanepaev(INTEGER, INTEGER) OWNER TO vlad;

