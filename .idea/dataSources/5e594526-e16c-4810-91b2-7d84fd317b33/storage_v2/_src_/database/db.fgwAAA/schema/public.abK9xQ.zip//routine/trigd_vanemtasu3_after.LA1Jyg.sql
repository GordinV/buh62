CREATE FUNCTION trigd_vanemtasu3_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 



	v_userid record;



	lresult int;



	lcNotice varchar;



begin



	if old.journalId > 0 then



		perform sp_del_journal(old.journalId,1);



	end if;



	perform sp_register_oper(old.rekvid,old.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, old.rekvid));





	delete from vanemtasu4 where parentid = old.id;



	return old;



end;


$$;

ALTER FUNCTION trigd_vanemtasu3_after() OWNER TO vlad;

