CREATE FUNCTION trigu_leping1_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:=

	case when old.asutusid <> new.asutusid then 

		'asutusid:' + old.asutusid::text + '

'  else ''

	end +

	

	case when old.rekvid <> new.rekvid then 

		'rekvid:' + old.rekvid::text + '

'  else ''

	end +

	

	case when old.doklausid <> new.doklausid then 

		'doklausid:' + old.doklausid::text + '

'  else ''

	end +

	

	case when old.number <> new.number then 

		'number:' + old.number::text + '

'  else ''

	end +

	

	case when old.kpv <> new.kpv then 

		'kpv:' + dtoc(old.kpv) + '

'  else ''

	end +

	

	case when old.tahtaeg <> new.tahtaeg or (IfNull(old.tahtaeg,date(1900,01,01)) <> IfNull(new.tahtaeg,date(1900,01,01))) then 

		'tahtaeg:' + case when ifNull(old.tahtaeg,date(1900,01,01)) = date(1900,01,01) then space(1) + '

'  else dtoc(old.tahtaeg) +  '

'  end else ''

	end +

	

	case when old.selgitus <> new.selgitus then 

		'selgitus:' + old.selgitus::text + '

'  else ''

	end +

	

	case when old.dok <> new.dok or (IfNull(old.dok,space(1)) <> IfNull(new.dok,space(1))) then 

		'dok:' + case when ifNull(old.dok,space(1)) = space(1) then space(1) + '

'  else old.dok::text + '

'  end else ''

	end +

	

	case when old.muud <> new.muud or (IfNull(old.muud,space(1)) <> IfNull(new.muud,space(1))) then 

		'muud:' + case when ifNull(old.muud,space(1)) = space(1) then space(1) + '

'  else old.muud::text + '

'  end else ''

	end;

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (new.rekvid,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,new.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigu_leping1_after_r() OWNER TO vlad;

