CREATE FUNCTION sp_rekl_aruanne3(tnrekvid integer, tdkpv1 date, tdkpv2 date, tnasutusid integer) RETURNS character varying
    LANGUAGE plpgsql
AS
$$
DECLARE 
	lcReturn varchar = to_char(now(), 'YYYYMMDDMISSSS');
begin
	delete from tmpReklAruanne3  where left(timestamp,8)::integer < left(lcReturn,8)::integer;

	insert into tmpReklAruanne3
		select lcReturn, a.regkood, a.nimetus,
			asd('102060%',a.id, tnRekvId,  tdKpv2), asd('102095%',a.id, tnRekvId,  tdKpv2), ask('200060%',a.id, tnRekvId,  tdKpv2),
			(select sum(fncdekljaak(t.id)) from toiming t where parentid = a.id and tyyp in ('DEKL','PARANDUS') 
				and staatus > 0 
				and tahtaeg <= tdKpv2 
				and year(tahtaeg) = year(tdKpv2) ) as volg,
			fncreklettemaksjaak(a.id, tdKpv2) as ettemaks, fncreklintressijaak(a.id, tdKpv2) as intress
			from asutus a 
			where id in (select parentId from luba l where l.staatus > 0) 
			and (a.id = tnAsutusId or coalesce(tnAsutusId = 0));
	return lcReturn;

end;

$$;

ALTER FUNCTION sp_rekl_aruanne3(INTEGER, DATE, DATE, INTEGER) OWNER TO vlad;

