CREATE FUNCTION sp_update_pv_jaak(integer) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
declare
	tnid alias for $1;
	lnpv_operId int;
	lnId int; 
	lnSumma numeric(18,6);
	v_pv_kaart record;
	lrCurRec record;
	lnPvElu numeric(6,2);
	lnKulum numeric(12,2);

	lnSoetSumma numeric (18,6);
	lnParandatudSumma numeric (18,6);
	lnUmberhindatudSumma numeric (18,6);
	
	lnDokKuurs numeric(14,4);
	lcString varchar;
	v_dokvaluuta record;
	ldKpv date;
	lnJaak numeric (18,6);

	lKasUmberHindatud integer;

begin

lKasUmberHindatud= 0;

	select pv_kaart.id, soetmaks, parhind, algkulum, kulum, soetkpv, ifnull(dokvaluuta1.kuurs,1)::numeric as kuurs into v_pv_kaart 
		from pv_kaart left outer join dokvaluuta1 on (dokvaluuta1.dokid = pv_kaart.id and dokliik = 18) 
		where pv_kaart.parentId = tnid;

	lnKulum := v_pv_kaart.kulum;
	ldKpv := v_pv_kaart.soetkpv;

	-- PARANDAME PARANDATUD SUMMA.

--	lnSumma = get_pv_summa(tnparentid);




		select sum(summa*ifnull(dokvaluuta1.kuurs,1)) into lnUmberhindatudSumma 
			from pv_oper left outer join dokvaluuta1 on (dokvaluuta1.dokid = pv_oper.id and dokvaluuta1.dokliik = 13)
			where pv_oper.parentId = tnid and liik = 5;

		lnUmberhindatudSumma := ifnull(lnUmberhindatudSumma,0);

		raise notice 'hind: %',lnUmberhindatudSumma;
		if lnUmberhindatudSumma > 0 then
			select kpv into ldKpv from pv_oper where liik = 5 and parentId = tnId order by kpv desc limit 1;
			lKasUmberHindatud = 1;
		else
			lnUmberhindatudSumma := lnSoetSumma;
		end if;

		raise notice 'kpv: %',ldKpv;

	if lKasUmberHindatud = 0 then
	select sum(summa*ifnull(dokvaluuta1.kuurs,1)) into lnSoetSumma 
		from pv_oper left outer join dokvaluuta1 on (dokvaluuta1.dokid = pv_oper.id and dokvaluuta1.dokliik = 13)
		where parentId = tnid and liik = 1;

	lnSoetSumma  = ifnull(lnSoetSumma ,v_pv_kaart.soetmaks);

	raise notice 'lnSoetSumma %, v_pv_kaart.soetmaks %, v_pv_kaart.id %',lnSoetSumma, v_pv_kaart.soetmaks, v_pv_kaart.id;

	else
		lnSoetSumma = lnUmberhindatudSumma;		
		raise notice 'lnUmberhindatudSumma %, v_pv_kaart.id %',lnUmberhindatudSumma, v_pv_kaart.id;
	end if;
	
	select sum(summa*ifnull(dokvaluuta1.kuurs,1)) into lnParandatudSumma 
		from pv_oper left outer join dokvaluuta1 on (dokvaluuta1.dokid = pv_oper.id and dokvaluuta1.dokliik = 13)
		where parentId = tnid and liik = 3 and kpv > ldKpv;

		raise notice 'lnParandatudSumma 1: %',lnParandatudSumma;

	lnParandatudSumma = ifnull(lnParandatudSumma,0);

	select sum(summa*ifnull(dokvaluuta1.kuurs,1)) into lnKulum 
		from pv_oper left outer join dokvaluuta1 on (dokvaluuta1.dokid = pv_oper.id and dokvaluuta1.dokliik = 13)
		where parentId = tnid and liik = 2 and kpv > ldKpv;

--	lnParandatudSumma := ifnull(lnParandatudSumma,0) + ifnull(lnUmberhindatudSumma,v_pv_kaart.soetmaks);
	lnKulum = ifnull(lnKulum,0);

	lnParandatudSumma := lnSoetSumma + ifnull(lnParandatudSumma,0);
		raise notice 'lnParandatudSumma 2: %',lnParandatudSumma;



	-- otsime dok.valuuta
	Select id into lnId from pv_kaart where parentid = tnId;
	
		
--	lnParandatudSumma = lnParandatudSumma;
		raise notice 'lnParandatudSumma dokvaluutas %',lnParandatudSumma;

	raise notice 'kulum  %',lnKulum;
	raise notice 'v_pv_kaart.algkulum %',v_pv_kaart.algkulum;


--	if lnUmberhindatudSumma > 0 and lnUmberhindatudSumma <> lnSoetSumma then
--		raise notice 'Umber kulum = 0 %',lnKulum;
--		raise notice 'lnSoetSumma %',lnSoetSumma;
--		raise notice 'lnUmberhindatudSumma %',lnUmberhindatudSumma;
--	end if;
-- privodim k kursu po kotoroj kupleno PO
		lnKulum = ifnull(lnKulum,0);

	lnParandatudSumma = round(lnParandatudSumma / v_pv_kaart.kuurs,2);
	lnKulum = round(lnKulum / v_pv_kaart.kuurs,2);

	if lKasUmberHindatud = 0 then
		lnJaak = lnParandatudSumma - lnKulum - ifnull(v_pv_kaart.algkulum,0);
	else
		lnJaak = lnParandatudSumma - lnKulum ;
	end if;
	raise notice 'lnJaak %',lnJaak;
	update pv_kaart set parhind = lnParandatudSumma , jaak = lnJaak where parentId = tnid;

         return  lnJaak;
end;
$$;

ALTER FUNCTION sp_update_pv_jaak(INTEGER) OWNER TO vlad;

