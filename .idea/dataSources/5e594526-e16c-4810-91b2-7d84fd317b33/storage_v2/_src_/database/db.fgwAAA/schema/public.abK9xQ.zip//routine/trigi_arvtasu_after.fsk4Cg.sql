CREATE FUNCTION trigi_arvtasu_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin

	UPDATE DBASE SET LASTNUM = NEW.ID WHERE id = 85;	 

	return NULL;

end;

$$;

ALTER FUNCTION trigi_arvtasu_after() OWNER TO vlad;

