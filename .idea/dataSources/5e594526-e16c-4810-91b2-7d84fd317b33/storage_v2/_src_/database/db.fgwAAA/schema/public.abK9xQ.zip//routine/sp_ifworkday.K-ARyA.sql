CREATE FUNCTION sp_ifworkday(date, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare 
	tdKpv	 ALIAS FOR $1;
	tnRekvId ALIAS FOR $2;

	lnreturn int;
	lnCount int;

	lnDow int;


BEGIN
lnreturn = 1;



lnDow:=DOW(tdKpv);
IF lnDOW = 6 OR lnDOW = 7 or lnDow = 0 then
	lnreturn = 0;
ELSE
	SELECT count(id) into lnCount from holidays where rekvid = tnrekvid 

		and paEv=DAY(tdKpv) AND kuU=MONTH(tdKpv) 

		group by kuu, paev;
	if lnCount > 0 then
		lnreturn = 0;

        END IF;
END IF;


RETURN lnReturn;
end;

$$;

ALTER FUNCTION sp_ifworkday(DATE, INTEGER) OWNER TO vlad;

