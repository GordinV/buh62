CREATE FUNCTION trigd_vanemtasu4_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 



	v_userid record;





	v_vanemtasu3 record;



	lresult int;



	lcNotice varchar;



begin





	select * into v_vanemtasu3 from vanemtasu3 where id = old.parentid;











	IF v_vanemtasu3.opt = 1 then





		-- kassa





		UPDATE vanemtasu2 SET jaak = jaak + old.summa 





			WHERE isikId = old.isikId AND tunnus = v_vanemtasu3.tunnus AND rekvid = v_vanemtasu3.rekvId;





	END IF;





	IF v_vanemtasu3.opt = 2 then





		UPDATE vanemtasu2 SET jaak = jaak - old.summa 





			WHERE isikId = old.isikId AND tunnus = v_vanemtasu3.tunnus AND rekvid = v_vanemtasu3.rekvId;





	END IF;





	



	perform sp_register_oper(v_vanemtasu3.rekvid,old.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, v_vanemtasu3.rekvid));



	return null;



end;


$$;

ALTER FUNCTION trigd_vanemtasu4_after() OWNER TO vlad;

