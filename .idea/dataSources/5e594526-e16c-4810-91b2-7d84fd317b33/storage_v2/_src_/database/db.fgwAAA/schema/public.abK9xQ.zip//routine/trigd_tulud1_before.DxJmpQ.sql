CREATE FUNCTION trigd_tulud1_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	lnCount int4;


begin

	delete from tulud2 where parentid = old.id;


	return OLD;

end;

$$;

ALTER FUNCTION trigd_tulud1_before() OWNER TO vlad;

