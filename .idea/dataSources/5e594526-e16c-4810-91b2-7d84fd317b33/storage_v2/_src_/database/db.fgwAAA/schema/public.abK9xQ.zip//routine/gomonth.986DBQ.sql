CREATE FUNCTION gomonth(date, integer) RETURNS date
    LANGUAGE plpgsql
AS
$$
declare


	tdKpv alias for $1;


	tnPeriod alias for $2;


	lnYear int;


	lnMonth int;


	lnDay int;


	lnCount int2;

begin


	lnDay := day(tdKpv);


	lnMonth := month(tdKpv) + tnPeriod;


	if lnMonth > 12 then


		lnCount:= lnMonth / 12 ::int2;


		lnMonth := lnMonth - 12 * lnCount;


		lnYear := YEAR(tdKpv) + lnCount;


	else


		lnYear := YEAR(tdKpv);


	end if;


         return  date(lnYear,lnMonth,lnDay);

end;

$$;

ALTER FUNCTION gomonth(DATE, INTEGER) OWNER TO vlad;

