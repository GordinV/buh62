CREATE FUNCTION month(date) RETURNS integer
    LANGUAGE plpgsql
AS
$$
begin

         return  cast(extract(month from $1) as int8);

end;

$$;

ALTER FUNCTION month(DATE) OWNER TO vlad;

