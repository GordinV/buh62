CREATE FUNCTION trigd_toiming_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	lnCount int4;
	lnSumma numeric(12,2);
	lnStaatus int;
begin

	if old.tyyp = 'TASU' then
		if (select count(*) from dekltasu where tasuid = old.id) > 0 then
			raise notice 'kustame tasu info';
			delete from dekltasu where tasuid = old.id;
			IF (select count(id) from ettemaksud where dokid = old.id) > 0 then
				delete from ettemaksud where dokid = old.id;
			else
				insert into ettemaksud (rekvid, kpv, summa, number, asutusid, dokid, doktyyp, selg, staatus, journalid)
				values( 28, old.KPV, old.summa, 0,old.parentid, 0, 1, old.alus, 1, 0);
			end if;
			perform sp_recalc_rekljaak(old.lubaId); 
			perform fncReklEttemaksStaatusRecalc(old.parentid);
		end if;
	end if;
	if old.tyyp = 'ANULLERI' then
		select staatus into lnStaatus from luba where id = old.lubaid;
		if ifnull(lnStaatus,0) = 0 then
			perform sp_muuda_lubastaatus(old.lubaid, 1);
		end if;
	end if;
	perform sp_register_oper(0,old.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, 0));

	return NULL;
end;
$$;

ALTER FUNCTION trigd_toiming_after() OWNER TO vlad;

