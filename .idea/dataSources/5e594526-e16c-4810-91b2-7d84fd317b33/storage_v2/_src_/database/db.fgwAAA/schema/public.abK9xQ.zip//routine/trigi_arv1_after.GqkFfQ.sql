CREATE FUNCTION trigi_arv1_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin

	UPDATE DBASE SET LASTNUM = NEW.ID WHERE id = 83;	 

	return NULL;

end;

$$;

ALTER FUNCTION trigi_arv1_after() OWNER TO vlad;

