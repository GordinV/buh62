CREATE FUNCTION trigd_failid_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare
lnKinni int;

begin
	if old.name > 0 then
		-- kustuta dokument
		SELECT lo_unlink(old.name);
	end if;

	return null;


end;
$$;

ALTER FUNCTION trigd_failid_after() OWNER TO vlad;

