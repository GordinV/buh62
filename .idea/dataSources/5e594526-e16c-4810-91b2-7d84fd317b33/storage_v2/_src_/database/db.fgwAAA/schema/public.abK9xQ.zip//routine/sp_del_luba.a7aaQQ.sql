CREATE FUNCTION sp_del_luba(integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 


	tnId alias for $1;

begin

	Delete From luba Where Id = tnid;


	Return 1;


end;

$$;

ALTER FUNCTION sp_del_luba(INTEGER) OWNER TO vlad;

