CREATE FUNCTION trigi_doklausend_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin

	UPDATE DBASE SET LASTNUM = NEW.ID WHERE id = 91;	 

	return NULL;

end;

$$;

ALTER FUNCTION trigi_doklausend_after() OWNER TO vlad;

