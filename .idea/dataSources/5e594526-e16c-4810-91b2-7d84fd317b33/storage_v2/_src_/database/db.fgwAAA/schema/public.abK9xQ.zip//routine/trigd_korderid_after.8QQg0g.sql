CREATE FUNCTION trigd_korderid_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	lnId int;

begin

	if old.journalId > 0 then

		perform sp_del_journal(old.journalId,1);

	end if;

	

	SELECT count(id) into lnid FROM  Arvtasu WHERE Arvtasu.pankkassa = 2  AND Arvtasu.sorderid = old.Id;

	if lnId > 0 then

		SELECT id into lnid FROM  Arvtasu WHERE Arvtasu.pankkassa = 2  AND Arvtasu.sorderid = old.Id;

		perform sp_del_tasud (lnId,1);

	end if;

	--perform sp_register_oper(old.rekvid,old.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, old.rekvid));



	return NULL;

end;

$$;

ALTER FUNCTION trigd_korderid_after() OWNER TO vlad;

