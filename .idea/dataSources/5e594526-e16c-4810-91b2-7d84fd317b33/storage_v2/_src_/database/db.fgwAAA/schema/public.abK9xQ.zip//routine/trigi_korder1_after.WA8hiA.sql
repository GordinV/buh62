CREATE FUNCTION trigi_korder1_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin


	UPDATE DBASE SET LASTNUM = NEW.ID WHERE id = 148;	 


	return NULL;


end;


$$;

ALTER FUNCTION trigi_korder1_after() OWNER TO vlad;

