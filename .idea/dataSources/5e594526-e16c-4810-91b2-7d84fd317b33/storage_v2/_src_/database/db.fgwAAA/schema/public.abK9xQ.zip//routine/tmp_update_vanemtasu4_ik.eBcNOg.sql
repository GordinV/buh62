CREATE FUNCTION tmp_update_vanemtasu4_ik() RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare 
	v_lapsed record;

	lnCount int;
BEGIN


for v_lapsed in 

	select * from vanemtasu1 

loop

	if (select count(id) from vanemtasu4 where empty(vanemtasu4.maksjakood) and vanemtasu4.isikid = v_lapsed.id) > 0 then

		update vanemtasu4 set 

			maksjakood = v_lapsed.vanemkood, 

			maksjanimi = v_lapsed.vanemnimi

			where empty(vanemtasu4.maksjakood) and vanemtasu4.isikid = v_lapsed.id;

	end if;





end loop;





RETURN 1;

end;

$$;

ALTER FUNCTION tmp_update_vanemtasu4_ik() OWNER TO vlad;

