CREATE FUNCTION trigd_rekv_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	lnCount int4;	


	lnError int;

begin


	lnError := 0;

	select count(id) into lnCount from (


		SELECT id FROM journal WHERE rekvid = old.id


		UNION 


		SELECT id FROM arv WHERE rekvid = old.id


		union


		SELECT id FROM korder1 WHERE rekvid = old.id


		union


		SELECT id FROM mk WHERE rekvid = old.id


		union


		select id FROM curPohivara where rekvid = old.id


		union


		select id FROM curpalkoper where rekvid = old.id) a;





	if lnCount > 0 then

		raise exception 'Ei saa kustuta';

		return NULL;

	else


		delete from userid where rekvid = old.id;

--		delete from aa where rekvid = old.id;


		return OLD;

	end if;

end;

$$;

ALTER FUNCTION trigd_rekv_before() OWNER TO vlad;

