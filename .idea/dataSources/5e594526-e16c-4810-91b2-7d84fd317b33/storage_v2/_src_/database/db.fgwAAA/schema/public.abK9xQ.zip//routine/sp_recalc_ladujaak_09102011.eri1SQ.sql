CREATE FUNCTION sp_recalc_ladujaak_09102011(integer, integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 

	tnrekvId	ALIAS FOR $1;
	tnNomid	ALIAS FOR $2;
	tnArveId	ALIAS FOR $3;	
	cur_ladusisearved record;
	cur_v_arved record;
	v_ladu_config record;
	cur_ladujaak_valja record;
	cur_ladujaak_sise record;
	recArv	record;
	recArv1	record;
	lnCount int;
	ldKpv date;

	lnNomid1 int;
	lnNomid2 int;
	lnArveId1 int;
	lnArveId2 int;
	lnKogus numeric;
	lnJaak numeric;
	lnMaha numeric;

	lnSi integer;
	lnVi integer;
	lnId int;

begin



--raise notice ' alg  ';

lnNomId1 = 0;
lnNomid2 = 9999999;

if tnNomId > 0 then
	lnNomId1 = tnNomId;
	lnNomid2 = tnNomId;	
end if;
lnArveId1 = 0;
lnArveid2 = 9999999;

if tnArveId > 0 then
	lnArveId1 = tnArveId;
	lnArveid2 = tnArveId;	
end if;


select * into v_ladu_config from ladu_config where rekvid = tnrekvId;


-- clearn up old data
-- raise notice ' clearn up old data ';

delete from ladu_jaak 
	where rekvid = tnRekvId  
	and ladu_jaak.nomid >= lnNomId1 
	and ladu_jaak.nomid <= lnNomId2 
	and dokItemId in (select id from arv1 where parentid >= lnArveId1 and parentid <= lnArveid2);

-- delete compl. data
/*
delete from ladu_jaak 
	where rekvid = tnRekvId  
	and ladu_jaak.nomid in (select nomid from varaitem where parentid  >= lnNomId1 and parentid <= lnNomId2) 
	and dokItemId in (select id from arv1 where parentid >= lnArveId1 and parentid <= lnArveid2);
*/
-- insert new jaagid (+)
-- raise notice ' insert new jaagid (+) ';


insert into ladu_jaak (rekvid, dokItemId, nomId, userid,kpv, hind,kogus, maha, jaak, tahtaeg  )
	SELECT arv.rekvid, arv1.Id, arv1.nomId, arv.userId, arv.kpv, arv1.hind, arv1.kogus, 0, arv1.kogus,
	arv2.tahtaeg
	from arv inner join arv1 on arv.id = arv1.parentid 
	left outer join arv2 on arv2.arv1id = arv1.id
	where arv.rekvid = tnRekvid
	and arv.liik = 1 and arv.operId > 0
	and arv1.nomid >= lnNomId1 
	and arv1.nomid <= lnNomId2
	and arv.id >= lnArveId1 and arv.id <= lnArveid2;

-- update arve status

update arv1 set maha = 0 
	where id in (	SELECT distinct arv1.Id
	from arv inner join arv1 on arv.id = arv1.parentid 
	where arv.rekvid = tnRekvid
	and arv.liik = 1 and arv.operId > 0
	and arv1.nomid >= lnNomId1 
	and arv1.nomid <= lnNomId2
	and arv.id >= lnArveId1 and arv.id <= lnArveid2);


-- insert new jaagid (-)
-- raise notice ' insert new jaagid (-) ';

insert into ladu_jaak (rekvid, dokItemId, nomId, userid,kpv, hind,kogus, maha, jaak, tahtaeg  )
	SELECT arv.rekvid, arv1.Id, arv1.nomId, arv.userId, arv.kpv, arv1.hind, (-1 * arv1.kogus), 0, (-1 * arv1.kogus), arv2.tahtaeg
	from arv inner join arv1 on arv.id = arv1.parentid 
	left outer join arv2 on arv2.arv1id = arv1.id
	where arv.rekvid = tnRekvid
	and arv.liik = 0 and arv.operId > 0
	and arv1.nomid >= lnNomId1 
	and arv1.nomid <= lnNomId2 
	and arv.id >= lnArveId1 and arv.id <= lnArveid2;


-- insert items for complex. prod (+)
-- raise notice ' insert items for complex. prod (+)';


insert into ladu_jaak (rekvid, dokItemId, nomId, userid,kpv, hind,kogus, maha, jaak, tahtaeg  )
	SELECT arv.rekvid, arv1.Id, varaitem.nomId, arv.userId, arv.kpv, 
	nomenklatuur.hind, 
	(-1 * arv1.kogus * varaitem.kogus), 0, (-1 * arv1.kogus * varaitem.kogus), arv2.tahtaeg
	from arv inner join arv1 on arv.id = arv1.parentid 
	inner join varaitem on varaitem.parentid = arv1.nomid
	inner join nomenklatuur on varaitem.nomid = nomenklatuur.id
	left outer join arv2 on arv2.arv1id = arv1.id
	where arv.rekvid = tnRekvid
	and arv.liik = 1 and arv.operId > 0
	and arv1.nomid >= lnNomId1 
	and arv1.nomid <= lnNomId2 
	and arv.id >= lnArveId1 and arv.id <= lnArveid2;

		
-- update dok. inform

update arv1 set maha = 0 where parentid in (select id from arv where arv.rekvid = tnRekvid and arv.liik = 1 and arv.operId > 0 and arv.id >= lnArveId1 and arv.id <= lnArveid2)
	and arv1.nomid >= lnNomId1 
	and arv1.nomid <= lnNomId2; 



--vara valjaminek
-- list of reduced items

lnVi = 0;
for cur_ladujaak_valja  in 
	select   id, jaak, maha, kpv, dokItemId, kogus, nomid   
	from ladu_jaak
	where rekvid = tnrekvId
	and jaak < 0
	and ladu_jaak.nomid >= lnNomid1
	and ladu_jaak.nomid <= lnNomId2
	order by kpv

loop
	lnVi = lnVi + 1;
	raise notice 'lnVi %',lnVi;
	raise notice 'reduced cur_ladujaak_valja %',cur_ladujaak_valja.id;
	-- look for item 
	lnKogus = -1* cur_ladujaak_valja.kogus;
	lnJaak = cur_ladujaak_valja.jaak;
	lnMaha = 0;
	lnSi = 0;
	for cur_ladujaak_sise  in 
		select   id, jaak, maha, kpv, dokItemId, kogus, nomid   
			from ladu_jaak
			where rekvid = tnrekvId
			and jaak > 0
			and ladu_jaak.nomid = cur_ladujaak_valja.nomid
			order by kpv
	loop
		lnSi = lnSi + 1;
		raise notice 'lnSi %',lnSi;

		raise notice 'cur_ladujaak_sise %',cur_ladujaak_sise.id;
		raise notice 'lnKogus (1) %',lnKogus;

		if lnKogus = 0 then
			exit;
		end if;

		lnJaak = cur_ladujaak_sise.jaak - lnKogus;
		lnMaha = -1 * lnKogus;

		raise notice 'lnJaak (1) %',lnJaak;

			if lnJaak < 0 then
				raise notice 'lnJaak < 0, selleparast sKogus = 0 , mahakandmine, lnKogus = lnKogus - SJaak ';
				
				lnJaak = 0;
				lnKogus = lnKogus - cur_ladujaak_sise.jaak;
				lnMaha = cur_ladujaak_sise.jaak;

				raise notice 'lnKogus (2) %',lnKogus;

				update ladu_jaak set jaak = 0, 
					maha = maha + lnMaha 
					where id = cur_ladujaak_sise.id ;			

				update arv1 set maha = 1 where id = cur_ladujaak_sise.dokitemid;
						
			
			else
						
				raise notice 'lnJaak > 0, SJaak = lnJaak, lnKogus = 0, VJaak = 0';
				lnMaha = lnKogus;
				lnKogus = 0;
				raise notice 'lnJaak (2) %',lnJaak;
				
				update ladu_jaak set jaak = lnJaak, 
					maha = maha + lnMaha 
					where id = cur_ladujaak_sise.id ;			

				raise notice 'cur_ladujaak_sise.id(2) %',cur_ladujaak_sise.id;
					
				-- mahakandmine vkogus
				update ladu_jaak set jaak = 0
					where id = cur_ladujaak_valja.id ;			

				raise notice 'cur_ladujaak_valja.id(2) %',cur_ladujaak_valja.id;

				update arv1 set maha = 1 where id = cur_ladujaak_sise.dokitemid;
				
				
				exit;

			end if;	
/*
		-- check if avail. kogus >= reduced
		if cur_ladujaak_sise.jaak >= (-1 * cur_ladujaak_valja.jaak) then 
			-- update reduced item, obnulili spisanie
			
--			update ladu_jaak set jaak = 0 where id = cur_ladujaak_valja.id;
			-- update avail item, 

			-- 1
			lnJaak = cur_ladujaak_sise.jaak - lnKogus;
			lnMaha = -1 * lnKogus;


			if lnJaak < 0 then
				
				lnJaak = 0;
				lnKogus = lnKogus - cur_ladujaak_sise.jaak;
				lnMaha = lnKogus;

				update ladu_jaak set jaak = 0, 
					maha = maha + lnMaha 
					where id = cur_ladujaak_sise.id ;			

				update arv1 set maha = 1 where id = cur_ladujaak_sise.dokitemid;
						
			end if;
			if lnJaak >= 0 then
				lnMaha = lnKogus;
				lnKogus = 0;
				
				update ladu_jaak set jaak = lnJaak, 
					maha = maha + lnMaha 
					where id = cur_ladujaak_sise.id ;			
					
				-- mahakandmine vkogus
				update ladu_jaak set jaak = 0
					where id = cur_ladujaak_valja.id ;			

				update arv1 set maha = 1 where id = cur_ladujaak_sise.dokitemid;
				

				exit;
			end if;			
			
-- varamahakandmine (vkogus) laost


		else
			-- valja qantity more than avail.item
	
			-- update reduced item
			update ladu_jaak set jaak = jaak + cur_ladujaak_sise.jaak where id = cur_ladujaak_valja.id;
			-- update avail item
			update ladu_jaak set jaak = 0, maha = cur_ladujaak_sise.kogus where id = cur_ladujaak_sise.id;
			-- update arv1 rea status
			update arv1 set maha = 1 where id = cur_ladujaak_sise.dokitemid;

			raise notice 'else ecur_ladujaak_sise.jaak %',cur_ladujaak_sise.jaak;
			raise notice 'else cur_ladujaak_sise.kogus %',cur_ladujaak_sise.kogus;

		end if;
*/
	end loop;
	if lnVi = 3 then
		exit;	
	end if;
end loop;

delete from ladu_jaak where jaak = 0;


return 1;



end;

$$;

ALTER FUNCTION sp_recalc_ladujaak_09102011(INTEGER, INTEGER, INTEGER) OWNER TO vlad;

