CREATE FUNCTION trigd_journal1_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	v_journal record;
begin

	select * into v_journal from journal where id = old.parentid;

	delete from dokvaluuta1 where dokid = old.id and dokliik = 1;

	--reklmaks
	delete from ettemaksud where journalid = old.id;
	
	return null;
end;
$$;

ALTER FUNCTION trigd_journal1_after() OWNER TO vlad;

