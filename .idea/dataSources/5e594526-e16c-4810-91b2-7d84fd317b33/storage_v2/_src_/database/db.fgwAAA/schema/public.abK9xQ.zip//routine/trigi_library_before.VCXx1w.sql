CREATE FUNCTION trigi_library_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	v_userid record;
	lresult int;
	lcNotice varchar;
begin
	lresult := 1;
	select * into v_userid from userid where  userid.rekvid = new.rekvid  and userid.kasutaja = CURRENT_USER::varchar order by peakasutaja_ desc limit 1;

	if (new.library = 'KONTOD' or new.library = 'ALLIKAS' OR new.library = 'TEGEV' OR new.library = 'KONTOD'
		OR new.library = 'TP' OR new.library = 'TULUDEALLIKAS' OR new.library = 'RAHA') and v_userid.peakasutaja_ < 1 then
		lresult := 0;
		lcNotice := 'Ei ole oigused'+space(1)+CURRENT_USER::varchar;
		raise notice 'kontrol library %',new.library;

	end if;
	if lResult = 1 then
		if empty (new.kood) or empty (new.library) then
			lresult := 0;
			lcNotice := 'Puudub vajalikud andmed'+space(1)+CURRENT_USER::varchar;
		end if;
	end if;
	if lResult = 0 then
		raise exception 'Viga: %',lcNotice;
		return null;
	else
		return new;
	end if;
end;
$$;

ALTER FUNCTION trigi_library_before() OWNER TO vlad;

