CREATE FUNCTION trigd_journal1_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:='parentid:' + old.parentid::TEXT + '

' +

	'summa:' + old.summa::TEXT + '

' +

	'dokument:' + case when ifnull(old.dokument,space(1))<>space(1) then 

		old.dokument::TEXT + '

' else ' ' end +

	'muud:' + case when ifnull(old.muud,space(1))<>space(1) then 

		old.muud::TEXT + '

' else ' ' end +

	'kood1:' + old.kood1 + '

' +

	'kood2:' + old.kood2 + '

' +

	'kood3:' + old.kood3 + '

' +

	'kood4:' + old.kood4 + '

' +

	'kood5:' + old.kood5 + '

' +

	'deebet:' + old.deebet + '

' +

	'lisa_k:' + old.lisa_k + '

' +

	'kreedit:' + old.kreedit + '

' +

	'lisa_d:' + old.lisa_d + '

' +

	'valuuta:' + old.valuuta + '

' +

	'kuurs:' + old.kuurs::TEXT + '

' +

	'valsumma:' + old.valsumma::TEXT + '

' +

	'tunnus:' + old.tunnus + '

' +

	'proj:' + old.proj + '

';

	

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (0,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,old.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigd_journal1_after_r() OWNER TO vlad;

