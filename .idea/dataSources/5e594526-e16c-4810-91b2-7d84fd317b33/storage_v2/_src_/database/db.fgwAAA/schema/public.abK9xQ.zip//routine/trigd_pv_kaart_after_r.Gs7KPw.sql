CREATE FUNCTION trigd_pv_kaart_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:='parentid:' + old.parentid::TEXT + '

' +

	'vastisikid:' + old.vastisikid::TEXT + '

' +

	'soetmaks:' + old.soetmaks::TEXT + '

' +

	'soetkpv:'+ old.soetkpv::TEXT + '

' +

	'kulum:' + old.kulum::TEXT + '

' +

	'algkulum:' + old.algkulum::TEXT + '

' +

	'gruppid:' + old.gruppid::TEXT + '

' +

	'konto:' + old.konto + '

' +

	'tunnus:' + old.tunnus::TEXT + '

' +

	'mahakantud:'+ case when ifnull(old.mahakantud,date(1900,01,01))<>date(1900,01,01) then 

		dtoc(old.mahakantud) + '

' else '' end +

	'otsus:' + case when ifnull(old.otsus,space(1))<>space(1) then 

		old.otsus::TEXT + '

' else ' ' end +

	'muud:' + case when ifnull(old.muud,space(1))<>space(1) then 

		old.muud::TEXT + '

' else ' ' end;

	

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	lnUsrId = ifnull(lnUsrId,0);

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (0,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,old.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigd_pv_kaart_after_r() OWNER TO vlad;

