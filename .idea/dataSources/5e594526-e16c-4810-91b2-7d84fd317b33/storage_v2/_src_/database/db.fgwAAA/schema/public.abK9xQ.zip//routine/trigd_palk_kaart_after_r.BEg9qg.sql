CREATE FUNCTION trigd_palk_kaart_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:='parentid:' + old.parentid::TEXT + '

' +

	'lepingid:' + old.lepingid::TEXT + '

' +

	'libid:' + old.libid::TEXT + '

' +

	'summa:' + old.summa::TEXT + '

' +

	'percent_:' + old.percent_::TEXT + '

' +

	'tulumaks:' + old.tulumaks::TEXT + '

' +

	'tulumaar:' + old.tulumaar::TEXT + '

' +

	'status:' + old.status::TEXT + '

' +

	'muud:' + case when ifnull(old.muud,space(1))<>space(1) then 

		old.muud::TEXT + '

' else ' ' end +

	'alimentid:' + old.alimentid::TEXT + '

' +

	'tunnusid:' + old.tunnusid::TEXT + '

';

	

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (0,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,old.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigd_palk_kaart_after_r() OWNER TO vlad;

