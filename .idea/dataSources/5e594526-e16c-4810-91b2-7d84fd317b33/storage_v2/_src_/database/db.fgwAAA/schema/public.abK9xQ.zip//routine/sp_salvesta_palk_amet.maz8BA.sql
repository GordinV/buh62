CREATE FUNCTION sp_salvesta_palk_amet(integer, integer, integer, character varying, character varying, integer, numeric, integer, numeric) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare

	tnid alias for $1;

	tnRekvid alias for $2;

	tcKood alias for $3;

	tcNimetus alias for $4;

	tnOsakondId alias for $5;

	tnKogus alias for $6;

	tnTunnusid alias for $7;

	tnVaba alias for $8;

	tnPalgamaar alias for $9;

	lnId int; 

	lcString varchar;





begin



if tnId = 0 then

	-- uus kiri, library

	insert into library (rekvid,kood,nimetus,library) values (tnRekvid,tcKood,tcNimetus,'AMET');



	lnId:= cast(CURRVAL('public.library_id_seq') as int4);



	-- palk_asutus



	insert into palk_asutus (rekvid, osakondid, ametid, kogus, tunnusid, vaba, palgamaar) values (tnrekvid, tnOsakondId,lnId, tnKogus, tnTunnusId, tnVaba, tnPalgamaar);



else

	-- muuda 



	update library set

		kood = tcKood,

		nimetus = tcNimetus

		where id = tnId;

		



	update palk_asutus set 

		kogus = tnKogus,

		tunnusid = tnTunnusid,

		vaba = tnVana,

		palgamaar = tnPalgamaar

		where ametid = tnId;



	lnid = tnid;

end if;



         return  lnId;

end;
$$;

ALTER FUNCTION sp_salvesta_palk_amet(INTEGER, INTEGER, INTEGER, VARCHAR, VARCHAR, INTEGER, NUMERIC, INTEGER, NUMERIC) OWNER TO vlad;

