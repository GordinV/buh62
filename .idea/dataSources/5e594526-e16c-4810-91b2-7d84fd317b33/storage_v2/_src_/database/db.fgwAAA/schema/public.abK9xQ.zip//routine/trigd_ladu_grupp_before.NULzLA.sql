CREATE FUNCTION trigd_ladu_grupp_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	lnCount int;	


begin


	select count(id) into lnCount from nomenklatuur where id = old.parentid;


	if lnCount > 0 then


		raise exception ' ei saa kustuta ';


		return null;


	else


		return old;


	end if;





end;

$$;

ALTER FUNCTION trigd_ladu_grupp_before() OWNER TO vlad;

