CREATE FUNCTION trigd_palk_asutus_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	v_userid record;
	lresult int;
	lcNotice varchar;
begin
	perform sp_register_oper(old.rekvid,old.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, old.rekvid));
	return null;
end;
$$;

ALTER FUNCTION trigd_palk_asutus_after() OWNER TO vlad;

