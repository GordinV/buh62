CREATE FUNCTION trigd_vanemtasu1_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 





	lnCount int4;













begin







	select count(*)  into lnCount from vanemtasu4 where isikid = old.id;











	if lnCount > 0 then







		raise exception 'Ei saa kustuta';







		return NULL;





	else







		return OLD;







	end if;







end;


$$;

ALTER FUNCTION trigd_vanemtasu1_before() OWNER TO vlad;

