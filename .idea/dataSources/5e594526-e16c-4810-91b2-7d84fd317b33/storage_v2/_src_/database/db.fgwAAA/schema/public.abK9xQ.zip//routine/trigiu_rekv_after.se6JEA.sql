CREATE FUNCTION trigiu_rekv_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	v_userid record;
	lresult int;
	lcNotice varchar;
begin
	perform sp_register_oper(new.id,new.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, new.id));
	return null;
end;
$$;

ALTER FUNCTION trigiu_rekv_after() OWNER TO vlad;

