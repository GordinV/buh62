CREATE FUNCTION trigd_palk_lib_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	lnCount int;

	lcErr varchar;

begin

	lnCount:= 0;

	select count(id) into lnCount from palk_oper WHERE palk_oper.libId = old.parentid;

	if ifnull(lnCount,0) > 0 then

		lcErr:= 'Selle kood kasutusel ';		

	end if;

	if ifnull(lnCount,0) > 0 then

		raise exception 'Viga: %',lcErr;

		return null;

	end if;



return old;



end;

$$;

ALTER FUNCTION trigd_palk_lib_before() OWNER TO vlad;

