CREATE FUNCTION trigd_holidays_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	v_rekv record;

begin



	if old.rekvid = 119 then

		for v_rekv in 

			select id from rekv where parentid = 119 

		loop

			delete from holidays 

				where paev = old.paev 

				and kuu = old.kuu

				and rekvid = v_rekv.id;



		end loop;





	end if;

	return null;



end;

$$;

ALTER FUNCTION trigd_holidays_after() OWNER TO vlad;

