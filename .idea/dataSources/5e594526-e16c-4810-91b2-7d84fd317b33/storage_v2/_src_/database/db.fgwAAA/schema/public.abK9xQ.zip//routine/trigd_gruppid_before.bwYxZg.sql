CREATE FUNCTION trigd_gruppid_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	lnCount int4;

begin




	select count(id) into lnCount from ladu_grupp where parentid = old.Id;




	 if lnCount > 0 then

	-- ei saa kustuta

		raise notice 'ei saa kustuta '; 

		 return NULL;

	else

		return OLD;

	end if;

end;

$$;

ALTER FUNCTION trigd_gruppid_before() OWNER TO vlad;

