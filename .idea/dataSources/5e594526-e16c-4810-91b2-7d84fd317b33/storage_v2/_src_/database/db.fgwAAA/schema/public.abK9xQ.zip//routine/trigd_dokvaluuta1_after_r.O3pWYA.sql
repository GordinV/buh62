CREATE FUNCTION trigd_dokvaluuta1_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare
	lcSql text;
	lnUsrID int;
	lnRekvId int;
begin

lcSql:='dokid:' + old.dokid::TEXT + '
' +
	'dokliik:' + old.dokliik::TEXT + '
' +
	'valuuta:' + old.valuuta::TEXT + '
' +
	'kuurs:'+ old.kuurs::TEXT + '
' +
	'muud:' + case when ifnull(old.muud,space(1))<>space(1) then 
		old.muud::TEXT + '
' else ' ' end;
	
	SELECT id, rekvid INTO lnUsrID, lnRekvId from userid WHERE kasutaja = CURRENT_USER::VARCHAR;
	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 
		VALUES (lnrekvid,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,old.id,lcSql);
	return null;
end;
$$;

ALTER FUNCTION trigd_dokvaluuta1_after_r() OWNER TO vlad;

