CREATE FUNCTION trigi_eelarve_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin

	UPDATE DBASE SET LASTNUM = NEW.ID WHERE id = 95;	 

	return NULL;

end;

$$;

ALTER FUNCTION trigi_eelarve_after() OWNER TO vlad;

