CREATE FUNCTION trigi_dokprop_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin

	UPDATE DBASE SET LASTNUM = NEW.ID WHERE id = 93;	 

	return NULL;

end;

$$;

ALTER FUNCTION trigi_dokprop_after() OWNER TO vlad;

