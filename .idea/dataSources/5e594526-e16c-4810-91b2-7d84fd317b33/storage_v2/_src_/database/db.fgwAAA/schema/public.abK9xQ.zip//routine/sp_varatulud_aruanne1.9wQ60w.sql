CREATE FUNCTION sp_varatulud_aruanne1(integer, date, date) RETURNS character varying
    LANGUAGE plpgsql
AS
$$
DECLARE tnrekvid alias for $1;
	tdKpv1 alias for $2;
	tdKpv2 alias for $3;

	lcArt varchar(20);
	lcNimetus varchar(254);
	lnCount int;
	lnSumma numeric(12,4);


	v_tunnus record;
	lcReturn varchar;
	lcString varchar;
	lcPnimi varchar;
	v_tulu record;

	v_pank record;

	v_tasu record;


begin

-- varaamet aruanne 

	select count(*) into lnCount from pg_stat_all_tables where UPPER(relname) = 'TMP_VARA';
	if ifnull(lnCount,0) < 1 then
	
		create table tmp_vara (art varchar(20), artikkel varchar(20), tunnus varchar(20), nimetus varchar(254),  tulusumma numeric (14,2) default 0, 
			panksumma numeric (14,2) default 0, tasudsumma numeric (14,2) default 0, jaak numeric (14,2) default 0, 
			timestamp varchar(20), kpv date default date(), rekvid int)  ;
		
		GRANT ALL ON TABLE tmp_vara TO GROUP public;

	else
		delete from tmp_vara where kpv < date() and rekvid = tnrekvId;

	end if;

	lcreturn := to_char(now(), 'YYYYMMDDMISSSS');

	-- tulud 

	for v_tulu  in 

		select arv1.kood5, sum(arv1.summa) as summa,  library.nimetus
		from arv inner join arv1 on arv.id = arv1.parentid 
		inner join library on (arv1.kood5 = library.kood and library.library = 'TULUDEALLIKAD')
		where arv.liik = 0 
		and arv.rekvid = tnrekvId 
		and arv.kpv >= tdKpv1 
		and arv.kpv <= tdKpv2
		group by kood5, nimetus

--		order by kood5


	loop
		-- kontrollime tunnus

		select count(*) into lnCount
		from 

		(

		select arv1.tunnus from arv inner join arv1 on arv.id = arv1.parentid 
		where arv.liik = 0 
		and arv.rekvid = tnrekvId 
		and arv.kpv >= tdKpv1 
		and arv.kpv <= tdKpv2
		and arv1.kood5 = v_tulu.kood5
		and not empty (arv1.tunnus)

		and arv1.kood5 in ('3238','3209','3811')

		group by tunnus

		) tmpArved;
		
		lnCount = ifnull(lnCount,0);



		if lnCount > 1  then
			--  tunnused suurem kui 1, siis teeme veek uks syscle

			lnSumma = 0;
			insert into tmp_vara (rekvid, art, artikkel, tunnus , nimetus, tulusumma, timestamp ) values 

					(tnrekvId,v_tulu.kood5, space(1),  space(1),'s.h.',0, lcreturn);



			for v_tunnus in 
				select arv1.tunnus, sum(arv1.summa) as Summa, library.nimetus  
				from arv inner join arv1 on arv.id = arv1.parentid 
				inner join library on (arv1.tunnus = library.kood and library.library = 'TUNNUS')
				where arv.liik = 0 
				and arv.rekvid = tnrekvId 
				and arv.kpv >= tdKpv1 
				and arv.kpv <= tdKpv2
				and arv1.kood5 = v_tulu.kood5
				and not empty (arv1.tunnus)

				and UPPER(arv1.tunnus) not like '%PANK%'
				group by tunnus, nimetus
			loop

				v_tunnus.Tunnus = ifnull(v_tunnus.Tunnus,space(1));
				v_tunnus.Summa = ifnull(v_tunnus.Summa,0);
				v_tunnus.Nimetus = ifnull(v_tunnus.Nimetus,space(1));


				lcArt := space(1);
				lcNimetus := v_tunnus.Nimetus;

				insert into tmp_vara (rekvid, art, artikkel, tunnus , nimetus, tulusumma, timestamp ) values 
					(tnrekvId,v_tulu.kood5, lcArt, v_tunnus.Tunnus,lcNimetus,v_tunnus.Summa, lcReturn);

				lnSumma = lnSumma + v_tunnus.Summa;
			end loop;


			-- kond rea

			lcArt := v_tulu.kood5;

			lcNimetus := v_tulu.nimetus;



			insert into tmp_vara (rekvid, art, artikkel, tunnus , nimetus, tulusumma, timestamp ) values 

				(tnRekvid, lcArt, lcArt, space(1),lcNimetus,v_tulu.Summa, lcreturn);


		else
			-- tavaline artikkel
			lcArt := v_tulu.kood5;
			lcNimetus := v_tulu.nimetus;

			insert into tmp_vara (rekvid, art, artikkel, tunnus , nimetus, tulusumma, timestamp ) values 
				(tnRekvid, lcArt, lcArt, space(1),lcNimetus,v_tulu.Summa, lcReturn);

		end if;


	END loop;


	-- saadetud a.a-le



	for v_pank  in 



		select sum(summa) as summa, kood5 

		from curJournal JOIN kassakontod 

		ON ltrim(rtrim(curjournal.deebet::text)) ~~ ltrim(rtrim(kassakontod.kood::text))

		where curJournal.rekvid = tnrekvId 

		and curJournal.kpv >= tdKpv1 

		and curJournal.kpv <= tdKpv2

		and left(curJournal.deebet,1) <> '9'

		group by curJournal.kood5





	loop

		-- kontrollime tunnus



		select count(*) into lnCount

		from 

		(

		select tunnus from curJournal

		where rekvid = tnrekvId 

		and kpv >= tdKpv1 

		and kpv <= tdKpv2

		and kood5 = v_pank.kood5

		and not empty (tunnus)

		and kood5 in ('3238','3209','3811')

		and UPPER(tunnus) not like '%PANK%'

		group by tunnus

		) tmpJournal;

		

		lnCount = ifnull(lnCount,0);







		if lnCount > 1 then

			--  tunnused suurem kui 1, siis teeme veek uks syscle

			lnSumma = 0;

	

	

			for v_tunnus in 

				select curJournal.tunnus, sum(curJournal.summa) as Summa

				from curJournal JOIN kassakontod 

				ON ltrim(rtrim(curjournal.deebet::text)) ~~ ltrim(rtrim(kassakontod.kood::text))

				where curJournal.rekvid = tnrekvId 

				and curJournal.kpv >= tdKpv1 

				and curJournal.kpv <= tdKpv2

				and curJournal.kood5 = v_pank.kood5

				and not empty (curJournal.tunnus)

				and UPPER(tunnus) not like '%PANK%'

				and left(curJournal.deebet,1) <> '9'

				group by curJournal.tunnus

			loop



				-- otsime rea tmptaabelis

	

				if (select count(*) from tmp_vara 

					where timestamp = lcReturn 

					and rekvid = tnRekvid 

					and art = v_pank.kood5 

					and tunnus = v_tunnus.tunnus) > 0 then



					update tmp_vara set panksumma = v_tunnus.summa 

						where timestamp = lcReturn 

						and rekvid = tnRekvid

						and art = v_pank.kood5 

						and tunnus = v_tunnus.tunnus;



				else



					select nimetus into lcNimetus from library where kood = v_tunnus.tunnus and library = 'TUNNUS';



					insert into tmp_vara (rekvid, art, artikkel, tunnus , nimetus, panksumma, timestamp ) values 	

						(tnrekvId,v_pank.kood5, space(1), v_tunnus.Tunnus,ifnull(lcNimetus,space(1)),v_tunnus.Summa, lcReturn);



				end if;

			end loop;



		else

			--lnCount > 1 then



			if (select count(*) from tmp_vara 

					where timestamp = lcReturn 

					and rekvid = tnRekvid 

					and art = v_pank.kood5 ) > 0 then



					update tmp_vara set panksumma = v_pank.summa 

						where timestamp = lcReturn 

						and rekvid = tnRekvid 

						and art = v_pank.kood5;



				else



					select nimetus into lcNimetus from library where kood = v_pank.kood5 and library = 'TULUDEALLIKAD';



					insert into tmp_vara (rekvid, art, artikkel, tunnus , nimetus, panksumma, timestamp ) values 	

						(tnrekvId,v_pank.kood5, v_pank.kood5, space(1),ifnull(lcNimetus,space(1)),v_pank.Summa, lcreturn);



				end if;





		end if;



	end loop;




	-- tagastamine eelarvesse



	for v_tasu  in 



		select sum(summa) as summa, kood5 

		from curJournal JOIN kassakontod 

		ON ltrim(rtrim(curjournal.kreedit::text)) ~~ ltrim(rtrim(kassakontod.kood::text))

		where curJournal.rekvid = tnrekvId 

		and curJournal.kpv >= tdKpv1 

		and curJournal.kpv <= tdKpv2

		and left(curJournal.KREEDIT,1) <> '9'

		and left(curJournal.deebet,6) = '710001'

		group by curJournal.kood5





	loop

		-- kontrollime tunnus



		select count(*) into lnCount

		from 

		(

		select tunnus from curJournal

		where rekvid = tnrekvId 

		and kpv >= tdKpv1 

		and kpv <= tdKpv2

		and kood5 = v_tasu.kood5

		and not empty (tunnus)

		and kood5 in ('3238','3209','3811')

		and UPPER(tunnus) not like '%PANK%'

		group by tunnus

		) tmpJournal;

		

		lnCount = ifnull(lnCount,0);







		if lnCount > 1 then

			--  tunnused suurem kui 1, siis teeme veek uks syscle

			lnSumma = 0;

	

	

			for v_tunnus in 

				select curJournal.tunnus, sum(curJournal.summa) as Summa

				from curJournal JOIN kassakontod 

				ON ltrim(rtrim(curjournal.kreedit::text)) ~~ ltrim(rtrim(kassakontod.kood::text))

				where curJournal.rekvid = tnrekvId 

				and curJournal.kpv >= tdKpv1 

				and curJournal.kpv <= tdKpv2

				and curJournal.kood5 = v_tasu.kood5

				and not empty (curJournal.tunnus)

				and UPPER(tunnus) not like '%PANK%'

				and left(curJournal.KREEDIT,1) <> '9'

				and left(curJournal.deebet,6) = '710001'

				group by curJournal.tunnus

			loop



				-- otsime rea tmptaabelis

	

				if (select count(*) from tmp_vara 

					where timestamp = lcReturn 

					and rekvid = tnRekvid 

					and art = v_tasu.kood5 

					and tunnus = v_tunnus.tunnus) > 0 then



					update tmp_vara set tasudsumma = v_tunnus.summa 

						where timestamp = lcReturn 

						and rekvid = tnRekvid

						and art = v_tasu.kood5 

						and tunnus = v_tunnus.tunnus;



				else



					select nimetus into lcNimetus from library where kood = v_tunnus.tunnus and library = 'TUNNUS';



					insert into tmp_vara (rekvid, art, artikkel, tunnus , nimetus, tasudsumma, timestamp ) values 	

						(tnrekvId,v_tasu.kood5, space(1), v_tunnus.Tunnus,ifnull(lcNimetus,space(1)),v_tunnus.Summa, lcreturn);



				end if;

			end loop;



		else

			--lnCount > 1 then



			if (select count(*) from tmp_vara 

					where timestamp = lcReturn 

					and rekvid = tnRekvid 

					and art = v_tasu.kood5 ) > 0 then



					update tmp_vara set tasudsumma = v_tasu.summa 

						where timestamp = lcReturn 

						and rekvid = tnRekvid 

						and art = v_tasu.kood5;



				else



					select nimetus into lcNimetus from library where kood = v_tasu.kood5 and library = 'TULUDEALLIKAD';



					insert into tmp_vara (rekvid, art, artikkel, tunnus , nimetus, tasudsumma, timestamp ) values 	

						(tnrekvId,v_tasu.kood5, v_tasu.kood5, space(1),ifnull(lcNimetus,space(1)),v_tasu.Summa, lcreturn);



				end if;





		end if;



	end loop;





	return LCRETURN;
end;

$$;

ALTER FUNCTION sp_varatulud_aruanne1(INTEGER, DATE, DATE) OWNER TO vlad;

