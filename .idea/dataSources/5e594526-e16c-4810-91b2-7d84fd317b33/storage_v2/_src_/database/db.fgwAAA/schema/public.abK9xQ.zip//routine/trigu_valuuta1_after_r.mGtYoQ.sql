CREATE FUNCTION trigu_valuuta1_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare
	lcSql text;
	lnUsrID int;
	lnRekvId int;
begin

lcSql:=
	case when old.parentid <> new.parentid then 
		'parentid:' + old.parentid::text + '
'  else ''
	end +
		
	case when old.kuurs <> new.kuurs then 
		'kuurs:' + old.kuurs::text + '
'  else ''
	end +
		
	case when old.alates <> new.alates then 
		'alates:' + old.alates::text + '
'  else ''
	end +

	case when old.kuni <> new.kuni then 
		'Kuni:' + old.kuni::text + '
'  else ''
	end +
	
	case when old.muud <> new.muud or (IfNull(old.muud,space(1)) <> IfNull(new.muud,space(1))) then 
		'muud:' + case when ifNull(old.muud,space(1)) = space(1) then space(1) + '
'  else old.muud::text + '
'  end else ''
	end;
	SELECT id, rekvid INTO lnUsrID, lnRekvId from userid WHERE kasutaja = CURRENT_USER::VARCHAR;
	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 
		VALUES (lnRekvId,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,new.id,lcSql);
	return null;
end;
$$;

ALTER FUNCTION trigu_valuuta1_after_r() OWNER TO vlad;

