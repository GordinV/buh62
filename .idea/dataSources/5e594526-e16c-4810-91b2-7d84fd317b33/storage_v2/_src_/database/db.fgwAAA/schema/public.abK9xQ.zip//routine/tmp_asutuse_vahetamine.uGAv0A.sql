CREATE FUNCTION tmp_asutuse_vahetamine() RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare 

	v_journal record;

	lnIsikId int;

begin

	for v_journal in 

		select id, asutusId from journal where rekvid = 61 and id in (select parentid from journal1 where kreedit = '203035')

	loop

		raise notice 'v_journal.asutusId: %', v_journal.asutusId;

		select tooleping.parentId into lnIsikId from tooleping inner join palk_oper on tooleping.id = palk_oper.lepingid 

			where palk_oper.journalid = v_journal.id and tooleping.rekvId = 61 limit 1;

		if ifnull(lnIsikId,0) > 0 then

			raise notice 'Parandame v_journal.asutusId -> : %', lnIsikId;

			update journal set asutusId = lnIsikId where id = v_journal.id;

		end if;

	end loop;



         return  1;

end;

$$;

ALTER FUNCTION tmp_asutuse_vahetamine() OWNER TO vlad;

