CREATE FUNCTION dk_new(character varying, integer, date, date) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
DECLARE tcKontogrupp alias for $1;
	tnrekvid alias for $2;
	tdKpv1 alias for $3;
	tdKpv2 alias for $4;
	lnKaib1 numeric (14,2);

	lnKaib2 numeric (14,2);

	lnreturn numeric (14,2);

	ldKpv1 date;

	ldKpv2 date;


begin	

	raise notice ' alg ';



	ldKpv1 := tdKpv1;

	ldKpv2 := tdKpv2;

	lnReturn := 0;



	if day(ldKpv1) > 1 then

	-- moving kond period up to 1 month

		ldKpv1 := gomonth(tdKpv1,1)

		ldKpv1 := date(year(ldKpv1),month(ldKpv1),1);

	end if;

	if day(ldKpv2) < sp_viimanepaev(tdKpv2) then

		ldKpv2 := date(year(gomonth(tdKpv1,-1)),month(gomonth(tdKpv1,-1)),sp_viimanepaev(tdKpv1));

	end if;

	raise notice ' ldkpv ';







	if tdKpv1 < ldKpv1 then

-- IT WAS MOVED FORWARD

		select sum(summa) into lnKaib2 from journal1 

			inner join journal on journal.id = journal1.parentid

			where journal.rekvid = tnRekvid

			and kpv >= tdKpv1

			and kpv < ldKpv1

			and deebet = tcKontogrupp

			and kpv <= tdKpv2

		lnreturn := lnreturn + ifnull(lnKaib2,0);

		

	end if;

	raise notice ' lnkaib2 1 ';

	if tdKpv2 > ldKpv2 then

		select sum(summa) into lnKaib2 from journal1 

			inner join journal on journal.id = journal1.parentid

			where journal.rekvid = tnRekvid

			and kpv > ldKpv2

			and kpv <= tdKpv2

			and deebet = tcKontogrupp

			and kpv >= tdKpv1

		lnreturn := lnreturn + ifnull(lnKaib2,0);

	end if;



	raise notice ' lnkaib2 2 ';



	if (month(ldKpv2) - month(ldKpv1)) > 0 then

	-- arv. meedia db kaibed
		select sum(dbkaibed) into lnKaib1 from saldo 
		where konto = tcKontogrupp

		and rekvid = tnRekvid

		and kpv >= ldKpv1 

		and kpv <= ldKpv2;



	raise notice ' lnkaib2 2 %',lnKaib1;

		

--		lnreturn := lnreturn + ifnull(lnKaib1,0);

		lnReturn := lnreturn + lnkaib1 	;
	end if;

	raise notice ' lnkaib1 1 ';



	return ifnull(lnReturn,0);
end;
$$;

ALTER FUNCTION dk_new(VARCHAR, INTEGER, DATE, DATE) OWNER TO vlad;

