CREATE FUNCTION trigd_failid_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare
lnKinni int;

lnCount int;
v_userid record;
lnrekvid int;
begin
	select rekvid into lnRekvId from luba where id = old.lubaid order by id limit 1;

	select * into v_userid from userid where id = sp_currentuser(CURRENT_USER::varchar, lnrekvid);
	if empty (v_userid.kasutaja_) and empty (v_userid.peakasutaja_) then
			raise exception 'Ei ole Oigused lisada/muudata/kustuta';
			return null;
	end if;

	return OLD;


end;
$$;

ALTER FUNCTION trigd_failid_before() OWNER TO vlad;

