CREATE FUNCTION trigd_luba_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

lnKinni int;



lnCount int;

v_userid record;



begin



--	delete from luba1 where parentid = old.id;

--	delete from toiming where lubaid = old.id;

	lnCount = 1;

	return NULL;





end;

$$;

ALTER FUNCTION trigd_luba_after() OWNER TO vlad;

