CREATE FUNCTION trigi_gruppomandus_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin

	UPDATE DBASE SET LASTNUM = NEW.ID WHERE id = 96;	 

	return NULL;

end;

$$;

ALTER FUNCTION trigi_gruppomandus_after() OWNER TO vlad;

