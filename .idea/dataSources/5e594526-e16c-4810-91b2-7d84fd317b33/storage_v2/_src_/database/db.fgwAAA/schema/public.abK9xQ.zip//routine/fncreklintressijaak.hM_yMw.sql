CREATE FUNCTION fncreklintressijaak(integer) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
declare
	tnAsutusId alias for $1;
	lnIntressiSumma numeric(18,6);
	lnTasuSumma numeric(18,6);
begin
lnIntressiSumma = 0;
/*
-- arvestatud intressi
select SUM(SuMma*ifnull(dokvaluuta1.kuurs,1))::numeric into lnIntressiSumma 
	from toiming left outer join dokvaluuta1 on (dokvaluuta1.dokid = toiming.id and dokvaluuta1.dokliik = 24)
	where parentid = tnAsutusId AND staatus > 0 and tyyp = 'INTRESS';

lnIntressiSumma  = ifnull(lnIntressiSumma ,0);
-- intressi laekumised

select sum(summa) into lnTasuSumma from dekltasu where deklid in (select id from toiming where parentid = tnAsutusId and staatus > 0 and tyyp = 'INTRESS');
lnTasuSumma = ifnull(lnTasuSumma,0);
*/

select sum(jaak) into lnIntressiSumma from (
select fncDeklJaak(id) as jaak from toiming where parentid = tnAsutusId and tyyp = 'INTRESS' and kpv >= date(2011,01,01) and staatus > 0
) tmpJaak;

lnIntressiSumma = ifnull(lnIntressiSumma,0);

return lnIntressiSumma;
--- lnTasuSumma;
end;


$$;

ALTER FUNCTION fncreklintressijaak(INTEGER) OWNER TO vlad;

