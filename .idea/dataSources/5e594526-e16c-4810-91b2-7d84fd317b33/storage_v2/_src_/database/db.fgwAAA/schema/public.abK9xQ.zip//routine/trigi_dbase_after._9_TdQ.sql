CREATE FUNCTION trigi_dbase_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin

         select new.id, "DBASE" as tbl

end;

$$;

ALTER FUNCTION trigi_dbase_after() OWNER TO vlad;

