CREATE FUNCTION sp_calc_tahtpaevad(integer, integer) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
DECLARE tnRekvId alias for $1;

	tnKuu alias for $2;

	lnTunnid int2;

begin



	SELECT count(id) into lnTunnid FROM holidays WHERE rekvid = tnRekvid and kuu = tnKuu  AND luhipaev = 1;

	lnTunnid := 3 * lnTunnid;



	RETURN lnTunnid;

end;


$$;

ALTER FUNCTION sp_calc_tahtpaevad(INTEGER, INTEGER) OWNER TO vlad;

