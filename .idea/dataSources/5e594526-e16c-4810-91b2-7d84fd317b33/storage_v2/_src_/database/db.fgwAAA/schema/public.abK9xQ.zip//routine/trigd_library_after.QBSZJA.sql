CREATE FUNCTION trigd_library_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	lnuserid int;

begin

	if old.library = 'KONTOD' then



		DELETE FROM kontoinf WHERE parentid = old.Id;



		DELETE FROM subkonto WHERE KontoId = old.Id;



		DELETE FROM tunnusinf WHERE kontoid = old.Id;



	end if;

	if old.library = 'KONTOD' then



		DELETE FROM tunnusinf WHERE tunnusid = old.Id;



	end if;

	if old.library = 'POHIVARA' then



		DELETE FROM pv_kaart WHERE parentid = old.Id;

		DELETE FROM pv_oper WHERE parentid = old.Id;



	end if;



	if old.library = 'AMET' then

		delete from palk_asutus where ametid = old.id;

	END IF;

	if old.library = 'PALK' then

		delete from palk_lib where parentid = old.id;

	END IF;

--	perform sp_register_oper(old.rekvid,old.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, old.rekvid));



return null;



end;

$$;

ALTER FUNCTION trigd_library_after() OWNER TO vlad;

