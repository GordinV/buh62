CREATE FUNCTION trigd_pv_kaart_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	v_userid record;
	lresult int;
	lcNotice varchar;
begin

	delete from pv_oper where parentId = old.parentId;
	perform sp_register_oper(0,old.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, 0));
	return null;
end;
$$;

ALTER FUNCTION trigd_pv_kaart_after() OWNER TO vlad;

