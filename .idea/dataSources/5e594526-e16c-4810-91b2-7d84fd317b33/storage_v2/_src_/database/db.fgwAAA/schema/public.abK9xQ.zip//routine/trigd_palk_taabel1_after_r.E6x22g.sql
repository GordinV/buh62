CREATE FUNCTION trigd_palk_taabel1_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:='toolepingid:' + old.toolepingid::TEXT + '

' +

	'kokku:' + old.kokku::TEXT + '

' +

	'too:' + old.too::TEXT + '

' +

	'paev:' + old.paev::TEXT + '

' +

	'ohtu:' + old.ohtu::TEXT + '

' +

	'oo:' + old.oo::TEXT + '

' +

	'tahtpaev:' + old.tahtpaev::TEXT + '

' +

	'puhapaev:' + old.puhapaev::TEXT + '

' +

	'kuu:' + old.kuu::TEXT + '

' +

	'aasta:' + old.aasta::TEXT + '

' +

	'muud:' + case when ifnull(old.muud,space(1))<>space(1) then 

		old.muud::TEXT + '

' else ' ' end +

	'uleajatoo:' + old.uleajatoo::TEXT + '

';

	

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (0,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,old.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigd_palk_taabel1_after_r() OWNER TO vlad;

