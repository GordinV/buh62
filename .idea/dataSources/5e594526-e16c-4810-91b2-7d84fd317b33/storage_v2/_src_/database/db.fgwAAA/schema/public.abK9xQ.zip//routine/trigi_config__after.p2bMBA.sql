CREATE FUNCTION trigi_config__after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin

	UPDATE DBASE SET LASTNUM = NEW.ID WHERE id = 89;	 

	return NULL;

end;

$$;

ALTER FUNCTION trigi_config__after() OWNER TO vlad;

