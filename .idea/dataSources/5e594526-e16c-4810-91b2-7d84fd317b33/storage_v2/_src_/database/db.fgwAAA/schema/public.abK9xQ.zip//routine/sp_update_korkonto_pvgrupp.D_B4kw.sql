CREATE FUNCTION sp_update_korkonto_pvgrupp(integer, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare


	tnGruppId alias for $1;


	tnKorKonto alias for $2;


	cKood varchar;


begin

	SELECT kood into cKood FROM library WHERE id = tnKorKonto ;


	UPDATE pv_kaart SET konto = ckood WHERE gruppid = tnGruppId;


	if found then 


		return 1;


	else


		return 0;


	end if;


end;

$$;

ALTER FUNCTION sp_update_korkonto_pvgrupp(INTEGER, INTEGER) OWNER TO vlad;

