CREATE FUNCTION trigiu_pv_oper_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	lresult int;

	lcNotice varchar;

begin

	lresult := 1;



	lcNotice = ' ';

	if empty (new.nomid) then

		lcNotice := 'Nomenklatturi kood';

	end if;

	if empty (new.parentid) then

		lcNotice := LcNotice + ' Pv kaardi Id number';

	end if;

	if empty (new.liik) then

		lcNotice := LcNotice + ' Operatsioonide liik';

	end if;

	if empty (new.liik) then

		lcNotice := LcNotice + ' Operatsioonide kuupaev';

	end if;

	if not empty (lcNotice) then

		lresult := 0;

		lcNotice := 'Puudub vajalikud andmed'+space(1)+lcNotice+space(1)+CURRENT_USER::varchar;

	end if;



	if lResult = 0 then

		raise exception 'Viga: %',lcNotice;

		return null;

	else

		return new;

	end if;

end;

$$;

ALTER FUNCTION trigiu_pv_oper_before() OWNER TO vlad;

