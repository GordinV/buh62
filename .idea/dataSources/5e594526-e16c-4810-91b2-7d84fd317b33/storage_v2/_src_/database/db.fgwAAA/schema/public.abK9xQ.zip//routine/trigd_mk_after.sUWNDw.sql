CREATE FUNCTION trigd_mk_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	lnId int;
	lnreturn int;
begin
delete from mk1 where parentid = old.id;	
SELECT count(id) into lnid FROM  Arvtasu WHERE Arvtasu.pankkassa = 1  AND Arvtasu.sorderid = old.Id;
if lnId > 0 then
	SELECT id into lnid FROM  Arvtasu WHERE Arvtasu.pankkassa = 1  AND Arvtasu.sorderid = old.Id;
	lnreturn:=sp_del_tasud (lnId,1);
end if;
perform sp_register_oper(old.rekvid,old.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, old.rekvid));
return null;

end;
$$;

ALTER FUNCTION trigd_mk_after() OWNER TO vlad;

