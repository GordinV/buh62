CREATE FUNCTION isdigit(character varying) RETURNS integer
    LANGUAGE plpgsql
AS
$$
DECLARE tcChar alias for $1;
	lnresult int;
	lnCount int;
begin
	lnresult = 0;
	lnCount = 0;
	loop
		if lnCount::varchar(1) = left(ltrim(rtrim(tcChar)),1)::varchar(1) then
--			raise notice 'digit';
			lnresult = 1;
		end if;
		if lnCount = 9 or lnresult = 1 then
			exit;
		end if;
		
		lnCount = lnCount + 1;
	end loop;

         return  lnResult;
end;
$$;

ALTER FUNCTION isdigit(VARCHAR) OWNER TO vlad;

