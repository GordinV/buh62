CREATE FUNCTION trigi_vastisikud_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin

	UPDATE DBASE SET LASTNUM = NEW.ID WHERE id = 147;	 

	return NULL;

end;

$$;

ALTER FUNCTION trigi_vastisikud_after() OWNER TO vlad;

