CREATE FUNCTION trigd_eelarve_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	lnCount int4;


	v_userid record;


begin


	select * into v_userid from userid where kasutaja = current_user::varchar and rekvid = old.rekvid;


	if not found then


		raise exception 'Ei saa kustuta';


		return NULL;

	else


		return OLD;


	end if;


end;

$$;

ALTER FUNCTION trigd_eelarve_before() OWNER TO vlad;

