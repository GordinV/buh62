CREATE FUNCTION sp_salvesta_hooleping(integer, integer, integer, integer, character varying, integer, date, date, numeric, numeric, text) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	tnid alias for $1;
	tnrekvid alias for $2;
	tnIsikId alias for $3;
	tnhooldekoduid alias for $4;
	tcNumber alias for $5;
	tnOmavalitsusId alias for $6;
	tdAlgkpv alias for $7;
	tdLoppkpv alias for $8;
	tnSumma alias for $9;
	tnOsa alias for $10;
	ttmuud alias for $11;

	lnId int; 
	lrCurRec record;

begin
raise notice 'tdAlgkpv %',tdAlgkpv;
if tnId = 0 then
	-- uus kiri
	insert into hooleping( rekvid,isikid, hooldekoduid,number, omavalitsus, omavalitsusId, algkpv,loppkpv, muud,summa,osa) 
		values (tnrekvid,tnisikid, tnhooldekoduid,tcnumber,space(1), tnomavalitsusId, tdalgkpv,tdloppkpv, ttmuud,tnsumma,tnosa);

	lnId:= cast(CURRVAL('public.hooleping_id_seq') as int4);

else
	-- muuda 
	update hooleping set 
		isikid = tnIsikId, 
		hooldekoduid = tnhooldekoduid,
		number = tcNumber, 
		omavalitsusid = tnomavalitsusId, 
		algkpv = tdalgkpv,
		loppkpv = tdloppkpv, 
		muud = ttMuud,
		summa = tnSumma,
		osa = tnOsa
	where id = tnId;

	lnId := tnId;

end if;
return  lnId;

end;
$$;

ALTER FUNCTION sp_salvesta_hooleping(INTEGER, INTEGER, INTEGER, INTEGER, VARCHAR, INTEGER, DATE, DATE, NUMERIC, NUMERIC, TEXT) OWNER TO vlad;

