CREATE FUNCTION recalc_parhind() RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare

	v_pv record;

	lnSumma numeric(14,4);

	

       lcString varchar;

begin

	for v_pv in select * from curPohivara 

	loop

		select sum(summa) into lnSumma from pv_oper where parentId = v_pv.id and liik = 3;

		update pv_kaart set parhind = v_pv.soetmaks + ifnull(lnSumma,0) where parentid = v_pv.id; 

	End loop;

	

     return 1;

end;

$$;

ALTER FUNCTION recalc_parhind() OWNER TO vlad;

