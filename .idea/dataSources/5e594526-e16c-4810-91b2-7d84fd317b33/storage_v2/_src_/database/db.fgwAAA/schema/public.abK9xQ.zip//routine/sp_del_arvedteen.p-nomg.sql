CREATE FUNCTION sp_del_arvedteen(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 


	tnId alias for $1;



begin


	Return sp_del_arved(tnid);


end;


$$;

ALTER FUNCTION sp_del_arvedteen(INTEGER, INTEGER) OWNER TO vlad;

