CREATE FUNCTION empty(numeric) RETURNS boolean
    LANGUAGE plpgsql
AS
$$
begin


	if $1 is null or $1 = 0 then


		return true;


	else


		return false;


	end if;


end;


$$;

ALTER FUNCTION empty(NUMERIC) OWNER TO vlad;

