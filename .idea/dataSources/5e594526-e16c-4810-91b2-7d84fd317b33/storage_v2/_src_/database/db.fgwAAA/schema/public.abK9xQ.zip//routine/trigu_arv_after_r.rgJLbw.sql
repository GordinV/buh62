CREATE FUNCTION trigu_arv_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:=

	case when old.rekvid <> new.rekvid then 

		'rekvid:' + old.rekvid::text + '

'  else ''

	end +

	

	case when old.userid <> new.userid then 

		'userid:' + old.userid::text + '

'  else ''

	end +

	

	case when old.journalid <> new.journalid then 

		'journalid:' + old.journalid::text + '

'  else ''

	end +

	

	case when old.doklausid <> new.doklausid then 

		'doklausid:' + old.doklausid::text + '

'  else ''

	end +

	

	case when old.liik <> new.liik then 

		'liik:' + old.liik::text + '

'  else ''

	end +

	

	case when old.operid <> new.operid then 

		'operid:' + old.operid::text + '

'  else ''

	end +

	

	case when old.number <> new.number then 

		'number:' + old.number::text + '

'  else ''

	end +

	

	case when old.kpv <> new.kpv then 

		'kpv:' + dtoc(old.kpv) + '

'  else ''

	end +

	

	case when old.asutusid <> new.asutusid then 

		'asutusid:' + old.asutusid::text + '

'  else ''

	end +

	

	case when old.arvid <> new.arvid then 

		'arvid:' + old.arvid::text + '

'  else ''

	end +

	

	case when old.lisa <> new.lisa then 

		'lisa:' + old.lisa::text + '

'  else ''

	end +

	

	case when old.tahtaeg <> new.tahtaeg or (IfNull(old.tahtaeg,date(1900,01,01)) <> IfNull(new.tahtaeg,date(1900,01,01))) then 

		'tahtaeg:' + case when ifNull(old.tahtaeg,date(1900,01,01)) = date(1900,01,01) then space(1) + '

'  else dtoc(old.tahtaeg) +  '

'  end else ''

	end +

	

	case when old.kbmta <> new.kbmta then 

		'kbmta:' + old.kbmta::text + '

'  else ''

	end +

	

	case when old.kbm <> new.kbm then 

		'kbm:' + old.kbm::text + '

'  else ''

	end +

	

	case when old.summa <> new.summa then 

		'summa:' + old.summa::text + '

'  else ''

	end +

	

	case when old.tasud <> new.tasud or (IfNull(old.tasud,date(1900,01,01)) <> IfNull(new.tasud,date(1900,01,01))) then 

		'tasud:' + case when ifNull(old.tasud,date(1900,01,01)) = date(1900,01,01) then space(1) + '

'  else dtoc(old.tasud) +  '

'  end else ''

	end +

	

	case when old.tasudok <> new.tasudok or (IfNull(old.tasudok,space(1)) <> IfNull(new.tasudok,space(1))) then 

		'tasudok:' + case when ifNull(old.tasudok,space(1)) = space(1) then space(1) + '

'  else old.tasudok::text + '

'  end else ''

	end +

	

	case when old.muud <> new.muud or (IfNull(old.muud,space(1)) <> IfNull(new.muud,space(1))) then 

		'muud:' + case when ifNull(old.muud,space(1)) = space(1) then space(1) + '

'  else old.muud::text + '

'  end else ''

	end +

	

	case when old.jaak <> new.jaak then 

		'jaak:' + old.jaak::text + '

'  else ''

	end +

	

	case when old.objektid <> new.objektid then 

		'objektid:' + old.objektid::text + '

'  else ''

	end;

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (new.rekvid,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,new.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigu_arv_after_r() OWNER TO vlad;

