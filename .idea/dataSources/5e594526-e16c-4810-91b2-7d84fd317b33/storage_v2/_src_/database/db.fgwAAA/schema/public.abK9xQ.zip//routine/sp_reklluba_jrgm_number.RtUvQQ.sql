CREATE FUNCTION sp_reklluba_jrgm_number(integer) RETURNS character varying
    LANGUAGE plpgsql
AS
$$
declare 



	tnRekvId alias for $1;

	lcresult varchar;



begin

	select left(number,2) into lcResult  from luba where rekvid = tnRekvid order by left(ltrim(rtrim(number)),7) desc limit 1;



	Return ifnull(lcresult,space(2));



end;


$$;

ALTER FUNCTION sp_reklluba_jrgm_number(INTEGER) OWNER TO vlad;

