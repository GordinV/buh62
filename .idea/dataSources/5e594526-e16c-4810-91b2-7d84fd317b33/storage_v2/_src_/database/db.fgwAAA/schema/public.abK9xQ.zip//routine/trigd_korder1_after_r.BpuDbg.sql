CREATE FUNCTION trigd_korder1_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:='rekvid:' + old.rekvid::TEXT + '

' +

	'userid:' + old.userid::TEXT + '

' +

	'journalid:' + old.journalid::TEXT + '

' +

	'kassaid:' + old.kassaid::TEXT + '

' +

	'tyyp:' + old.tyyp::TEXT + '

' +

	'doklausid:' + old.doklausid::TEXT + '

' +

	'number:' + old.number + '

' +

	'kpv:'+ old.kpv::TEXT + '

' +

	'asutusid:' + old.asutusid::TEXT + '

' +

	'nimi:' + old.nimi + '

' +

	'aadress:' + old.aadress + '

' +

	'dokument:' + old.dokument + '

' +

	'alus:' + old.alus + '

' +

	'summa:' + old.summa::TEXT + '

' +

	'muud:' + case when ifnull(old.muud,space(1))<>space(1) then 

		old.muud::TEXT + '

' else ' ' end +

	'arvid:' + old.arvid::TEXT + '

' +

	'doktyyp:' + old.doktyyp::TEXT + '

' +

	'dokid:' + old.dokid::TEXT + '

';

	

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (old.rekvid,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,old.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigd_korder1_after_r() OWNER TO vlad;

