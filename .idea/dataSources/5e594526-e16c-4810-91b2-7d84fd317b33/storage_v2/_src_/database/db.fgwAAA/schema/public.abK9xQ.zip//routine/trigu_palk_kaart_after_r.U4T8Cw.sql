CREATE FUNCTION trigu_palk_kaart_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:=

	case when old.parentid <> new.parentid then 

		'parentid:' + old.parentid::text + '

'  else ''

	end +

	

	case when old.lepingid <> new.lepingid then 

		'lepingid:' + old.lepingid::text + '

'  else ''

	end +

	

	case when old.libid <> new.libid then 

		'libid:' + old.libid::text + '

'  else ''

	end +

	

	case when old.summa <> new.summa then 

		'summa:' + old.summa::text + '

'  else ''

	end +

	

	case when old.percent_ <> new.percent_ then 

		'percent_:' + old.percent_::text + '

'  else ''

	end +

	

	case when old.tulumaks <> new.tulumaks then 

		'tulumaks:' + old.tulumaks::text + '

'  else ''

	end +

	

	case when old.tulumaar <> new.tulumaar then 

		'tulumaar:' + old.tulumaar::text + '

'  else ''

	end +

	

	case when old.status <> new.status then 

		'status:' + old.status::text + '

'  else ''

	end +

	

	case when old.muud <> new.muud or (IfNull(old.muud,space(1)) <> IfNull(new.muud,space(1))) then 

		'muud:' + case when ifNull(old.muud,space(1)) = space(1) then space(1) + '

'  else old.muud::text + '

'  end else ''

	end +

	

	case when old.alimentid <> new.alimentid then 

		'alimentid:' + old.alimentid::text + '

'  else ''

	end +

	

	case when old.tunnusid <> new.tunnusid then 

		'tunnusid:' + old.tunnusid::text + '

'  else ''

	end;

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (0,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,new.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigu_palk_kaart_after_r() OWNER TO vlad;

