CREATE FUNCTION trigu_toiming_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	v_userid record;

	lresult int;

	lcNotice varchar;

	lnrekvId int = 28; -- Narva Linna Arengu
	

begin

	if new.tyyp = 'DEKL' then

		if old.staatus = 1 and new.tyyp = 'DEKL' then

			-- vaba

			raise notice 'vaba';

			return new;

		else

			if old.staatus > 1 and new.staatus <> old.staatus  then

				-- parandame staatus, lubatud

				raise notice 'parandame staatus, lubatud';

				return new;

--			else

--				raise exception 'Ei saa parandada deklaratsioon sest oli tasud';

--				return null;

			end if;

		end if;





	end if;

	-- kontrollime dekl. kpv. Kui period on suletud, siis ei saa parandada v.a. proa. N. Smelova
		if (fnc_aasta_kontrol(lnrekvId, old.kpv)= 1 or (CURRENT_USER::varchar = 'natalja.smelova' 
				or CURRENT_USER::varchar = 'niina.krolova'
				) ) then
			raise notice 'Parandamine on lubatud';

		else
			raise exception 'Viga: Perion on kinnitatud';
			return null;
		
		end if;

	return new;

end;

$$;

ALTER FUNCTION trigu_toiming_before() OWNER TO vlad;

