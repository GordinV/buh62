CREATE FUNCTION trigiu_arvtasu_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin



	perform docs.sp_update_arv_jaak(new.doc_arv_Id, new.Kpv);

	return null;



end;

$$;

ALTER FUNCTION trigiu_arvtasu_after() OWNER TO vlad;

