CREATE FUNCTION trigiu_vanemtasu4_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 


	lnCount int4;
	lcTunnus varchar(20);






begin

	

	select *  into lcTunnus from vanemtasu3 where id = new.parentid;
	

	select count(*) into lnCount from vanemtasu2 where isikId = new.isikId and tunnus = lcTunnus;




	if ifnull(lnCount,0) = 0 then



		raise notice 'Ei ole registreeritud asutuses';


		return NULL;


	else



		return NEW;



	end if;



end;


$$;

ALTER FUNCTION trigiu_vanemtasu4_before() OWNER TO vlad;

