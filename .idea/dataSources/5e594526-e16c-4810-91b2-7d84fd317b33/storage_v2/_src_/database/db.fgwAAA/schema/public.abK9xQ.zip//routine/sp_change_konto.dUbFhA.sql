CREATE FUNCTION sp_change_konto(character varying, character varying) RETURNS integer
    LANGUAGE plpgsql
AS
$$
/* New function body */

declare

       tcVanaKonto alias for $1;

       tcUusKonto alias for $2;

       lnLiik int;

begin

	Select liik into lnLiik From Library INNER Join kontoinf On kontoinf.parentId = Library.Id

		where Ltrim ( Rtrim ( Library.kood ) )  = Ltrim ( Rtrim ( tcuuskonto ) );

  lnLiik =  ifnull(lnLiik,0);

	If lnliik = 2 then

		Update kontoinf Set pohikonto = tcuuskonto

			where Ltrim ( Rtrim ( pohikonto) )  = Ltrim ( Rtrim ( tcvanakonto) );

	End if;

	Update saldo Set konto = tcuuskonto

		where Ltrim ( Rtrim ( konto ) )  = Ltrim ( Rtrim ( tcvanakonto ) );



	Update arv1 Set konto = tcuuskonto

		where Ltrim ( Rtrim ( konto ) )  = Ltrim ( Rtrim ( tcvanakonto ) );



	Update doklausend Set deebet = tcuuskonto

		where Ltrim ( Rtrim ( deebet ) )  = Ltrim ( Rtrim ( tcvanakonto ) );



	Update doklausend Set kreedit = tcuuskonto

		where Ltrim ( Rtrim ( kreedit ) )  = Ltrim ( Rtrim ( tcvanakonto ) );



	Update dokprop Set konto = tcuuskonto

		where Ltrim ( Rtrim ( konto ) )  = Ltrim ( Rtrim ( tcvanakonto ) );

	Update dokprop Set kbmkonto = tcuuskonto

		where Ltrim ( Rtrim ( kbmkonto ) )  = Ltrim ( Rtrim ( tcvanakonto ) );

	Update gruppomandus Set konto = tcuuskonto

		where Ltrim ( Rtrim ( konto ) )  = Ltrim ( Rtrim ( tcvanakonto ) );

	Update journal1 Set deebet = tcuuskonto

		where Ltrim ( Rtrim ( deebet ) )  = Ltrim ( Rtrim ( tcvanakonto ) );

	Update journal1 Set kreedit = tcuuskonto

		where Ltrim ( Rtrim ( kreedit ) )  = Ltrim ( Rtrim ( tcvanakonto ) );

	Update klassiflib Set konto = tcuuskonto

		where Ltrim ( Rtrim ( konto ) )  = Ltrim ( Rtrim ( tcvanakonto ) );

	Update korder2 Set konto = tcuuskonto

		where Ltrim ( Rtrim ( konto ) )  = Ltrim ( Rtrim ( tcvanakonto ) );

	Update mk1 Set konto = tcuuskonto

		where Ltrim ( Rtrim ( konto ) )  = Ltrim ( Rtrim ( tcvanakonto ) );

	Update palk_lib Set konto = tcuuskonto

		where Ltrim ( Rtrim ( konto ) )  = Ltrim ( Rtrim ( tcvanakonto ) );

	Update palk_oper Set konto = tcuuskonto

		where Ltrim ( Rtrim ( konto ) )  = Ltrim ( Rtrim ( tcvanakonto ) );

	Update pv_oper Set konto = tcuuskonto

		where Ltrim ( Rtrim ( konto ) )  = Ltrim ( Rtrim ( tcvanakonto ) );

  return 1;

end;

$$;

ALTER FUNCTION sp_change_konto(VARCHAR, VARCHAR) OWNER TO vlad;

