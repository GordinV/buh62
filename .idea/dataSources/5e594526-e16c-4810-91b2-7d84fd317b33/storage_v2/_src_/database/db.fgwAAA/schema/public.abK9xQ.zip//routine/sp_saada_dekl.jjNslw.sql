CREATE FUNCTION sp_saada_dekl(integer, date) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	tnid alias for $1;
	tdKpv alias for $2;

	lnResult int; 

	lnJournalid int;
begin
	lnresult = 1;
--	raise notice 'status: %',tnStaatus;
	update toiming set saadetud = tdKpv where id = tnid;
	perform sp_recalc_rekljaak(tnid);

	perform sp_muuda_deklstaatus(tnId, 1);

	
	lnJournalId = gen_lausend_reklmaks(tnId);


return  lnResult;
end;
$$;

ALTER FUNCTION sp_saada_dekl(INTEGER, DATE) OWNER TO vlad;

