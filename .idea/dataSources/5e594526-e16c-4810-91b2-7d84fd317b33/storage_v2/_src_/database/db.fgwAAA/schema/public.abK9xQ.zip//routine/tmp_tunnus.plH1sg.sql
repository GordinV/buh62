CREATE FUNCTION tmp_tunnus() RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare v_tunnus record;

	

begin


	for v_tunnus in select * from library where library = 'TUNNUS'
	loop		

		insert into tunnusinf (tunnusid, kontoid, rekvid)

		select v_tunnus.id as tunnusId, library.id, v_tunnus.rekvId from library where library = 'KONTOD';

	End loop;


	return 1;
end;
$$;

ALTER FUNCTION tmp_tunnus() OWNER TO vlad;

