CREATE FUNCTION sp_del_autod(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 


	tnId alias for $1;



begin


	delete from autod where id = tnId;


	if found then


		return 1;


	else


		return 0;


	end if;


end;


$$;

ALTER FUNCTION sp_del_autod(INTEGER, INTEGER) OWNER TO vlad;

