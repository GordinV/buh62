CREATE FUNCTION trigd_luba_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare
lnKinni int;

lnCount int;
v_userid record;

begin
	select * into v_userid from userid where id = sp_currentuser(CURRENT_USER::varchar, old.rekvid);
	if empty (v_userid.kasutaja_) and empty (v_userid.peakasutaja_) then
			raise exception 'Ei ole Ćµigused lisada/muudata/kustuta';
			return null;
	end if;

/*
	select count(*) into lnCount from toiming where lubaid = old.id and tyyp in ('TASU','INTRESS','KORRALDUS') and staatus > 0;

	if ifnull(lnCount,0) > 0 then

			raise exception 'Luba on lukkustatud';

			return null;

	end if;

*/


	return OLD;


end;
$$;

ALTER FUNCTION trigd_luba_before() OWNER TO vlad;

