CREATE FUNCTION trigd_pv_oper_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	lnCount int4;

	lnSumma numeric(14,2);



begin





	if old.liik = 4 then



		update pv_kaart set tunnus = 1,



			mahakantud = NULL where parentid = old.parentid;



	end if;



	update pv_oper set journalid = 0 where id = old.id;



	if old.journalid > 0 then

		lnCount:= sp_del_journal(old.journalid,1);



	end if;

/*
	lnSumma =  get_pv_summa(old.parentid);



	update pv_kaart set parhind = ifnull(lnSumma,0) where parentid = old.parentid;



*/
	perform sp_update_pv_jaak(old.parentid);



	perform sp_register_oper(0,old.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, 0));



	return NULL;

end;

$$;

ALTER FUNCTION trigd_pv_oper_after() OWNER TO vlad;

