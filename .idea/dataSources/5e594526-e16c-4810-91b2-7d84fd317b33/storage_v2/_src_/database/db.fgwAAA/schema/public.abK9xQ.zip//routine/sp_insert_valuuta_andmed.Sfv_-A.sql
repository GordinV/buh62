CREATE FUNCTION sp_insert_valuuta_andmed() RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare

	v_toiming record;
	 lnResult integer;

begin
	 lnResult = 0;

	for v_toiming in 
		select * from toiming where kpv >= date(2011,01,01) and id not in (select dokid from dokvaluuta1 where dokliik = 15)

	loop
		if (select count(id) from dokvaluuta1 where dokliik = 15 and dokid = v_toiming.id) = 0 then
			raise notice ' insert id %',v_toiming.id;
			insert into dokvaluuta1 (dokid, dokliik, valuuta, kuurs,  muud) values 
				(v_toiming.id, 15, 'EUR',15.6466, 'Parandus');
			
			lnResult =  lnResult + 1;	
		end if;
	end loop;



return  lnResult;

end;

$$;

ALTER FUNCTION sp_insert_valuuta_andmed() OWNER TO vlad;

