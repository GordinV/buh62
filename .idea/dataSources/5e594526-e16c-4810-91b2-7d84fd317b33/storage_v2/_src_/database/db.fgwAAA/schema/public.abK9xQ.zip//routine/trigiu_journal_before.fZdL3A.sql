CREATE FUNCTION trigiu_journal_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	v_userid record;
	lresult int;
	lcNotice varchar;
	lnuserId int4;
	lnKinni int;
	ldAsutusekehtivus DATE;
begin
		

	select kinni into lnKinni from aasta where kuu = month(new.kpv)  and aasta = year(new.kpv)
			and rekvid = new.rekvId ;

	lnKinni :=ifnull(lnkinni,0);

	if lnKinni = 0 and TG_OP = 'UPDATE' then
		select kinni into lnKinni from aasta where kuu = month(old.kpv)  and aasta = year(old.kpv)
			and rekvid = old.rekvId ;

		lnKinni :=ifnull(lnkinni,0);
	end if;
	
		if lnKinni = 1 then
			raise exception 'Viga: Period on kinnitatud';

			RETURN NULL;
		end if;
		
	lnUserid = sp_currentuser(current_user::varchar, new.rekvid);
	select * into v_userid from userid where id = lnUserid;
	if v_userid.kasutaja_ = 0 and v_userid.peakasutaja_ = 0 then
			raise exception 'Ei ole Ćµigused lisada/muudata/kustuta';
			return null;
	end if;
	-- asutused kontrol
	/*
	if new.asutusid > 0 then
		select fnc_ntod(rekvid) into ldAsutusekehtivus from asutus where id = new.asutusid;
		if new.kpv > ifnull(ldAsutusekehtivus,date()) then
			raise exception 'Asutus ei kehti ';
			return null;
		end if;
	end if;
	*/


	return new;
end;
$$;

ALTER FUNCTION trigiu_journal_before() OWNER TO vlad;

