CREATE FUNCTION trigd_arv_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:='rekvid:' + old.rekvid::TEXT + '

' +

	'userid:' + old.userid::TEXT + '

' +

	'journalid:' + old.journalid::TEXT + '

' +

	'doklausid:' + old.doklausid::TEXT + '

' +

	'liik:' + old.liik::TEXT + '

' +

	'operid:' + old.operid::TEXT + '

' +

	'number:' + old.number + '

' +

	'kpv:'+ old.kpv::TEXT + '

' +

	'asutusid:' + old.asutusid::TEXT + '

' +

	'arvid:' + old.arvid::TEXT + '

' +

	'lisa:' + old.lisa + '

' +

	'tahtaeg:'+ case when ifnull(old.tahtaeg,date(1900,01,01))<>date(1900,01,01) then 

		dtoc(old.tahtaeg) + '

' else '' end +

	'kbmta:' + old.kbmta::TEXT + '

' +

	'kbm:' + old.kbm::TEXT + '

' +

	'summa:' + old.summa::TEXT + '

' +

	'tasud:'+ case when ifnull(old.tasud,date(1900,01,01))<>date(1900,01,01) then 

		dtoc(old.tasud) + '

' else '' end +

	'tasudok:' + case when ifnull(old.tasudok,space(1))<>space(1) then 

		old.tasudok::TEXT + '

' else ' ' end +

	'muud:' + case when ifnull(old.muud,space(1))<>space(1) then 

		old.muud::TEXT + '

' else ' ' end +

	'jaak:' + old.jaak::TEXT + '

' +

	'objektid:' + old.objektid::TEXT + '

';

	

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (old.rekvid,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,old.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigd_arv_after_r() OWNER TO vlad;

