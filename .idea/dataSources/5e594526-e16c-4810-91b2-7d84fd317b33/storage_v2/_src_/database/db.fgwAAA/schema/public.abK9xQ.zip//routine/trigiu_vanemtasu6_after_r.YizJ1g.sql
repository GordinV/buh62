CREATE FUNCTION trigiu_vanemtasu6_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	v_userid record;

	lresult int;

	lcNotice varchar;

	lnRekvid int;

begin

	

	select rekvid into lnrekvid from vanemtasu5 where id = new.parentid;

	perform sp_register_oper(LNrekvid,new.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, lnrekvid));

	return null;

end;

$$;

ALTER FUNCTION trigiu_vanemtasu6_after_r() OWNER TO vlad;

