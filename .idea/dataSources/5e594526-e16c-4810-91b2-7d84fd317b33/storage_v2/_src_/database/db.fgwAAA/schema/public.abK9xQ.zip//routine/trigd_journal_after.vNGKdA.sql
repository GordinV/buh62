CREATE FUNCTION trigd_journal_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	v_userid record;
	lresult int;
	lcNotice varchar;

	v_journal1 record;

	lnSaldoId int;
begin

	/*

	for v_journal1 in select * from journal1 where parentid = old.Id

	loop



		-- debet 

		update saldo set dbkaibed = dbkaibed - v_journal1.summa

			where konto = v_journal1.deebet

			and asutusId = old.asutusId

			and kuu = month(old.kpv)

			and aasta = year(old.kpv)

			and ltrim(rtrim(tunnus)) = ltrim(rtrim(v_journal1.tunnus));

	

		-- kreedit 

		update saldo set krkaibed = krkaibed - v_journal1.summa

			where konto = v_journal1.kreedit

			and asutusId = old.asutusId

			and kuu = month(old.kpv)

			and aasta = year(old.kpv)

			and ltrim(rtrim(tunnus)) = ltrim(rtrim(v_journal1.tunnus));



	End loop;

	

--	delete from saldo where dbkaibed = 0 and krkaibed = 0;

*/
	delete from journal1 where parentId = old.id;



	perform sp_register_oper(old.rekvid,old.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, old.rekvid));


	return null;
end;
$$;

ALTER FUNCTION trigd_journal_after() OWNER TO vlad;

