CREATE FUNCTION trigd_palk_kaart_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	v_userid record;
	lresult int;
	lcNotice varchar;
begin
	select count(*) into lresult from palk_oper where lepingId = old.lepingId and libId = old.libid;

	if ifnull(lresult,0) > 0 then

		raise exception 'Ei saa kustuta';
		return old;

--		return null;

	else

		return old;

	end if;
end;
$$;

ALTER FUNCTION trigd_palk_kaart_before() OWNER TO vlad;

