CREATE FUNCTION sp_salvesta_counter(integer, integer, date, numeric, numeric, text) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	tnid alias for $1;
	tnparentid alias for $2;
	tdKpv alias for $3;
	tnAlgkogus alias for $4;
	tnLoppKogus alias for $5;
	ttMuud alias for $6;
	lnLastNait numeric(14,4);


	lnId int; 
--	lrCurRec record;
begin

	if tnId = 0 then
			-- lisame uus kiri
		insert into counter (parentid, kpv, algkogus, loppkogus, muud)
			values (tnparentid, tdkpv, tnalgkogus, tnloppkogus, ttmuud);
	else
		update counter set
			kpv = tdKpv,
			algkogus = tnAlgKogus,
			loppkogus = tnLoppKogus,
			muud = ttMuud
		where id = tnId;

	end if;
	
	select loppkogus into lnLastNait from counter where parentid = tnParentid order by kpv desc limit 1;

	lnLastNait = ifnull(lnLastNait,tnLoppKogus);
	
	update library set tun5 = lnLastNait where id = tnParentId;


         return  tnId;
end;
$$;

ALTER FUNCTION sp_salvesta_counter(INTEGER, INTEGER, DATE, NUMERIC, NUMERIC, TEXT) OWNER TO vlad;

