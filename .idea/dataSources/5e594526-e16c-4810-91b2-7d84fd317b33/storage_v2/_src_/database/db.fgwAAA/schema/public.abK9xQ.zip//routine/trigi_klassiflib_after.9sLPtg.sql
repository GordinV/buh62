CREATE FUNCTION trigi_klassiflib_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin

	UPDATE DBASE SET LASTNUM = NEW.ID WHERE id = 101;	 

	return NULL;

end;

$$;

ALTER FUNCTION trigi_klassiflib_after() OWNER TO vlad;

