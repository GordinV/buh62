CREATE FUNCTION trigu_avans1_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:=

	case when old.rekvid <> new.rekvid then 

		'rekvid:' + old.rekvid::text + '

'  else ''

	end +

	

	case when old.userid <> new.userid then 

		'userid:' + old.userid::text + '

'  else ''

	end +

	

	case when old.asutusid <> new.asutusid then 

		'asutusid:' + old.asutusid::text + '

'  else ''

	end +

	

	case when old.kpv <> new.kpv then 

		'kpv:' + dtoc(old.kpv) + '

'  else ''

	end +

	

	case when old.number <> new.number then 

		'number:' + old.number::text + '

'  else ''

	end +

	

	case when old.selg <> new.selg then 

		'selg:' + old.selg::text + '

'  else ''

	end +

	

	case when old.journalid <> new.journalid then 

		'journalid:' + old.journalid::text + '

'  else ''

	end +

	

	case when old.dokpropid <> new.dokpropid then 

		'dokpropid:' + old.dokpropid::text + '

'  else ''

	end +

	

	case when old.muud <> new.muud or (IfNull(old.muud,space(1)) <> IfNull(new.muud,space(1))) then 

		'muud:' + case when ifNull(old.muud,space(1)) = space(1) then space(1) + '

'  else old.muud::text + '

'  end else ''

	end;

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (new.rekvid,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,new.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigu_avans1_after_r() OWNER TO vlad;

