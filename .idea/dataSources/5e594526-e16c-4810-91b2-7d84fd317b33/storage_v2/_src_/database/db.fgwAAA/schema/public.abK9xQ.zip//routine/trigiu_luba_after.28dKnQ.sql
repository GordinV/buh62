CREATE FUNCTION trigiu_luba_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare
lnKinni int;

lnCount int;
v_userid record;

begin
--	PERFORM sp_recalc_rekljaak(new.id);
	return NULL;


end;
$$;

ALTER FUNCTION trigiu_luba_after() OWNER TO vlad;

