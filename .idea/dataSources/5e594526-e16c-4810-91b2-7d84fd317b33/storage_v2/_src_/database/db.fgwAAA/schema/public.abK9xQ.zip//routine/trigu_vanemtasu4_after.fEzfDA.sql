CREATE FUNCTION trigu_vanemtasu4_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 



	v_userid record;



	lresult int;



	lcNotice varchar;





	v_vanemtasu3 record;



begin





	select *  into v_vanemtasu3 from vanemtasu3 where id = new.parentId;











	if old.isikid <> new.isikId then





		perform sp_calc_vanemtasu_jaak(v_vanemtasu3.rekvid, old.isikId);











	end if;









	perform sp_calc_vanemtasu_jaak(v_vanemtasu3.rekvid, new.isikId);











	perform sp_register_oper(v_vanemtasu3.rekvid,new.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, v_vanemtasu3.rekvid));



	return null;



end;


$$;

ALTER FUNCTION trigu_vanemtasu4_after() OWNER TO vlad;

