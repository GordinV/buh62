CREATE FUNCTION trigu_journal1_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	lnKontoId int4;

	lnId int4;

	v_journal record;

	lnSaldoId int4;

	lnKuu int;

	lnAasta int;

	ldKpv date;

	tmpJournal record;

begin

	select * into v_journal from journal where id = new.parentid;

	-- kontrolin deebet

	select id into lnKontoid from library where kood = new.deebet and library = 'KONTOD';

	select id into lnId from subkonto 

	where asutusid = v_journal.asutusid 

	and kontoid = lnKontoid

	and rekvid = v_journal.rekvid;



	if not found and ifnull(lnKontoid,0) > 0 and ifnull(v_journal.Asutusid,0) > 0 then

		Insert Into subkonto (algsaldo, rekvid, aasta, kontoid, Asutusid) Values 

		(0, v_journal.rekvId, year(v_journal.kpv),lnKontoId, v_journal.Asutusid);

	end if;



	-- kontrolin kreedit



	select id into lnKontoid from library where kood = new.kreedit and library = 'KONTOD';

	select id into lnId from subkonto 

	where asutusid = v_journal.asutusid 

	and kontoid = lnKontoid

	and rekvid = v_journal.rekvid;

	if not found and ifnull(lnKontoid,0) > 0 and ifnull(v_journal.Asutusid,0) > 0 then

		Insert Into subkonto (algsaldo, rekvid, aasta, kontoid, Asutusid) Values 

		(0, v_journal.rekvId, year(v_journal.kpv),lnKontoId, v_journal.Asutusid);

	end if;

/*

-- kaibed uuendamine

	lnKuu := month(v_journal.kpv);

	lnAAsta := year (v_journal.kpv);

	ldKpv := date(lnAasta, lnKuu, sp_viimanepaev(lnKuu, lnAAsta));



-- deebet



	select id into lnSaldoId from saldo 

		where rekvId = v_journal.rekvid 

		and konto = new.deebet

		and asutusId = v_journal.asutusId

		and kuu = lnKuu

		and aasta = lnAasta

		and tunnus = new.tunnus;

		



	if ifnull(lnSaldoId,0) = 0 then

		-- insert 

		insert into saldo (rekvid, konto, dbkaibed, asutusid, tunnus, kuu, aasta, kpv)

			values (v_journal.rekvid, new.deebet, new.summa, v_journal.asutusId, new.tunnus, lnKuu, lnAasta, ldKpv);

	else

		update saldo set dbKaibed = dbkaibed + new.summa where id = lnSaldoId;

	end if;





-- kreedit



	select id into lnSaldoId from saldo 

		where rekvId = v_journal.rekvid 

		and konto = new.kreedit

		and asutusId = v_journal.asutusId

		and kuu = lnKuu

		and aasta = lnAasta

		and tunnus = new.tunnus;



	if ifnull(lnSaldoId,0) = 0 then

		-- insert 

		insert into saldo (rekvid, konto, krkaibed, asutusid, tunnus, kuu, aasta, kpv)

			values (v_journal.rekvid, new.kreedit, new.summa, v_journal.asutusId, new.tunnus, lnKuu, lnAasta, ldKpv);

	else

		update saldo set krKaibed = krkaibed + new.summa where id = lnSaldoId;

	end if;









*/





-- reklmaks

/*

select id, rekvid, kpv, asutusId, dok into tmpJournal from journal where id = new.parentId;



if (select count(id) from luba where number = tmpJournal.dok and rekvid = tmpJournal.rekvid and luba.parentid = tmpJournal.asutusId) > 0 then

	perform sp_tasu_dekl(tmpJournal.id);

end if;





select id, rekvid, kpv, asutusId, dok into tmpJournal from journal where id = new.parentId;



if (select count(toiming.id) from luba inner join toiming on luba.id = toiming.lubaid where ltrim(rtrim(luba.number))+'-'+ltrim(rtrim(toiming.number::varchar)) like ltrim(rtrim(tmpJournal.dok))+'%' and rekvid = tmpJournal.rekvid and luba.parentid = tmpJournal.asutusId) > 0 then

	if left(ltrim(rtrim(new.deebet)),6) = '100100' or left(ltrim(rtrim(new.kreedit)),6) = '100100' then 	

		raise notice 'see on dekl.tasu %',new.deebet;

		perform sp_tasu_dekl(tmpJournal.id);

	end if;

end if;



*/





	--perform sp_register_oper(v_journal.rekvid,new.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, v_journal.rekvid));





	return NULL;

end;

$$;

ALTER FUNCTION trigu_journal1_after() OWNER TO vlad;

