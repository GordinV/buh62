CREATE FUNCTION trigi_dokvaluuta1_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	lnUsrId int;
	lnRekvId int;
begin
	SELECT id, rekvid INTO lnUsrID, lnRekvId from userid WHERE kasutaja = CURRENT_USER::VARCHAR;
	perform sp_register_oper(lnrekvid,new.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, lnUsrId);

	raise notice 'inserted new.id %', new.id;


	return null;
end;
$$;

ALTER FUNCTION trigi_dokvaluuta1_after() OWNER TO vlad;

