CREATE FUNCTION trigiu_nomenklatuur_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	v_userid record;

	lresult int;

	lcNotice varchar;

	lnuserId int4;

begin



	lnUserid = sp_currentuser(current_user::varchar, new.rekvid);

	select * into v_userid from userid where id = lnUserid;

	if v_userid.kasutaja_ = 0 and v_userid.peakasutaja_ = 0 then

			raise exception 'Ei ole Ćµigused lisada/muudata/kustuta';

			return null;

	end if;



	return new;

end;

$$;

ALTER FUNCTION trigiu_nomenklatuur_before() OWNER TO vlad;

