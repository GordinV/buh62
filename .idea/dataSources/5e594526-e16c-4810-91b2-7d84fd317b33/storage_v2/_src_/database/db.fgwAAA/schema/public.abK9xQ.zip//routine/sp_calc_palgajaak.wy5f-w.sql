CREATE FUNCTION sp_calc_palgajaak(user_id integer, params json) RETURNS integer
    LANGUAGE plpgsql
AS
$$
DECLARE

  l_kpv1      DATE = coalesce((params ->> 'kpv1') :: DATE, date(year(current_date), month(current_date), 1));

  l_kpv2      DATE = coalesce((params ->> 'kpv2') :: DATE, current_date);

  lnKuu       INTEGER = month(l_kpv1);

  lnAasta     INTEGER = year(l_kpv1);

  ldKpv1      DATE = date(lnAasta, lnKuu, 1);

  v_tooleping RECORD;

  isik_ids    INTEGER [] = params ->> 'isikud';

  l_rekvid    INTEGER = params ->> 'rekvid';



BEGIN

  IF l_rekvid IS NULL OR isik_ids IS NULL OR json_array_length(isik_ids :: JSON) = 0

  THEN

    RAISE NOTICE 'l_rekvid %, isik_ids %, json_array_length(isik_ids::json) %', l_rekvid, isik_ids, json_array_length(

        isik_ids :: JSON);

    --puudub vajaliku parameter

    RETURN 0;

  END IF;



  FOR v_tooleping IN

  SELECT tooleping.id

  FROM libs.asutus a

    INNER JOIN palk.tooleping t ON t.parentId = a.id

  WHERE ARRAY [a.id] && isik_ids

        AND t.rekvid = l_rekvid

  LOOP

    WHILE l_kpv2 >= l_kpv1

    LOOP

      l_kpv1 = date(lnAasta, lnKuu, 1);

      PERFORM palk.sp_update_palk_jaak(l_kpv1, v_tooleping.id);

      l_kpv1 = l_kpv1 + INTERVAL ' 1 month ';

    END LOOP;

    ldKpv1 = date(year(tdKpv1), month(tdkpv1), 1);

  END LOOP;

  RETURN 1;

  EXCEPTION WHEN OTHERS

  THEN

    RAISE NOTICE 'error % %', SQLERRM, SQLSTATE;

    RETURN 0;



END;

$$;

ALTER FUNCTION sp_calc_palgajaak(INTEGER, JSON) OWNER TO vlad;

