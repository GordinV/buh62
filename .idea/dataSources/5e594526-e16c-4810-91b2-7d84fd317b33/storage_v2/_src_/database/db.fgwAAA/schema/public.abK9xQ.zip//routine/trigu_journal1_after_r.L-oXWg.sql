CREATE FUNCTION trigu_journal1_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:=

	case when old.parentid <> new.parentid then 

		'parentid:' + old.parentid::text + '

'  else ''

	end +

	

	case when old.summa <> new.summa then 

		'summa:' + old.summa::text + '

'  else ''

	end +

	

	case when old.dokument <> new.dokument or (IfNull(old.dokument,space(1)) <> IfNull(new.dokument,space(1))) then 

		'dokument:' + case when ifNull(old.dokument,space(1)) = space(1) then space(1) + '

'  else old.dokument::text + '

'  end else ''

	end +

	

	case when old.muud <> new.muud or (IfNull(old.muud,space(1)) <> IfNull(new.muud,space(1))) then 

		'muud:' + case when ifNull(old.muud,space(1)) = space(1) then space(1) + '

'  else old.muud::text + '

'  end else ''

	end +

	

	case when old.kood1 <> new.kood1 then 

		'kood1:' + old.kood1::text + '

'  else ''

	end +

	

	case when old.kood2 <> new.kood2 then 

		'kood2:' + old.kood2::text + '

'  else ''

	end +

	

	case when old.kood3 <> new.kood3 then 

		'kood3:' + old.kood3::text + '

'  else ''

	end +

	

	case when old.kood4 <> new.kood4 then 

		'kood4:' + old.kood4::text + '

'  else ''

	end +

	

	case when old.kood5 <> new.kood5 then 

		'kood5:' + old.kood5::text + '

'  else ''

	end +

	

	case when old.deebet <> new.deebet then 

		'deebet:' + old.deebet::text + '

'  else ''

	end +

	

	case when old.lisa_k <> new.lisa_k then 

		'lisa_k:' + old.lisa_k::text + '

'  else ''

	end +

	

	case when old.kreedit <> new.kreedit then 

		'kreedit:' + old.kreedit::text + '

'  else ''

	end +

	

	case when old.lisa_d <> new.lisa_d then 

		'lisa_d:' + old.lisa_d::text + '

'  else ''

	end +

	

	case when old.valuuta <> new.valuuta then 

		'valuuta:' + old.valuuta::text + '

'  else ''

	end +

	

	case when old.kuurs <> new.kuurs then 

		'kuurs:' + old.kuurs::text + '

'  else ''

	end +

	

	case when old.valsumma <> new.valsumma then 

		'valsumma:' + old.valsumma::text + '

'  else ''

	end +

	

	case when old.tunnus <> new.tunnus then 

		'tunnus:' + old.tunnus::text + '

'  else ''

	end;

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (0,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,new.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigu_journal1_after_r() OWNER TO vlad;

