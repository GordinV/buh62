CREATE FUNCTION sp_create_journal_number_seq(integer, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
DECLARE 

	tnRekvId alias for $1;

	tnYear alias for $2;
	lcString varchar;

	lcSeq varchar;
	lnYear integer;

begin
	lnYear = tnYear;

	lcSeq = ' journalid_number_'+lnYear::varchar + '_'+tnrekvId::varchar;

	lcString = 'CREATE SEQUENCE ' + lcSeq + ' INCREMENT 1   MINVALUE 1   MAXVALUE 9223372036854775807   START 1 CACHE 1';

	execute lcstring;



	lcString = 'GRANT SELECT, UPDATE, INSERT ON TABLE ' + lcSeq + ' TO dbpeakasutaja';

	execute lcstring;

	lcString = 'GRANT SELECT, UPDATE, INSERT ON TABLE ' + lcSeq + ' TO dbkasutaja';

	execute lcstring;



        return  1;

end;

$$;

ALTER FUNCTION sp_create_journal_number_seq(INTEGER, INTEGER) OWNER TO vlad;

