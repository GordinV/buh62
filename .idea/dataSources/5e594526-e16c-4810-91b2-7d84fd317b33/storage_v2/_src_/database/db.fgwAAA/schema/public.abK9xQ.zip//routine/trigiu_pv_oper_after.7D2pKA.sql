CREATE FUNCTION trigiu_pv_oper_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

		v_userid record;

		lresult int;

		lnSumma numeric(14,4);

		lcNotice varchar;



	begin

/*

		lnSumma =  get_pv_summa(new.parentid);



			update pv_kaart set parhind = ifnull(lnSumma,0) where parentid = new.parentid;



		select sp_update_pv_jaak(new.parentid);
*/

		perform sp_register_oper(0,new.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, 0));



	return null;

	end;


$$;

ALTER FUNCTION trigiu_pv_oper_after() OWNER TO vlad;

