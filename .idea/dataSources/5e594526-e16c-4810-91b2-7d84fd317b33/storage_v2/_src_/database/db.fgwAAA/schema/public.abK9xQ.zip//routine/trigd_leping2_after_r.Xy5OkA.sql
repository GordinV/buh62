CREATE FUNCTION trigd_leping2_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:='parentid:' + old.parentid::TEXT + '

' +

	'nomid:' + old.nomid::TEXT + '

' +

	'kogus:' + old.kogus::TEXT + '

' +

	'hind:' + old.hind::TEXT + '

' +

	'soodus:' + old.soodus::TEXT + '

' +

	'soodusalg:'+ case when ifnull(old.soodusalg,date(1900,01,01))<>date(1900,01,01) then 

		dtoc(old.soodusalg) + '

' else '' end +

	'sooduslopp:'+ case when ifnull(old.sooduslopp,date(1900,01,01))<>date(1900,01,01) then 

		dtoc(old.sooduslopp) + '

' else '' end +

	'summa:' + old.summa::TEXT + '

' +

	'status:' + old.status::TEXT + '

' +

	'muud:' + case when ifnull(old.muud,space(1))<>space(1) then 

		old.muud::TEXT + '

' else ' ' end +

	'formula:' + old.formula + '

' +

	'kbm:' + old.kbm::TEXT + '

';

	

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (0,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,old.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigd_leping2_after_r() OWNER TO vlad;

