CREATE FUNCTION trigd_rekv_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	v_userid record;
	lresult int;
	lcNotice varchar;
begin
	perform sp_register_oper(old.id,old.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, old.id));
	return null;
end;
$$;

ALTER FUNCTION trigd_rekv_after() OWNER TO vlad;

