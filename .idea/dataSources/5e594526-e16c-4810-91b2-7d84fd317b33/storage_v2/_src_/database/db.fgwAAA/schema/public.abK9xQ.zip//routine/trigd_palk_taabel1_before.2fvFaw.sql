CREATE FUNCTION trigd_palk_taabel1_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	lnCount int4;

	lnrekvid int4;

begin



	select rekvid into lnRekvid from tooleping where id = old.toolepingId;



	-- check for user account

--	select * into v_userid from userid where id = sp_currentuser(CURRENT_USER::varchar, lnrekvid) and rekvid = lnrekvid;

--	if not found or (empty (v_userid.kasutaja_) and empty (v_userid.peakasutaja_)) then

--			raise exception 'Ei ole Ćµigused lisada/muudata/kustuta';

--			return null;

--	end if;





	select count(id) into lnCount from palk_taabel2 where parentid = old.Id;



	if lnCount > 0 then


		delete from palk_taabel2 where parentid = old.id;

	end if;


	return OLD;

end;

$$;

ALTER FUNCTION trigd_palk_taabel1_before() OWNER TO vlad;

