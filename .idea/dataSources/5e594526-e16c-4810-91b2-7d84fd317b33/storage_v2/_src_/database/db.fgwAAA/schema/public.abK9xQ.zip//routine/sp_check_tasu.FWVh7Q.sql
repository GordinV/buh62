CREATE FUNCTION sp_check_tasu(integer) RETURNS SETOF v_check_tasu
    LANGUAGE SQL
AS
$$
Select * from v_check_tasu where rekvid = $1;


$$;

ALTER FUNCTION sp_check_tasu(INTEGER) OWNER TO vlad;

