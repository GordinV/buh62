CREATE FUNCTION trigiu_taotlus_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	v_userid record;
	lresult int;
	lcNotice varchar;
begin
	if fnc_aasta_kontrol(new.rekvid, new.kpv) = 0 then
		raise exception 'Period on suletatud';
	else	
		return new;
	end if;
end;
$$;

ALTER FUNCTION trigiu_taotlus_before() OWNER TO vlad;

