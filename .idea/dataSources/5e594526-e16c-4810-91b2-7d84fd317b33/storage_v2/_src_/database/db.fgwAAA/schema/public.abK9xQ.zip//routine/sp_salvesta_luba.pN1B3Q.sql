CREATE FUNCTION sp_salvesta_luba(integer, integer, integer, date, date, character varying, numeric, character varying, integer, text, character varying) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare

	tnid alias for $1;

	tnParentid alias for $2;

	tnRekvid alias for $3;

	tdAlgKpv alias for $4;

	tdLoppKpv alias for $5;

	tcNumber alias for $6;

	tnSumma alias for $7;

	tcAlus alias for $8;

	tnStaatus alias for $9;

	ttMuud alias for $10;

	tcKord alias for $11;

	lnId int; 

begin



if tnId = 0 then

	-- uus kiri

	insert into luba (parentid,rekvid, algkpv,loppkpv, number, summa, alus, staatus, muud, kord) 

		values (tnparentid,tnrekvid, tdalgkpv,tdloppkpv, tcnumber, ROUND(tnsumma,2), tcalus, 1, ttmuud, tcKord);



	lnId:= cast(CURRVAL('public.luba_id_seq') as int4);



else

	-- muuda 

	update luba set 

		parentid = tnparentid,

		rekvid = tnrekvid,

		algkpv = tdAlgkpv,

		loppkpv = tdLoppKpv, 

		number = tcNumber, 

		summa = round(tnSumma,2), 

		alus = tcAlus,

		staatus = tnStaatus,

		kord = tcKord,

		muud = ttMuud

	where id = tnId;



	lnId := tnId;



end if;



         return  lnId;

end;

$$;

ALTER FUNCTION sp_salvesta_luba(INTEGER, INTEGER, INTEGER, DATE, DATE, VARCHAR, NUMERIC, VARCHAR, INTEGER, TEXT, VARCHAR) OWNER TO vlad;

