CREATE FUNCTION update_po(tnrekvid integer) RETURNS void
    LANGUAGE plpgsql
AS
$$
declare
	v_rec record;
	a_leping integer[] = array[0];
begin
	for v_rec in 
		select ltrim(rtrim(a.nimetus)) as nimetus, qry.*, pj.g31
		from asutus a 
		inner join tooleping t on t.parentid = a.id
		inner join palk_jaak pj on pj.lepingid = t.id
		inner join (
			select po.id, tulubaas, po.lepingid 
				from palk_oper po 
				inner join palk_lib pl on pl.parentid = po.libid
				where kpv >= date(2015,01,01) and kpv <= date(2015,01,31)
			--	and (tulubaas = 308)
				and libId in (select parentid from palk_lib where liik = 1)
		) qry on qry.lepingid = t.id
		where t.rekvid = 1
		and pj.kuu = 1 and pj.aasta = 2015
--		limit 15
	loop
		raise notice 'v_rec.nimetus %, v_rec.id %, v_rec.g31 %, a_leping %', v_rec.nimetus,  v_rec.id, v_rec.g31, a_leping;
		if not (v_rec.lepingid = any(a_leping))  then
			raise notice 'update ..' ;
			update palk_oper set tulubaas = v_rec.g31 where id = v_rec.id;
			a_leping =  array_append(a_leping , v_rec.lepingid);
		end if;
	end loop;

end;
$$;

ALTER FUNCTION update_po(INTEGER) OWNER TO vlad;

