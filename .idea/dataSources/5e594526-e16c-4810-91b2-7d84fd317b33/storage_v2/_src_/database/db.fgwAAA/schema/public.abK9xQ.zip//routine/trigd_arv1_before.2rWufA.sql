CREATE FUNCTION trigd_arv1_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare
lnId		int;
recArv		record; 
begin
	select id into lnId from ladu_grupp where ladu_grupp.nomId = old.nomId;
	if not found then
		return old;
	end if;
	select * into recArv from arv where id = old.parentId;

	if recArv.operId > 0  and recArv.liik = 1 then
	-- vara sisetulik
		if old.maha > 0 then
			-- mahakantud, ei saa
			raise exception ' ei saa kustuta sest kaup on mahakantud';
			return null;
		end if;
	end if;	

	return old;
end;
$$;

ALTER FUNCTION trigd_arv1_before() OWNER TO vlad;

