CREATE FUNCTION sp_calc_palk_jaak(integer, integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 


	tnKuu alias for $1;


	tnAasta	alias for $2;


	tnleping alias for $3;


	lnlastPeriodJaak numeric (12,4);


	lnPrevKuu numeric (12,4);


	lnPrevAasta numeric (12,4);


	lnid int;


	v_palk_jaak record;


begin


	update palk_jaak set jaak = 0 where kuu = tnkuu and aasta = tnaasta and lepingid = tnleping;


	lnPrevKuu := tnkuu - 1;


	if lnPrevkuu < 1 then


		lnPrevkuu := 12;


		lnPrevaasta := tnaasta - 1;


	else


		lnPrevAasta := tnaasta;


	end if;





	select jaak into lnLastPeriodJaak from palk_jaak where lepingId = tnleping and kuu = lnprevKuu and aasta = lnprevAasta;


	lnLastPeriodJaak := ifnull (lnLastPeriodJaak,0);


	select * into v_palk_jaak from palk_jaak where lepingId = tnleping and kuu = tnKuu and aasta = tnAasta;


	update palk_jaak set jaak = lnlastPeriodJaak + v_palk_jaak.arvestatud - v_palk_jaak.kinni - v_palk_jaak.tulumaks 


		where id = v_palk_jaak.id;


	return 1;


end;

$$;

ALTER FUNCTION sp_calc_palk_jaak(INTEGER, INTEGER, INTEGER) OWNER TO vlad;

