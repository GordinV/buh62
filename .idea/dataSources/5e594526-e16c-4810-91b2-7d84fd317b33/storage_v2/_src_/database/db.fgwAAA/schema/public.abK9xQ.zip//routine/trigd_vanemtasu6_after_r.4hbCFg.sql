CREATE FUNCTION trigd_vanemtasu6_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

	lnRekvid int;

begin

	

	select rekvid into lnrekvid from vanemtasu5 where id = old.parentid;

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid) 

		VALUES (lnrekvid,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,old.id);

	return null;

end;

$$;

ALTER FUNCTION trigd_vanemtasu6_after_r() OWNER TO vlad;

