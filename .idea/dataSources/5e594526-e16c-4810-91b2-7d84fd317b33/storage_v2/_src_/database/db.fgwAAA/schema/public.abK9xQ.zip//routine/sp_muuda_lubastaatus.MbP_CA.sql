CREATE FUNCTION sp_muuda_lubastaatus(integer, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	tnid alias for $1;
	tnStaatus alias for $2;

	lnResult int; 
begin
	lnresult = 1;
--	raise notice 'status: %',tnStaatus;
	update luba set staatus = tnStaatus where id = tnid;


return  lnResult;
end;
$$;

ALTER FUNCTION sp_muuda_lubastaatus(INTEGER, INTEGER) OWNER TO vlad;

