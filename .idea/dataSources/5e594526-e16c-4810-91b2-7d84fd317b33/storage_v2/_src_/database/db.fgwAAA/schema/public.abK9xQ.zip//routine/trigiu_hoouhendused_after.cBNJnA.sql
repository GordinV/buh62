CREATE FUNCTION trigiu_hoouhendused_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	lnAsutusId int;

begin
	if new.doktyyp = 'ARVED' then
		select asutusId into lnAsutusId from arv where id = new.dokid;
		lnAsutusid = ifnull(lnAsutusId,0);
		if lnAsutusId > 0 then
			perform sp_arvesta_hoolepingujaak(lnAsutusId, new.isikId);
		end if;
	end if;

	return null;

end;

$$;

ALTER FUNCTION trigiu_hoouhendused_after() OWNER TO vlad;

