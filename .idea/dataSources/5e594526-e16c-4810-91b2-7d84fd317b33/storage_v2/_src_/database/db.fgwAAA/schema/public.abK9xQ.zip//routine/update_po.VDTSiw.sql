CREATE FUNCTION update_po() RETURNS void
    LANGUAGE plpgsql
AS
$$
declare
	v_rec record;
begin
	for v_rec in 
		select a.nimetus, qry.*, pj.g31
		from asutus a 
		inner join tooleping t on t.parentid = a.id
		inner join palk_jaak pj on pj.lepingid = t.id
		inner join (
			select po.id, tulubaas, po.lepingid 
				from palk_oper po 
				inner join palk_lib pl on pl.parentid = po.libid
				where kpv >= date(2015,01,01) and kpv <= date(2015,01,31)
				and (tulubaas is null or tulubaas = 0)
				and libId in (select parentid from palk_lib where liik = 1)
		) qry on qry.lepingid = t.id
		where t.rekvid = 64
		and pj.kuu = 1 and pj.aasta = 2015
		limit 10
	loop
		
	end loop;

end;
$$;

ALTER FUNCTION update_po() OWNER TO vlad;

