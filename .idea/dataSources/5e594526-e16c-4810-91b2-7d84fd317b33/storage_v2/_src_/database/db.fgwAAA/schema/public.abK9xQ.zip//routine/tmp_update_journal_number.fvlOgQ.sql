CREATE FUNCTION tmp_update_journal_number() RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare 

	v_journalid record;

	lnNumber int4;

	lnDbaseId int4;

begin

	lnNumber := 415;



	for v_journalid in

		select * from journalid where rekvid = 28 and aasta = 2006 and number > 75000 order by journalid

		loop

			update journalid set number = lnNumber where id = v_journalid.id;

			raise notice 'lnNumber %',lnNumber;

			lnNumber := lnNumber + 1;

		end loop;

		select id into lnDbaseId from dbase where alias = '28ASUTUS2006';

		update dbase set lastnum = lnNumber where id = lnDbaseId;

	return 1;

end;

$$;

ALTER FUNCTION tmp_update_journal_number() OWNER TO vlad;

