CREATE FUNCTION vanem_user(integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare 

	tnUserid alias for $1;



begin





INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3450, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3451, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3452, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3453, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3454, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3456, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3457, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3458, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3460, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3461, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3466, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3467, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3468, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3469, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3470, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3988, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3994, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3995, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3346, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3347, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3348, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3349, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3350, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3351, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3352, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3353, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3354, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3355, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3356, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3357, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3358, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3359, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3360, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3361, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3275, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3362, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3363, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3364, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3365, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3366, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3367, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3368, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3369, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3370, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3371, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3372, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3373, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3374, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3375, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3376, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3377, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3378, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3379, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3380, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3381, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3382, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3383, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3976, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3979, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3980, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3538, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3541, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3542, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3543, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3544, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3545, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3546, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3547, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3548, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3549, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3550, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3551, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3552, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3553, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3554, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3555, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3556, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3557, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3558, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (4138, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (4139, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (4146, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3301, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3313, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3574, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3575, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3576, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3577, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3578, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3579, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3580, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3630, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3631, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3632, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3633, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3634, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3635, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3636, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3987, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (3997, 'KASUTAJA', tnUserid, 0, 1, '');

INSERT INTO menuisik(parentid, gruppid, userid, jah, ei, proc_ ) VALUES (4011, 'KASUTAJA', tnUserid, 0, 1, '');

return 0;

end;

$$;

ALTER FUNCTION vanem_user(INTEGER) OWNER TO vlad;

