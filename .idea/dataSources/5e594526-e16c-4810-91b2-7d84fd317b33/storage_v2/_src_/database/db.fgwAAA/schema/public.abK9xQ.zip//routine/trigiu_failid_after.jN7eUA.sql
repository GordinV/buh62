CREATE FUNCTION trigiu_failid_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	v_userid record;
	lresult int;
	lcNotice varchar;
	lnrekvId int;
begin
	select rekvid into lnrekvId from luba where id = new.lubaid order by id desc limit 1;


	perform sp_register_oper(lnrekvid,new.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, lnrekvid));
	return null;
end;
$$;

ALTER FUNCTION trigiu_failid_after() OWNER TO vlad;

