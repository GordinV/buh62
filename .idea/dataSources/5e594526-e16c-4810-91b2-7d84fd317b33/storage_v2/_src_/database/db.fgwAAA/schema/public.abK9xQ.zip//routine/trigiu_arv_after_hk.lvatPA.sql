CREATE FUNCTION trigiu_arv_after_hk() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	v_userid record;
	lresult int;
	lcNotice varchar;
	lnisikId integer;
begin
	if not empty(new.lisa) then
		lnIsikId = fnc_LeiaIsikuKood(new.lisa);
		if lnIsikId > 0 then
			-- see on hooarve, teeme kirja uhendus
			if (select count(id) from hoouhendused where isikid = lnIsikId and dokid = new.id) = 0 then
				insert into hoouhendused (isikid, dokid, doktyyp) values (lnIsikId, new.id,'ARVED');
			end if;			
		end if;
	end if;
	return null;
end;
$$;

ALTER FUNCTION trigiu_arv_after_hk() OWNER TO vlad;

