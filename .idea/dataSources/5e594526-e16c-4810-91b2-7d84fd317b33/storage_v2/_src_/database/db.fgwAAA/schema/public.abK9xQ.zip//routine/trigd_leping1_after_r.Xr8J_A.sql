CREATE FUNCTION trigd_leping1_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:='asutusid:' + old.asutusid::TEXT + '

' +

	'rekvid:' + old.rekvid::TEXT + '

' +

	'doklausid:' + old.doklausid::TEXT + '

' +

	'number:' + old.number + '

' +

	'kpv:'+ old.kpv::TEXT + '

' +

	'tahtaeg:'+ case when ifnull(old.tahtaeg,date(1900,01,01))<>date(1900,01,01) then 

		dtoc(old.tahtaeg) + '

' else '' end +

	'selgitus:' + old.selgitus + '

' +

	'dok:' + case when ifnull(old.dok,space(1))<>space(1) then 

		old.dok::TEXT + '

' else ' ' end +

	'muud:' + case when ifnull(old.muud,space(1))<>space(1) then 

		old.muud::TEXT + '

' else ' ' end;

	

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (old.rekvid,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,old.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigd_leping1_after_r() OWNER TO vlad;

