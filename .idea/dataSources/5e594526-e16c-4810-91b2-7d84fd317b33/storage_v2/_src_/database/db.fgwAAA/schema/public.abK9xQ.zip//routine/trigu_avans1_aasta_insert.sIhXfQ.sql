CREATE FUNCTION trigu_avans1_aasta_insert() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	lresult int;
	lcNotice varchar;
	lnuserId int4;
begin

	if (fnc_aasta_kontrol(old.rekvid, old.kpv)= 0) and 
		(new.kpv <> old.kpv or new.asutusid <> old.asutusId or new.number <> old.number)  then
			raise exception 'Viga: Perion on kinnitatud';
			return null;
	end if;

	return new;
end;
$$;

ALTER FUNCTION trigu_avans1_aasta_insert() OWNER TO vlad;

