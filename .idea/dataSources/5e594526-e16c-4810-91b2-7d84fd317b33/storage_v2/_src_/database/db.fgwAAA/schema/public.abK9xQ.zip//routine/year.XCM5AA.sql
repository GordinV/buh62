CREATE FUNCTION year() RETURNS integer
    LANGUAGE plpgsql
AS
$$
begin
         return  year(current_date);
end;
$$;

ALTER FUNCTION year() OWNER TO vlad;

