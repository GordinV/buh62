CREATE FUNCTION trigd_asutus_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:='rekvid:' + old.rekvid::TEXT + '

' +

	'regkood:' + old.regkood + '

' +

	'nimetus:' + old.nimetus + '

' +

	'omvorm:' + old.omvorm + '

' +

	'aadress:' + old.aadress + '

' +

	'kontakt:' + old.kontakt + '

' +

	'tel:' + old.tel + '

' +

	'faks:' + old.faks + '

' +

	'email:' + old.email + '

' +

	'muud:' + case when ifnull(old.muud,space(1))<>space(1) then 

		old.muud::TEXT + '

' else ' ' end +

	'tp:' + old.tp + '

';

	

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (old.rekvid,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,old.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigd_asutus_after_r() OWNER TO vlad;

