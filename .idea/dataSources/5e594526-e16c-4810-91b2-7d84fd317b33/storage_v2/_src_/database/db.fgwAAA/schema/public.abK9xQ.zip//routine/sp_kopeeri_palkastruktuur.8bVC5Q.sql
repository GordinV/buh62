CREATE FUNCTION sp_kopeeri_palkastruktuur(integer, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare

	tnid alias for $1;

	tnRekvid alias for $2;



	lnId int; 

	lcString varchar;

	v_library record;

	v_palk_lib record;

	v_klassiflib record;





begin







select * into v_library from library where id = tnId;



-- kontrolin kas on sama kood juba

if (select count(*) from library where rekvid = tnRekvid and library = 'PALK' and kood = v_library.kood) = 0 then

	-- uut library kiri

	insert into library (rekvid, kood, nimetus, library, muud, tun1, tun2,tun3,tun4 ,tun5) values 

		(tnrekvid, v_library.kood, v_library.nimetus, v_library.library, v_library.muud, v_library.tun1, v_library.tun2,v_library.tun3,v_library.tun4 ,v_library.tun5);	



	lnId:= cast(CURRVAL('public.library_id_seq') as int4);



	-- uut palk_lib



	select * into v_palk_lib from palk_lib where parentid = tnid;

	if ifnull(v_palk_lib.liik,999999) <> 999999 then

		insert into palk_lib (parentid, liik, tund, maks, palgafond, asutusest, lausendid, algoritm, muud, round,sots,konto, elatis, tululiik) values

			(lnId, v_palk_lib.liik, v_palk_lib.tund, v_palk_lib.maks, v_palk_lib.palgafond, v_palk_lib.asutusest, v_palk_lib.lausendid,

			v_palk_lib.algoritm, v_palk_lib.muud, v_palk_lib.round,v_palk_lib.sots,v_palk_lib.konto, v_palk_lib.elatis, v_palk_lib.tululiik);

	end if;

	-- uut klassiflib

	

	select * into v_klassiflib from klassiflib where libId = tnid;

	if ifnull(v_klassiflib.id,0) > 0 then 

	insert into klassiflib (libid,tyyp, tunnusid, kood1, kood2, kood3, kood4, kood5, konto, proj) values 

	(lnid,ifnull(v_klassiflib.tyyp,0), v_klassiflib.tunnusid, v_klassiflib.kood1, v_klassiflib.kood2, v_klassiflib.kood3, v_klassiflib.kood4, v_klassiflib.kood5, v_klassiflib.konto, v_klassiflib.proj);

	end if;

else

	select id into lnId from library where rekvid = tnRekvid and library = 'PALK' and kood = v_library.kood;

end if; 

         return  lnId;

end;

$$;

ALTER FUNCTION sp_kopeeri_palkastruktuur(INTEGER, INTEGER) OWNER TO vlad;

