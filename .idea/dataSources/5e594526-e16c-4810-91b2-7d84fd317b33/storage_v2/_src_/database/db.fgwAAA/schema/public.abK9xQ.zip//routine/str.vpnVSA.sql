CREATE FUNCTION str(integer) RETURNS character
    LANGUAGE plpgsql
AS
$$
begin

         return  cast($1 as bpchar);

end;

$$;

ALTER FUNCTION str(INTEGER) OWNER TO vlad;

