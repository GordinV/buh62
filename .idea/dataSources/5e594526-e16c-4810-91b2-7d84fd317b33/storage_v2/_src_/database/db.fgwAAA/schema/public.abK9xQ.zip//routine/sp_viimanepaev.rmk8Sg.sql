CREATE FUNCTION sp_viimanepaev(date) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare 
	ldKpv alias for $1;
BEGIN


RETURN DAY(GOMONTH(DATE(year(ldKpv), month(ldKpv), 1), 1)-1);
end;

$$;

ALTER FUNCTION sp_viimanepaev(DATE) OWNER TO vlad;

