CREATE FUNCTION trigd_tooleping_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	v_userid record;

	lresult int;

	lcNotice varchar;

begin



	delete from palk_oper where lepingId = old.id;

	delete from palk_kaart where lepingId = old.id;

	delete from palk_taabel1 where toolepingId = old.id;

	delete from palk_jaak where lepingId = old.id;

	delete from puudumine where lepingid = old.id;

	perform sp_register_oper(old.rekvId,old.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, old.rekvid));



	return null;

end;

$$;

ALTER FUNCTION trigd_tooleping_after() OWNER TO vlad;

