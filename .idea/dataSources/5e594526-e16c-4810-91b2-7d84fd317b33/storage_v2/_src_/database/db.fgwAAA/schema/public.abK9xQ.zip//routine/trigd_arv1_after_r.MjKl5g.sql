CREATE FUNCTION trigd_arv1_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:='parentid:' + old.parentid::TEXT + '

' +

	'nomid:' + old.nomid::TEXT + '

' +

	'kogus:' + old.kogus::TEXT + '

' +

	'hind:' + old.hind::TEXT + '

' +

	'soodus:' + old.soodus::TEXT + '

' +

	'kbm:' + old.kbm::TEXT + '

' +

	'maha:' + old.maha::TEXT + '

' +

	'summa:' + old.summa::TEXT + '

' +

	'muud:' + case when ifnull(old.muud,space(1))<>space(1) then 

		old.muud::TEXT + '

' else ' ' end +

	'kood1:' + old.kood1 + '

' +

	'kood2:' + old.kood2 + '

' +

	'kood3:' + old.kood3 + '

' +

	'kood4:' + old.kood4 + '

' +

	'kood5:' + old.kood5 + '

' +

	'konto:' + old.konto + '

' +

	'tp:' + old.tp + '

' +

	'kbmta:' + old.kbmta::TEXT + '

' +

	'isikid:' + old.isikid::TEXT + '

' +

	'tunnus:' + old.tunnus + '

';

	

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (0,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,old.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigd_arv1_after_r() OWNER TO vlad;

