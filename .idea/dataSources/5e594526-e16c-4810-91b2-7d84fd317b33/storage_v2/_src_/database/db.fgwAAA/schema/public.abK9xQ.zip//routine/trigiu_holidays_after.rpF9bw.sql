CREATE FUNCTION trigiu_holidays_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	lresult int;

	lcNotice varchar;

	v_rekv record;

	lnid int;

	lnLibId int;

begin

	raise notice 'START';





	if new.rekvid = 119 then

		for v_rekv in 

			select id, nimetus from rekv where parentid = 119 

		loop

			raise notice 'v_rekv.nimetus %',v_rekv.nimetus;

			-- kopeerime library



			-- kooperimie palk_lib

			if (select count(id) from holidays where kuu = new.kuu and paev = new.paev and rekvId = v_rekv.id) = 0 then

				insert into holidays (rekvid, kuu, paev, nimetus, muud, luhipaev ) values 

					(v_rekv.id, new.kuu, new.paev, new.nimetus, new.muud, new.luhipaev);

			else

				update holidays set

					nimetus = new.nimetus, 

					muud = new.muud, 

					luhipaev = new.luhipaev

					where kuu = new.kuu

					and paev = new.paev

					and rekvId = v_rekv.id;

			end if;



		end loop;





	end if;

	return null;



end;

$$;

ALTER FUNCTION trigiu_holidays_after() OWNER TO vlad;

