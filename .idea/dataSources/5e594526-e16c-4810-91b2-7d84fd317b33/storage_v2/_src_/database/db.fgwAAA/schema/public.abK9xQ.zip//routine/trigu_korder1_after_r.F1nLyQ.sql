CREATE FUNCTION trigu_korder1_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:=

	case when old.rekvid <> new.rekvid then 

		'rekvid:' + old.rekvid::text + '

'  else ''

	end +

	

	case when old.userid <> new.userid then 

		'userid:' + old.userid::text + '

'  else ''

	end +

	

	case when old.journalid <> new.journalid then 

		'journalid:' + old.journalid::text + '

'  else ''

	end +

	

	case when old.kassaid <> new.kassaid then 

		'kassaid:' + old.kassaid::text + '

'  else ''

	end +

	

	case when old.tyyp <> new.tyyp then 

		'tyyp:' + old.tyyp::text + '

'  else ''

	end +

	

	case when old.doklausid <> new.doklausid then 

		'doklausid:' + old.doklausid::text + '

'  else ''

	end +

	

	case when old.number <> new.number then 

		'number:' + old.number::text + '

'  else ''

	end +

	

	case when old.kpv <> new.kpv then 

		'kpv:' + dtoc(old.kpv) + '

'  else ''

	end +

	

	case when old.asutusid <> new.asutusid then 

		'asutusid:' + old.asutusid::text + '

'  else ''

	end +

	

	case when old.nimi <> new.nimi then 

		'nimi:' + old.nimi::text + '

'  else ''

	end +

	

	case when old.aadress <> new.aadress then 

		'aadress:' + old.aadress::text + '

'  else ''

	end +

	

	case when old.dokument <> new.dokument then 

		'dokument:' + old.dokument::text + '

'  else ''

	end +

	

	case when old.alus <> new.alus then 

		'alus:' + old.alus::text + '

'  else ''

	end +

	

	case when old.summa <> new.summa then 

		'summa:' + old.summa::text + '

'  else ''

	end +

	

	case when old.muud <> new.muud or (IfNull(old.muud,space(1)) <> IfNull(new.muud,space(1))) then 

		'muud:' + case when ifNull(old.muud,space(1)) = space(1) then space(1) + '

'  else old.muud::text + '

'  end else ''

	end +

	

	case when old.arvid <> new.arvid then 

		'arvid:' + old.arvid::text + '

'  else ''

	end +

	

	case when old.doktyyp <> new.doktyyp then 

		'doktyyp:' + old.doktyyp::text + '

'  else ''

	end +

	

	case when old.dokid <> new.dokid then 

		'dokid:' + old.dokid::text + '

'  else ''

	end;

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (new.rekvid,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,new.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigu_korder1_after_r() OWNER TO vlad;

