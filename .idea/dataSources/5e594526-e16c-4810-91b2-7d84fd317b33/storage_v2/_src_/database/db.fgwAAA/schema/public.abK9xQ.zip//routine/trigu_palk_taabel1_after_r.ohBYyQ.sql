CREATE FUNCTION trigu_palk_taabel1_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:=

	case when old.toolepingid <> new.toolepingid then 

		'toolepingid:' + old.toolepingid::text + '

'  else ''

	end +

	

	case when old.kokku <> new.kokku then 

		'kokku:' + old.kokku::text + '

'  else ''

	end +

	

	case when old.too <> new.too then 

		'too:' + old.too::text + '

'  else ''

	end +

	

	case when old.paev <> new.paev then 

		'paev:' + old.paev::text + '

'  else ''

	end +

	

	case when old.ohtu <> new.ohtu then 

		'ohtu:' + old.ohtu::text + '

'  else ''

	end +

	

	case when old.oo <> new.oo then 

		'oo:' + old.oo::text + '

'  else ''

	end +

	

	case when old.tahtpaev <> new.tahtpaev then 

		'tahtpaev:' + old.tahtpaev::text + '

'  else ''

	end +

	

	case when old.puhapaev <> new.puhapaev then 

		'puhapaev:' + old.puhapaev::text + '

'  else ''

	end +

	

	case when old.kuu <> new.kuu then 

		'kuu:' + old.kuu::text + '

'  else ''

	end +

	

	case when old.aasta <> new.aasta then 

		'aasta:' + old.aasta::text + '

'  else ''

	end +

	

	case when old.muud <> new.muud or (IfNull(old.muud,space(1)) <> IfNull(new.muud,space(1))) then 

		'muud:' + case when ifNull(old.muud,space(1)) = space(1) then space(1) + '

'  else old.muud::text + '

'  end else ''

	end +

	

	case when old.uleajatoo <> new.uleajatoo then 

		'uleajatoo:' + old.uleajatoo::text + '

'  else ''

	end;

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (0,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,new.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigu_palk_taabel1_after_r() OWNER TO vlad;

