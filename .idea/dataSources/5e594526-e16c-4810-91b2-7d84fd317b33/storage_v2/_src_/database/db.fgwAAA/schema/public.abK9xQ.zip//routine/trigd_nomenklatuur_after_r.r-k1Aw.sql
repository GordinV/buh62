CREATE FUNCTION trigd_nomenklatuur_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:='rekvid:' + old.rekvid::TEXT + '

' +

	'doklausid:' + old.doklausid::TEXT + '

' +

	'dok:' + old.dok + '

' +

	'kood:' + old.kood + '

' +

	'nimetus:' + old.nimetus + '

' +

	'uhik:' + old.uhik + '

' +

	'hind:' + old.hind::TEXT + '

' +

	'muud:' + case when ifnull(old.muud,space(1))<>space(1) then 

		old.muud::TEXT + '

' else ' ' end +

	'ulehind:' + old.ulehind::TEXT + '

' +

	'kogus:' + old.kogus::TEXT + '

' +

	'formula:' + old.formula + '

';

	

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (old.rekvid,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,old.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigd_nomenklatuur_after_r() OWNER TO vlad;

