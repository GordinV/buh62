CREATE FUNCTION trigiu_arv_aasta_insert() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	lresult int;

	lcNotice varchar;

	lnuserId int4;

begin



	if (fnc_aasta_kontrol(new.rekvid, new.kpv)= 0) 

		and (new.kpv <> old.kpv or new.asutusid <> old.asutusId or new.number <> old.number or new.summa <> old.summa) 

 then

			raise exception '(Parandus) Perion on kinnitatud';

			return null;

	end if;



	return new;

end;

$$;

ALTER FUNCTION trigiu_arv_aasta_insert() OWNER TO vlad;

