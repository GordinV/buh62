CREATE FUNCTION get_last_day(kpv date) RETURNS date
    LANGUAGE plpgsql
AS
$$
BEGIN

  RETURN ((make_date(year(kpv), month(kpv), 1) + INTERVAL '1 month') :: DATE - 1);

END;

$$;

ALTER FUNCTION get_last_day(DATE) OWNER TO vlad;

