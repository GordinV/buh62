CREATE FUNCTION trigd_journal_before() RETURNS opaque
    LANGUAGE plpgsql
AS
$$
declare 

	lnCount int4;

begin

	select count (id) into lnCount from (


	SELECT Arv.id FROM  Arv   WHERE Arv.journalid = tnId   


	union 


	select id from arvtasu where journalId = tnId  


	union 


	SELECT id FROM mk1  WHERE journalid = tnId  


	union


	SELECT id FROM palk_oper  WHERE journalid = tnId  


	union 


	SELECT id FROM pv_oper  WHERE journalid = tnId 


	union 


	SELECT id FROM korder1  WHERE journalid = tnId) a;


  

	 if lnCount > 0 then

	-- ei saa kustuta

		raise notice 'ei saa kustuta '; 

		 return NULL;

	else

		return OLD;

	end if;

end;

$$;

ALTER FUNCTION trigd_journal_before() OWNER TO vlad;

