CREATE FUNCTION import_ho_plus_kultuur() RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare

        lcString varchar;

	lnResult int;

	lnrekvId int;

	lnrec int;

	v_tooleping record;

	v_palk_kaart record;

	v_palk_asutus record;

	v_palk_tmpl record;

	v_klassiflib record;

	v_pv_kaart record;

	lnAmetId int;

	lnOsakondId int;

	lnLibId int;

	lnnomId int;

	lnrekvidVana int;



	v_nom record;



begin

	lnrekvidVana := 61;

	LNrEKViD = 62;



/*

	insert into rekv (parentid , regkood, nimetus , kbmkood , aadress , haldus , tel,  faks ,  email, juht, raama, muud )

		select parentid , regkood, 'Kultuuriosakond 2006' , kbmkood , aadress , haldus , tel,  faks ,  email, juht, raama, muud 

		from rekv

		where id = lnrekvidVana;



	select id into lnrekvId from rekv order by id desc  limit 1;



	raise notice 'lnrekvId %',lnrekvId;



	insert into userid ( rekvid ,kasutaja , ametnik , kasutaja_ , peakasutaja_ , admin , muud)

		select distinct lnrekvId ,kasutaja , ametnik , kasutaja_ , peakasutaja_ , admin , muud 

		from userid where rekvId = lnrekvidVana;



	GET DIAGNOSTICS lnrec = ROW_COUNT;

	raise notice 'userid, lnrec %',lnrec;





	insert into aa (parentid, arve,nimetus, default_,kassa,pank,konto,muud, tp) 

	select distinct lnrekvId, arve,nimetus, default_,kassa,pank,konto,muud, tp 

	from aa where parentid = lnrekvidVana;



	GET DIAGNOSTICS lnrec = ROW_COUNT;

	raise notice 'aa, lnrec %',lnrec;



	raise notice 'library';

--	alter table library add column vanaId int;



	insert into library (rekvid,kood,nimetus,library, muud, tun1, tun2, tun3, tun4, tun5, vanaid) 

		select distinct lnrekvid,kood,nimetus,library, muud, tun1, tun2, tun3, tun4, tun5, id from library 

		where rekvid = lnrekvidVana 

		and library in ('TUNNUS', 'AMET','DOK','OSAKOND','PALK','POHIVARA','PVGRUPP','VARAGRUPP');



	GET DIAGNOSTICS lnrec = ROW_COUNT;

	raise notice 'library, lnrec %',lnrec;



	insert into kontoinf (parentid,type,formula,aasta,liik,pohikonto, rekvid, algsaldo) 

		select parentid,type,formula,aasta,liik,pohikonto, lnrekvid, 0 

		from kontoinf where rekvid = lnrekvidVana;



	GET DIAGNOSTICS lnrec = ROW_COUNT;

	raise notice 'kontoinf, lnrec %',lnrec;





	raise notice 'nomenklatuur';

--	alter table nomenklatuur add column vanaId int;





	insert into nomenklatuur (rekvid,doklausid,dok,kood,nimetus,uhik,hind,muud,ulehind,kogus,formula, vanaId)

	select lnrekvid,doklausid,dok,kood,nimetus,uhik,hind,muud,ulehind,kogus,formula, vanaId 

	from nomenklatuur where rekvId = lnrekvidVana;



	GET DIAGNOSTICS lnrec = ROW_COUNT;

	raise notice 'kontoinf, lnrec %',lnrec;





	raise notice 'TOOLEPING';

--	alter table tooleping add column vanaId int;



	insert into tooleping (parentid , osakondid,  ametid,algab,lopp ,toopaev,palk,palgamaar,pohikoht,

		koormus,ametnik,tasuliik,pank,aa ,muud ,rekvid,resident,riik,toend, vanaId )

	select tooleping.parentid , osakondid,  ametid,algab,lopp ,toopaev,palk,palgamaar,pohikoht,

		koormus,ametnik,tasuliik,pank,aa ,muud ,lnrekvid,resident,riik,toend, Id

		from tooleping where rekvid = lnrekvidVana and ametid > 0 and ifnull(osakondid,0) > 0;



	GET DIAGNOSTICS lnrec = ROW_COUNT;

	raise notice 'tooleping, lnrec %',lnrec;



	for v_tooleping in

		select * from tooleping where rekvid = lnrekvid

	loop

		raise notice 'tooleping, id %',v_tooleping.id;

		select id into lnAmetId from library where vanaid = v_tooleping.ametId;	

		select id into lnOsakondId from library where vanaid = v_tooleping.OsakondId;

		if ifnull(lnOsakondId,0) > 0 and ifnull(lnAmetId ,0) > 0 then

			update tooleping set ametId = lnAmetId, osakondId = lnOsakondId where id = v_tooleping.id;

		end if;

	end loop;



	raise notice 'palk_lib';

--	alter table palk_lib add column vanaId int;



	insert into palk_lib ( parentid,liik, tund, maks, palgafond, asutusest, lausendid, algoritm, muud, round , 

		sots, konto, elatis, tululiik, vanaId)

	select library.id,palk_lib.liik, palk_lib.tund, palk_lib.maks, palk_lib.palgafond, palk_lib.asutusest, palk_lib.lausendid, palk_lib.algoritm, palk_lib.muud, palk_lib.round , 

		palk_lib.sots, palk_lib.konto, palk_lib.elatis, palk_lib.tululiik, palk_lib.Id 

		from palk_lib inner join library on library.vanaId = palk_lib.parentid 

		where library.rekvId = lnrekvId;



	GET DIAGNOSTICS lnrec = ROW_COUNT;

	raise notice 'palk_lib, lnrec %',lnrec;



	raise notice 'palk_asutus';

--	alter table palk_asutus add column vanaId int;



	insert into palk_asutus (rekvid,osakondid,ametid,kogus,vaba,palgamaar,muud, tunnusid,vanaid)

	select lnrekvid,osakondid,ametid,kogus,vaba,palgamaar,muud, tunnusid,vanaid 

	from palk_asutus where rekvid = lnrekvidVana and ametid > 0;



	GET DIAGNOSTICS lnrec = ROW_COUNT;

	raise notice 'palk_asutus, lnrec %',lnrec;



	for v_palk_asutus in 

		select * from palk_asutus where rekvid = lnrekvId

	loop

		raise notice 'palk_asutus, id %',v_palk_asutus.id;

		select id into lnAmetId from library where vanaid = v_palk_asutus.ametId;	

		select id into lnOsakondId from library where vanaid = v_palk_asutus.OsakondId;	

		if ifnull(lnAmetId,0) > 0 and ifnull(lnOsakondId,0) > 0 then

			update palk_asutus set ametId = lnAmetId, osakondId = lnOsakondId where id = v_palk_asutus.id;

		end if;

	end loop;



	raise notice 'palk_kaart';

--	alter table palk_kaart add column vanaId int;





	insert into palk_kaart (parentid,lepingid,libid,summa,percent_,tulumaks,tulumaar,status, muud,alimentid,tunnusid,vanaId)

	select palk_kaart.parentid,tooleping.id,palk_kaart.libid,palk_kaart.summa,palk_kaart.percent_,palk_kaart.tulumaks,palk_kaart.tulumaar,

	palk_kaart.status, palk_kaart.muud,palk_kaart.alimentid,palk_kaart.tunnusid,palk_kaart.Id 

	from palk_kaart inner join tooleping on (palk_kaart.lepingId = tooleping.vanaId and tooleping.rekvid = lnRekvId) and libId > 0;



	GET DIAGNOSTICS lnrec = ROW_COUNT;

	raise notice 'palk_kaart, lnrec %',lnrec;



	for v_palk_kaart in

		select * from palk_kaart where lepingId in (select id from tooleping where rekvid = lnrekvid)

	loop

		raise notice 'palk_kaart, id %',v_palk_kaart.id;

		select id into lnLibId from library where vanaId = v_palk_kaart.libId;

		if ifnull(lnLibId,0) > 0 then

			update palk_kaart set libId = lnLibId where id = v_palk_kaart.id;

		else

			delete from palk_kaart where id = v_palk_kaart.id;

		end if;

		if v_palk_kaart.tunnusId > 0 then

			select id into lnLibId from library where vanaId = v_palk_kaart.TunnusId;

			if ifnull(lnLibId,0) = 0 then

				update palk_kaart set TunnusId = 0 where id = v_palk_kaart.id;		

			else

				update palk_kaart set TunnusId = lnLibId where id = v_palk_kaart.id;		

			end if;

		end if;

	end loop;



	raise notice 'palk_tmpl';

--	alter table palk_tmpl add column vanaId int;





	insert into palk_tmpl (parentid,libid,percent_,summa,tulumaar,tulumaks,tunnusid, vanaId)

		select parentid,libid,percent_,summa,tulumaar,tulumaks,tunnusid, palk_tmpl.Id 

		from palk_tmpl inner join library on palk_tmpl.parentId = library.vanaId

		where library.rekvid = lnrekvid and libId > 0;



	GET DIAGNOSTICS lnrec = ROW_COUNT;

	raise notice 'palk_tmpl, lnrec %',lnrec;





	for v_palk_tmpl in

		select palk_tmpl.*  

			from palk_tmpl inner join library on palk_tmpl.parentId = library.vanaId

			where library.rekvid = lnrekvid and libid > 0

	loop

		raise notice 'palk_tmpl, id %',v_palk_tmpl.id;

		select id into lnLibId from library where vanaId = v_palk_tmpl.libId;

		if ifnull(lnLibId,0) > 0 then

			update palk_tmpl set libId = lnLibId where id = v_palk_tmpl.id;

		end if;

		if v_palk_tmpl.tunnusId > 0 then

			select id into lnLibId from library where vanaId = v_palk_tmpl.TunnusId;

			if ifnull(lnLibId,0) > 0 then

				update palk_tmpl set TunnusId = lnLibId where id = v_palk_tmpl.id;		

			else

				update palk_tmpl set TunnusId = 0 where id = v_palk_tmpl.id;		

			end if;

		end if;

	

	end loop;



	raise notice 'palk_jaak';

--	alter table palk_jaak add column vanaId int;



	insert into palk_jaak (lepingid,kuu,aasta,jaak,arvestatud,kinni, tki,tka,pm,tulumaks, sotsmaks, muud, g31, vanaid)

	select tooleping.id,palk_jaak.kuu,palk_jaak.aasta,palk_jaak.jaak,palk_jaak.arvestatud,palk_jaak.kinni, 

		palk_jaak.tki,palk_jaak.tka,palk_jaak.pm,palk_jaak.tulumaks, palk_jaak.sotsmaks, palk_jaak.muud, 

		palk_jaak.g31, palk_jaak.id 

		from palk_jaak inner join tooleping on (palk_jaak.lepingId = tooleping.vanaId and tooleping.rekvId = lnRekvId);



	GET DIAGNOSTICS lnrec = ROW_COUNT;

	raise notice 'palk_jaak, lnrec %',lnrec;



*/



	raise notice 'klassiflib';

--	alter table klassiflib add column vanaId int;





--	DELETE FROM KLASSIFLIB WHERE nomId in (select id from nomenklatuur where rekvid = lnrekvId) 

--		or LibId in (select id from library where rekvid = lnrekvId);





	insert into klassiflib (nomid,  palklibid, libid, tyyp, tunnusid, kood1, kood2, kood3, kood4, kood5, konto, vanaId)

		select nomid,  palklibid, libid, tyyp, tunnusid, kood1, kood2, kood3, kood4, kood5, konto, vanaId 

		from klassiflib 

		where nomId in (select vanaid from nomenklatuur where rekvid = lnrekvId) 

		or LibId in (select vanaid from library where rekvid = lnrekvId);

	

	GET DIAGNOSTICS lnrec = ROW_COUNT;

	raise notice 'klassiflib, lnrec %',lnrec;

		

	for v_klassiflib in

		select * from klassiflib 		

		where nomId in (select vanaid from nomenklatuur where rekvid = lnrekvId) 

		or LibId in (select vanaid from library where rekvid = lnrekvId)

	loop

		raise notice 'v_klassiflib, id %',v_klassiflib.id;



		if v_klassiflib.nomid > 0 then

			select id into lnNomId from nomenklatuur where vanaId = v_klassiflib.nomId;

			if ifnull(lnNomId,0) > 0 then

				update klassiflib set nomid = lnNomid where id = v_klassiflib.id;

			end if;

		end if;

		if v_klassiflib.libId > 0 then

			select id into lnLibId from library where vanaId = v_klassiflib.libId;

			if ifnull(lnLibId,0) > 0 then

				update klassiflib set libid = lnLibid where id = v_klassiflib.id;

			end if;

		end if;

	end loop;



/*

	raise notice 'pv_kaart';

--	alter table pv_kaart add column vanaId int;



	insert into pv_kaart (parentid,vastisikid,soetmaks, soetkpv, kulum, algkulum, gruppid, konto, tunnus, mahakantud, otsus, muud, parhind, vanaId)

		select library.id,vastisikid,soetmaks, soetkpv, kulum, algkulum, gruppid, konto, tunnus, mahakantud, otsus, pv_kaart.muud, parhind, pv_kaart.Id

		from pv_kaart inner join library on (library.vanaid = pv_kaart.parentid and library.rekvid = lnrekvid);



	GET DIAGNOSTICS lnrec = ROW_COUNT;

	raise notice 'klassiflib, lnrec %',lnrec;



	for v_pv_kaart in

		select * from pv_kaart where parentid in (select id from library where rekvid = lnRekvId)

	loop 

		raise notice 'pv_kaart, id %',v_pv_kaart.id;

		select id into lnLibId from library where vanaid = v_pv_kaart.gruppid;

		if ifnull(lnLibId,0) > 0 then

			update pv_kaart set gruppid = lnLibid where id = v_pv_kaart.id;

		end if;

	end loop;



	raise notice 'subkontod';





	insert into subkonto ( kontoid , asutusid , algsaldo, aasta , rekvid ) 

		select distinct kontoid , asutusid , 0, 2006 , lnrekvid from subkonto where rekvid = lnrekvidVana;

  

	GET DIAGNOSTICS lnrec = ROW_COUNT;

	raise notice 'subkont, lnrec %',lnrec;



*/



-- Projektid, uritused

/*

	insert into library (rekvid,kood,nimetus,library, muud, tun1, tun2, tun3, tun4, tun5, vanaid) 

		select distinct lnrekvid,kood,nimetus,library, muud, tun1, tun2, tun3, tun4, tun5, id from library 

		where rekvid = lnrekvidVana 

		and library in ('PROJ', 'URITUS');



	GET DIAGNOSTICS lnrec = ROW_COUNT;

	raise notice 'library, lnrec %',lnrec;



*/



-- tyyp lausend

/*

alter table doklausheader add column vanaId int;





insert into doklausheader (vanaid,  rekvid ,  dok , proc_ ,  selg ,  muud)

select distinct id,  lnrekvid ,  dok , proc_ ,  selg ,  muud from doklausheader where rekvid = lnrekvidVana ;





alter table doklausend add column vanaId int;



insert into doklausend ( vanaid, parentid,summa,muud,kood1,kood2, kood3, kood4, kood5, deebet,kreedit,lisa_d,lisa_k)

select doklausend.id, doklausheader.id ,  doklausend.summa,  doklausend.muud,  doklausend.kood1 ,  doklausend.kood2 ,  

	doklausend.kood3 ,  doklausend.kood4 ,  doklausend.kood5 ,  doklausend.deebet ,  doklausend.kreedit,  doklausend.lisa_d ,  

	doklausend.lisa_k 

	from doklausend inner join doklausheader on doklausheader.vanaid = doklausend.parentid

	where doklausheader.rekvid = lnRekvId;







	for v_nom in

		select * from nomenklatuur 

			where rekvid =  61

	loop 

		select id into lnLibId from nomenklatuur 

			where rekvid = 62

			and doklausid = v_nom.doklausid

			and dok = v_nom.dok

			and kood = v_nom.kood

			and nimetus = v_nom.nimetus

			and empty(vanaid);



		lnLibId = ifnull(lnLibId,0);



		if lnLibId > 0 then

			update nomenklatuur set vanaid = v_nom.id where id = lnLibId;

		end if;

			

	end loop;





	insert into klassiflib (nomid,  palklibid, libid, tyyp, tunnusid, kood1, kood2, kood3, kood4, kood5, konto, vanaId)

		select nomid,  palklibid, libid, tyyp, tunnusid, kood1, kood2, kood3, kood4, kood5, konto, vanaId 

		from klassiflib 

		where LibId in (select vanaid from library where rekvid = lnrekvId);

	

	GET DIAGNOSTICS lnrec = ROW_COUNT;

	raise notice 'klassiflib, lnrec %',lnrec;

		

	for v_klassiflib in

		select * from klassiflib 		

		where LibId in (select vanaid from library where rekvid = lnrekvId)

	loop

		raise notice 'v_klassiflib, id %',v_klassiflib.id;



		if v_klassiflib.libId > 0 then

			select id into lnLibId from library where vanaId = v_klassiflib.libId;

			if ifnull(lnLibId,0) > 0 then

				update klassiflib set libid = lnLibid where id = v_klassiflib.id;

			end if;

		end if;

	end loop;

*/



-- append klassiflib 

/*

	for v_klassiflib in

		select * from klassiflib_old

	loop

		if (select count(id) from klassiflib where id = v_klassiflib.id) = 0 then

			-- insert

			insert into klassiflib (id,nomid,palklibid,libid,tyyp,tunnusid,kood1,kood2, kood3,kood4,kood5,konto,vanaid,proj)

			values(v_klassiflib.id,v_klassiflib.nomid,v_klassiflib.palklibid,v_klassiflib.libid,v_klassiflib.tyyp,

				v_klassiflib.tunnusid,v_klassiflib.kood1,v_klassiflib.kood2, v_klassiflib.kood3,v_klassiflib.kood4,

				v_klassiflib.kood5,v_klassiflib.konto,v_klassiflib.vanaid,v_klassiflib.proj);

		end if;



	end loop;



*/

raise notice 'lopp ';





return lnResult;

end;

$$;

ALTER FUNCTION import_ho_plus_kultuur() OWNER TO vlad;

