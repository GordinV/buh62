CREATE FUNCTION trigd_avans1_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	lnCount int4;
	
begin
	delete from avans2 where parentid = old.id;

	IF old.JournalId > 0 then
		  lnCount:= sp_del_journal(old.journalId,1);
	end if;	

	--perform sp_register_oper(old.rekvid,old.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, old.rekvid));
	return NULL;
end;
$$;

ALTER FUNCTION trigd_avans1_after() OWNER TO vlad;

