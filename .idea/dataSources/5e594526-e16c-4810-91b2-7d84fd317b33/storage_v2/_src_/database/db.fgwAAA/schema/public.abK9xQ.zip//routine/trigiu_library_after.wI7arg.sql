CREATE FUNCTION trigiu_library_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	v_userid record;
	v_rekv record;

	lresult int;

	lcNotice varchar;

	lnCount int;

	lcTp varchar;

	lnid int;

begin

	if new.library = 'TUNNUS' then

		-- check for existent record in tunnusinf

		select count(id) into lnCount from tunnusinf where tunnusid = new.id ;

		if ifnull(lnCount,0) = 0 then

			-- no record, inserting 

			insert into tunnusinf (tunnusid, kontoid, rekvid)

			select new.id as tunnusId, library.id, new.rekvId from library where library = 'KONTOD';

		end if;

		if TG_OP = 'UPDATE' then
			if new.kood <> old.kood then

				raise notice ' parandamine ';
			

				update journal1 set tunnus = new.kood where tunnus = old.kood and parentid in (select id from journal where rekvid = new.rekvid);

				update arv1 set tunnus = new.kood where tunnus = old.kood and parentid in (select id from arv where rekvid = new.rekvid);

				update korder2 set tunnus = new.kood where tunnus = old.kood and parentid in (select id from korder1 where rekvid = new.rekvid);

				update palk_oper set tunnus = new.kood where tunnus = old.kood and  rekvid = new.rekvid;

				update pv_oper set tunnus = new.kood where tunnus = old.kood and parentid in (select id from library where rekvid = new.rekvid and library = 'POHIVARA');
			end if;

		end if;

	end if;



	if new.library = 'KONTOD' then

		for v_rekv in 
			select id from rekv where parentid < 999
		loop
			if (select count(id) from kontoinf where parentId = new.id and rekvid = v_rekv.id) = 0 then
				insert into kontoinf (parentid, rekvid ,algsaldo, type ) 
					values (new.id, v_rekv.id, 0, 3);
			end if;
		end loop;
	end if;



	if new.library = 'TP' and new.tun1 > 0 then

		-- check for existent record in tunnusinf

		select tp into lcTp from asutus where regkood = str(new.tun1) ;

		if ifnull(lcTp,'000000') <> new.kood then

			-- viga, parandame 

			update asutus set tp = new.kood where regkood = str(new.tun1);

		end if;

	end if;





/*

	if new.library = 'PROJ' or new.library = 'URITUS' and new.rekvid = 119 then

		if TG_OP = 'INSERT' then

			insert into library (rekvid, kood, nimetus, library, muud, tun1, tun2, tun3, tun4, tun5)

			select rekv.id, new.kood, new.nimetus, new.library, new.muud, new.tun1, new.tun2, new.tun3, new.tun4, new.tun5 from rekv

				where parentid = 119;

		end if;

		if TG_OP = 'UPDATE' then

			update library set 

				kood = new.kood,

				nimetus = new.nimetus,

				muud = new.muud,

				tun1 = new.tun1,

				tun2 = new.tun2,

				tun3 = new.tun3,

				tun4 = new.tun4,

				tun5 = new.tun5

			where rekvid in (select id from rekv where parentid = 119)

			and library.library = old.library 

			and library.kood = old.kood;



		end if;

	end if;

*/

	perform sp_register_oper(new.rekvid,new.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, new.rekvid));

	return null;

end;

$$;

ALTER FUNCTION trigiu_library_after() OWNER TO vlad;

