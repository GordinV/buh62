CREATE FUNCTION tmp_del_twin_kaart() RETURNS integer
    LANGUAGE plpgsql
AS
$$
DECLARE 

	v_palk_kaart record;

	lnId int;

	lnIdkustuta int;

	lnCount int;

begin	

	lnCount := 0;



	for v_palk_kaart in

	select libid, lepingid from palk_kaart 

		where lepingid in (select id from tooleping where rekvid = 61) 

		group by libid, lepingid

		having count(*) > 1

	loop

		lnCount := lnCount  + 1;

		select id into lnId from palk_kaart where libId = v_palk_kaart.libId and lepingid = v_palk_kaart.lepingid order by tunnusid desc limit 1;



		delete from palk_kaart where libId = v_palk_kaart.libId and lepingid = v_palk_kaart.lepingid and id <> lnId;

		

	end loop;

	



	return lnCount;

end;

$$;

ALTER FUNCTION tmp_del_twin_kaart() OWNER TO vlad;

