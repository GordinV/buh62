CREATE FUNCTION trigi_autod_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin

	UPDATE DBASE SET LASTNUM = NEW.ID WHERE id = 88;	 

	return NULL;

end;

$$;

ALTER FUNCTION trigi_autod_after() OWNER TO vlad;

