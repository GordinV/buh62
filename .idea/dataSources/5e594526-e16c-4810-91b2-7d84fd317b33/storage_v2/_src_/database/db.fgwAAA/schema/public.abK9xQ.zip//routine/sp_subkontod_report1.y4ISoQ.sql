CREATE FUNCTION sp_subkontod_report1(character varying, integer, date, date, integer) RETURNS character varying
    LANGUAGE plpgsql
AS
$$
DECLARE 

	tcKonto alias for $1;

	tnrekvid alias for $2;

	tdKpv1 alias for $3;

	tdKpv2 alias for $4;

	tnAsutus alias for $5;

	lcReturn varchar;

	lnDb numeric (14,2);

	lnKr numeric (14,2);

	lnAlg numeric (14,2);

	lnLopp numeric (14,2);

	lnAsutusId1 int;

	lnAsutusId2 int;

	v_kaibed record;

	v_saldo record;

	v_account record;

	v_tunnus record;

	lnCount int;





begin





	if tnAsutus > 0 then

		lnAsutusId1 := tnAsutus;

		lnAsutusId2 := tnAsutus;

	else

		lnAsutusId1 := 0;

		lnAsutusId2 := 99999999;

	end if;



	select count(*) into lnCount from pg_stat_all_tables where UPPER(relname) = 'TMP_SUBKONTOD_REPORT';

	if ifnull(lnCount,0) < 1 then



		create table tmp_subkontod_report (asutusId int default 0, Asutus varchar(254) default space(1), regkood varchar(20) default space(1), 

			aadress text default space(1), konto varchar(20) default space(1), korkonto varchar(20) default space(1),

			tunnus varchar(20) default space(1), dokkpv date default date(),

			algjaak numeric (14,2) default 0, db numeric(14,2) default 0, kr numeric(14,2) default 0, loppjaak numeric(14,2) default 0,

			kood1 varchar(20) default space(1), kood2 varchar(20) default space(1), kood3 varchar(20) default space(1),

			kood4 varchar(20) default space(1), kood5 varchar(20) default space(1), dok varchar(120) default space(1),

			lausend int default 0, 

			timestamp varchar(20) , kpv date default date(), rekvid int )  ;





		GRANT ALL ON TABLE tmp_subkontod_report TO GROUP public;

	else

		delete from tmp_subkontod_report where kpv < date() ;



	end if;



	lcreturn := to_char(now(), 'YYYYMMDDMISSSS');



	-- matrix of subkontod



	if not empty(tcKonto) then

		insert into tmp_subkontod_report (konto, asutusId,  regkood , Asutus, Aadress, algjaak, timestamp, rekvid )  

			select ltrim(rtrim(kontod.kood)) as konto, asutus.id, asutus.regkood, asutus.nimetus as asutus, asutus.aadress, subkontod.algsaldo ,

			lcReturn, tnRekvId from library kontod inner join subkonto subkontod on (subkontod.kontoid = kontod.id and kontod.library = 'KONTOD') 

			inner join asutus on asutus.id = subkontod.asutusId

			where kontod.kood like tcKonto 

			and subkontod.asutusId >= lnAsutusId1 and subkontod.asutusId <= lnAsutusid2 and subkontod.rekvId = tnRekvid;

	else

		insert into tmp_subkontod_report (konto, asutusId,  regkood , Asutus, Aadress, algjaak, timestamp, rekvid )  

			select ltrim(rtrim(kontod.kood)) as konto, asutus.id, asutus.regkood, asutus.nimetus as asutus, asutus.aadress, subkontod.algsaldo ,

			lcReturn, tnRekvId from library kontod inner join subkonto subkontod on (subkontod.kontoid = kontod.id and kontod.library = 'KONTOD') 

			inner join asutus on asutus.id = subkontod.asutusId

			where left(ltrim(rtrim(kontod.kood)),3) in ('103','102','201') 

			and subkontod.asutusId >= lnAsutusId1 and subkontod.asutusId <= lnAsutusid2 and subkontod.rekvId = tnRekvid;

	end if;



		-- saldo andmik



		for v_account in 

			select konto, asutusId from tmp_subkontod_report where timestamp = lcreturn and rekvid = tnRekvId



		loop

			select sum(case when ltrim(rtrim(deebet)) = ltrim(rtrim(v_account.konto)) then summa else 0::numeric(14,2)  end) as db, 

				sum(case when ltrim(rtrim(kreedit)) = ltrim(rtrim(v_account.konto)) then summa else 0::numeric(14,2) end ) as kr into v_saldo

				from journal1 where (ltrim(rtrim(deebet)) = ltrim(rtrim(v_account.konto)) or ltrim(rtrim(kreedit)) = ltrim(rtrim(v_account.konto)))

				and parentId in (select id from journal where kpv <= tdKpv2  

				and rekvid = tnRekvId and asutusId = v_account.asutusid);



			select algJaak into lnAlg from tmp_subkontod_report 

				where timestamp = lcreturn 

				and rekvid = tnRekvId

				and ltrim(rtrim(konto)) = ltrim(rtrim(v_account.konto)) and asutusId = v_account.asutusId;



			lnAlg := ifnull(lnAlg,0) + ifnull(v_saldo.db,0) - ifnull(v_saldo.kr,0);







			update 	tmp_subkontod_report set algjaak = lnAlg

				where timestamp = lcreturn 

				and rekvid = tnRekvId

				and ltrim(rtrim(konto)) = ltrim(rtrim(v_account.konto)) and asutusId = v_account.asutusId;





		end loop;

		delete from tmp_subkontod_report where algjaak = 0  and timestamp = lcreturn and rekvid = tnRekvId;





	return LCRETURN;



end;


$$;

ALTER FUNCTION sp_subkontod_report1(VARCHAR, INTEGER, DATE, DATE, INTEGER) OWNER TO vlad;

