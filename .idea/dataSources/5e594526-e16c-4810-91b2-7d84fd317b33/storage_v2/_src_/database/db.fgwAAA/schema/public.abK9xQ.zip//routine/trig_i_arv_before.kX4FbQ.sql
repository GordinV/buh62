CREATE FUNCTION trig_i_arv_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

lnId	int;



begin



	SELECT id into lnId FROM rekv WHERE rekv.id = new.rekvid;

	if not found then
            RAISE exception 'Cannot add or change record.  Referential integrity rules require a related record in table rekv';
	END if;
	SELECT id into lnId FROM asutus WHERE asutus.id = new.asutusid;

	if not found then
            RAISE exception 'Cannot add or change record.  Referential integrity rules require a related record in table asutus';
        END if;



	return new;

end;

$$;

ALTER FUNCTION trig_i_arv_before() OWNER TO vlad;

