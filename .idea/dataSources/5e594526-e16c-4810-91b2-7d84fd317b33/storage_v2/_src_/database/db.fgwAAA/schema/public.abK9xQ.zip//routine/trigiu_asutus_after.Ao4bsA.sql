CREATE FUNCTION trigiu_asutus_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	v_userid record;
	lresult int;
	lcNotice varchar;
begin
	perform sp_register_oper(new.rekvid,new.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, new.rekvid));
--	update asutus set staatus = fnc_asutusestaatus(new.id);
	return null;
end;
$$;

ALTER FUNCTION trigiu_asutus_after() OWNER TO vlad;

