CREATE FUNCTION get_saldo(formula text, konto text, rv text, tegevus text) RETURNS numeric
    LANGUAGE SQL
AS
$$
select coalesce((SELECT sum(case
                                when $1 like '%KD' then (kr - db) when $1 like '%DK' then (db - kr)
                                else  saldoandmik end)
                 from tmp_andmik s,
                      (select min(aasta) as eelmine_aasta, max(aasta) as aasta, min(kuu) as eelmine_kuu, max(kuu) as kuu from tmp_andmik) aasta
                 where s.tyyp = 2
                   and s.aasta = case when left($1,1) = 'M' then aasta.eelmine_aasta else  aasta.aasta end
--			and s.kuu = case when left($1,1) = 'M' then aasta.eelmine_kuu else  aasta.kuu end
                   and ($2 is null or s.artikkel like trim($2::text ||  '%'))
                   and ($3 is null or trim(s.rahavoog) = $3)
                   and ($4 is null or trim(s.tegev) = $4)),0);
$$;

ALTER FUNCTION get_saldo(TEXT, TEXT, TEXT, TEXT) OWNER TO vlad;

