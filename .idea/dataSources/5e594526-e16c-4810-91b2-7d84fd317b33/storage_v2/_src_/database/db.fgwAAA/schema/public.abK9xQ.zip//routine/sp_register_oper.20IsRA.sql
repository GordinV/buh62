CREATE FUNCTION sp_register_oper(integer, integer, character varying, character varying, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare 
	tnRekvid alias for $1;
	tnDokId alias for $2;
	tcTbl alias for $3;
	tcOper alias for $4;
	tnuserId alias for $5;
	lnuserid int;
begin
	--raise notice 'ID %',tnDokId;

	if tnuserid > 0 then
		insert into raamat (rekvid, userid, operatsioon, dokument, dokid) values 
			(ifnull(tnrekvid,0), tnUserId, ifnull(tcOper,space(1)), tcTbl, ifnull(tnDokId,0));
		return 1;

	else

		return 0;

	end if;


end;
$$;

ALTER FUNCTION sp_register_oper(INTEGER, INTEGER, VARCHAR, VARCHAR, INTEGER) OWNER TO vlad;

