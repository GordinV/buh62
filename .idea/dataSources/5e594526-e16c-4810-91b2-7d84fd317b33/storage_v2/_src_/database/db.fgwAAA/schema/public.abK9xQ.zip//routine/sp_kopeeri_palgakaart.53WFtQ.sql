CREATE FUNCTION sp_kopeeri_palgakaart(integer, integer, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare

	tnid alias for $1;

	tnLepingId alias for $2;

	tnLibId alias for $3;



	lnId int; 

	v_palk_kaart record;





begin







select * into v_palk_kaart from palk_kaart where id = tnId;



-- kontrolin kas on sama kood juba



if (select count(*) from palk_kaart where lepingid = tnLepingid and libId = tnLibId) = 0 then

	-- uut kaart kiri

	insert into palk_kaart ( parentid, lepingid, libid, summa,  percent_ , tulumaks, tulumaar, status,  muud, alimentid, tunnusid ) values 

		(v_palk_kaart.parentid, tnlepingid, tnlibid, v_palk_kaart.summa,  v_palk_kaart.percent_ , v_palk_kaart.tulumaks, v_palk_kaart.tulumaar,

		v_palk_kaart.status,  v_palk_kaart.muud, v_palk_kaart.alimentid, 0);	



	lnId:= cast(CURRVAL('public.palk_kaart_id_seq') as int4);



else

	select id into lnId from palk_kaart where lepingid = tnLepingid and libId = tnLibId;

end if; 

         return  lnId;

end;

$$;

ALTER FUNCTION sp_kopeeri_palgakaart(INTEGER, INTEGER, INTEGER) OWNER TO vlad;

