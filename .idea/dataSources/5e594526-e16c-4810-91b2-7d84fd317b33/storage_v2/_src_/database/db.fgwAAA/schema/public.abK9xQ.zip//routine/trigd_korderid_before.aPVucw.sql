CREATE FUNCTION trigd_korderid_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	lnCount int4;

	v_userid record;


begin

	-- check for user account

	select * into v_userid from userid where id = sp_currentuser(CURRENT_USER::varchar, old.rekvid) and rekvid = old.rekvid;

	if not found or (empty (v_userid.kasutaja_) and empty (v_userid.peakasutaja_)) then

			raise exception 'Ei ole Ćµigused lisada/muudata/kustuta';

			return null;

	end if;





	delete from korder2 where parentid = old.id;


	return OLD;

end;

$$;

ALTER FUNCTION trigd_korderid_before() OWNER TO vlad;

