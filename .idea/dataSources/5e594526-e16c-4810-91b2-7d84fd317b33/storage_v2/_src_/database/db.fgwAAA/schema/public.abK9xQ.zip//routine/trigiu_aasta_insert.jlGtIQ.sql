CREATE FUNCTION trigiu_aasta_insert() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	lresult int;
	lcNotice varchar;
	lnuserId int4;
begin

	if (fnc_aasta_kontrol(new.rekvid, new.kpv)= 0) then
			raise notice 'Viga:Perion on kinnitatud';
	--		return null;
	end if;

	return new;
end;
$$;

ALTER FUNCTION trigiu_aasta_insert() OWNER TO vlad;

