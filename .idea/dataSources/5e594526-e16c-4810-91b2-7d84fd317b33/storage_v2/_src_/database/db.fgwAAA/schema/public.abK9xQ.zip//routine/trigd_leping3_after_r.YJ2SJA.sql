CREATE FUNCTION trigd_leping3_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:='parentid:' + old.parentid::TEXT + '

' +

	'kpv:'+ old.kpv::TEXT + '

' +

	'algkogus:' + old.algkogus::TEXT + '

' +

	'loppkogus:' + old.loppkogus::TEXT + '

' +

	'muud:' + case when ifnull(old.muud,space(1))<>space(1) then 

		old.muud::TEXT + '

' else ' ' end;

	

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (0,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,old.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigd_leping3_after_r() OWNER TO vlad;

