CREATE FUNCTION trigd_journal_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:='rekvid:' + old.rekvid::TEXT + '

' +

	'userid:' + old.userid::TEXT + '

' +

	'kpv:'+ old.kpv::TEXT + '

' +

	'asutusid:' + old.asutusid::TEXT + '

' +

	'selg:' + old.selg + '

' +

	'dok:' + old.dok + '

' +

	'muud:' + case when ifnull(old.muud,space(1))<>space(1) then 

		old.muud::TEXT + '

' else ' ' end +

	'dokid:' + old.dokid::TEXT + '

';

if not empty(old.dok) then
	delete from arvtasu where sorderid = old.id and pankkassa = 3; 

end if;
	

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (old.rekvid,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,old.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigd_journal_after_r() OWNER TO vlad;

