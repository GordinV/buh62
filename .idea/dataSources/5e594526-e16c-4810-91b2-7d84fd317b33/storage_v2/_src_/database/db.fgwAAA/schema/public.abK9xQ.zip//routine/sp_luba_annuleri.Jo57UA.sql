CREATE FUNCTION sp_luba_annuleri(integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare

	tnid alias for $1;

	v_luba record;

	lnResult int; 

	lnDokProp int;

begin

	lnresult = 0;

	lnDokProp = 0;

	select * into v_luba from luba where id = tnId;



--	if v_luba.jaak = 0 then

		lnResult = sp_salvesta_toiming(0, v_luba.parentid,v_luba.id, date(), '', '', date(), 0, 1, 'ANULLERI', '', 0, lnDokProp);

		perform sp_muuda_lubastaatus(tnId, 0);

--	else

--		raise exception 'Viga, Jaak <> 0';

--	end if;

	



return  lnResult;

end;

$$;

ALTER FUNCTION sp_luba_annuleri(INTEGER) OWNER TO vlad;

