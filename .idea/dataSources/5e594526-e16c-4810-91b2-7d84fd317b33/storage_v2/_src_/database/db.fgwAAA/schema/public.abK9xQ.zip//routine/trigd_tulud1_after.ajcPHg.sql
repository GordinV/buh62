CREATE FUNCTION trigd_tulud1_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	lnId int;
begin
	
	-- kustuta lausend
	if old.journalId > 0 then
		perform sp_del_journal(old.journalId,1);
	end if;
		
	-- kirjuta raamatisse teatis
	perform sp_register_oper(old.rekvid,old.id, TG_RELNAME::VARCHAR, TG_OP::VARCHAR, sp_currentuser(CURRENT_USER::varchar, old.rekvid));

	return NULL;
end;
$$;

ALTER FUNCTION trigd_tulud1_after() OWNER TO vlad;

