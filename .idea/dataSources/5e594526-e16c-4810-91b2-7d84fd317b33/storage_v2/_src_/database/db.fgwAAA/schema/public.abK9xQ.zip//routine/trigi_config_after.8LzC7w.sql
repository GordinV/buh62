CREATE FUNCTION trigi_config_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin

         select new.id, "CONFIG_" as tbl

end;

$$;

ALTER FUNCTION trigi_config_after() OWNER TO vlad;

