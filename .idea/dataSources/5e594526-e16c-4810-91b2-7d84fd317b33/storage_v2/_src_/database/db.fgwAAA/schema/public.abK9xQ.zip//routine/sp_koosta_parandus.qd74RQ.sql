CREATE FUNCTION sp_koosta_parandus(integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 

	tnId alias for $1;
	tdKpv date = date();
	v_luba record;
	v_dekl record;
	lnresult int;
	lcAlus varchar;
	l_number integer;
begin
	lnresult = 0;
	select * into v_luba from luba where id = tnId;

	if v_luba.staatus = 0 then
		raise exception 'Luba anulleritud';
		return 0;
	end if;

	lcAlus = 'Dekl. number:'+ltrim(rtrim(v_luba.number))+space(1)+tdkpv::varchar +' nt maksumaksja avaldus ';

	select max(number)+1 into l_number from toiming where lubaId = v_luba.id and tyyp = 'PARANDUS';
	lnresult =  sp_salvesta_toiming(0, v_luba.parentid,v_luba.id, date(), lcAlus, space(1), tdKpv, 0, 0, 'PARANDUS', space(1), 0, 0, coalesce(l_number,1),fnc_currentvaluuta(date()),fnc_currentkuurs(date()));
	Return lnresult;

end;

$$;

ALTER FUNCTION sp_koosta_parandus(INTEGER) OWNER TO vlad;

