CREATE FUNCTION trigu_leping2_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare

	lcSql text;

	lnUsrID int;

begin



lcSql:=

	case when old.parentid <> new.parentid then 

		'parentid:' + old.parentid::text + '

'  else ''

	end +

	

	case when old.nomid <> new.nomid then 

		'nomid:' + old.nomid::text + '

'  else ''

	end +

	

	case when old.kogus <> new.kogus then 

		'kogus:' + old.kogus::text + '

'  else ''

	end +

	

	case when old.hind <> new.hind then 

		'hind:' + old.hind::text + '

'  else ''

	end +

	

	case when old.soodus <> new.soodus then 

		'soodus:' + old.soodus::text + '

'  else ''

	end +

	

	case when old.soodusalg <> new.soodusalg or (IfNull(old.soodusalg,date(1900,01,01)) <> IfNull(new.soodusalg,date(1900,01,01))) then 

		'soodusalg:' + case when ifNull(old.soodusalg,date(1900,01,01)) = date(1900,01,01) then space(1) + '

'  else dtoc(old.soodusalg) +  '

'  end else ''

	end +

	

	case when old.sooduslopp <> new.sooduslopp or (IfNull(old.sooduslopp,date(1900,01,01)) <> IfNull(new.sooduslopp,date(1900,01,01))) then 

		'sooduslopp:' + case when ifNull(old.sooduslopp,date(1900,01,01)) = date(1900,01,01) then space(1) + '

'  else dtoc(old.sooduslopp) +  '

'  end else ''

	end +

	

	case when old.summa <> new.summa then 

		'summa:' + old.summa::text + '

'  else ''

	end +

	

	case when old.status <> new.status then 

		'status:' + old.status::text + '

'  else ''

	end +

	

	case when old.muud <> new.muud or (IfNull(old.muud,space(1)) <> IfNull(new.muud,space(1))) then 

		'muud:' + case when ifNull(old.muud,space(1)) = space(1) then space(1) + '

'  else old.muud::text + '

'  end else ''

	end +

	

	case when old.formula <> new.formula then 

		'formula:' + old.formula::text + '

'  else ''

	end +

	

	case when old.kbm <> new.kbm then 

		'kbm:' + old.kbm::text + '

'  else ''

	end;

	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;

	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 

		VALUES (0,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,new.id,lcSql);

	return null;

end;

$$;

ALTER FUNCTION trigu_leping2_after_r() OWNER TO vlad;

