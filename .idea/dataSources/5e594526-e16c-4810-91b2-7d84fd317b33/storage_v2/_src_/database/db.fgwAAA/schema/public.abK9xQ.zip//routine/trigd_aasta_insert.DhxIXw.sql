CREATE FUNCTION trigd_aasta_insert() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	lresult int;
	lcNotice varchar;
	lnuserId int4;
begin

	if (fnc_aasta_kontrol(old.rekvid, old.kpv)= 0) then
--			raise notice 'Viga: Perion on kinnitatud';
--			raise exception 'Viga: Perion on kinnitatud';
--			return null;
	end if;

	return old;
end;
$$;

ALTER FUNCTION trigd_aasta_insert() OWNER TO vlad;

