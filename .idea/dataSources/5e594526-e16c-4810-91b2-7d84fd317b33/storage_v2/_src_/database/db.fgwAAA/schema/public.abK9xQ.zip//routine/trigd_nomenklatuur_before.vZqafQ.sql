CREATE FUNCTION trigd_nomenklatuur_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 


	lnCount int4;


begin

	 select count(id) into lnCount from (SELECT  id FROM Pv_oper WHERE nomid = old.Id 


	 union 


	 SELECT  id FROM korder2 WHERE nomid = old.Id 


	 union 


	 SELECT  id FROM arvtasu WHERE nomid = old.Id 


	 union 


	 SELECT id FROM mk1 WHERE nomid = old.Id 


	 union 


	 SELECT id FROM avans2 WHERE nomid = old.Id 

	 union 


	 SELECT  id FROM arv1 WHERE nomid = old.Id ) a;


	 if lnCount > 0 then


	-- ei saa kustuta


		raise notice 'ei saa kustuta '; 


		 return NULL;


	else


		return OLD;


	end if;


end;

$$;

ALTER FUNCTION trigd_nomenklatuur_before() OWNER TO vlad;

