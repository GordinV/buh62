CREATE FUNCTION "isnull"(integer, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
begin

	if $1 is null then

		 return  $2;

	end if;

end;

$$;

ALTER FUNCTION "isnull"(INTEGER, INTEGER) OWNER TO vlad;

