CREATE FUNCTION sp_salvesta_pakett(integer, integer, integer, numeric, numeric, integer, text) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	tnid alias for $1;
	tnLibid alias for $2;
	tnNomId alias for $3;
	tnHind alias for $4;
	tnKogus alias for $5;
	tnStatus alias for $6;
	ttFormula alias for $7;


	lnId int; 
	lrCurRec record;
begin

	if tnId = 0 then
			-- lisame uus kiri
		insert into pakett (libid, nomid, hind, kogus,status, formula)
			values (tnLibId, tnNomId, tnHind, tnKogus,tnStatus,ttFormula);
	else
		update pakett set
			nomid = tnNomId,
			libid = tnLibId,
			hind = tnHind,
			kogus = tnKogus,
			status = tnStatus,
			formula = ttFormula
		where id = tnId;

	end if;


         return  tnId;
end;
$$;

ALTER FUNCTION sp_salvesta_pakett(INTEGER, INTEGER, INTEGER, NUMERIC, NUMERIC, INTEGER, TEXT) OWNER TO vlad;

