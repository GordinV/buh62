CREATE FUNCTION haridus() RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare 

	v_journal record;

	v_journal1 record;

	v_journalId record;

	v_tunnus record;

	v_tunnusinf record;

	lnId	int;



begin



--	library

	insert into library (rekvid, kood, nimetus, library, muud, tun1, tun2, tun3, tun4, tun5) 

	select 32, kood, nimetus, library, muud, tun1, tun2, tun3, tun4, tun5 from library where rekvid = 11;



--	nomenklatuur



-- kontoinf



	insert into kontoinf (parentid, type , formula , aasta , liik , pohikonto , rekvid , algsaldo)

	select parentid, type , formula , aasta , liik , pohikonto , 32 , algsaldo from kontoinf where rekvid = 11;
 



-- subkonto



	insert into subkonto (kontoid , asutusid , algsaldo , aasta ,  rekvid) 

	select kontoid , asutusid , algsaldo , aasta ,  32 from subkonto where rekvid = 11;




-- tunnusinf

	insert into tunnusinf (tunnusid , kontoid , rekvid , algsaldo, muud) 

	select tunnusid , kontoid , 32 , algsaldo, muud from tunnusinf where rekvid = 11;


	for v_tunnus in 

		select * from library where rekvid = 11 and library = 'TUNNUS'

		loop

			-- id in uus asutus

			select id into lnId from library where rekvid = 32 and kood = v_tunnus.kood and library = 'TUNNUS';

			if ifnull(lnId,0) > 0 then

				update tunnusInf set tunnusid = lnId where tunnusId = v_tunnus.id and rekvid = 32;

			end if;

		end loop;



-- journal



	for v_journal in

		select * from journal where rekvid = 11 

		loop

			insert into journal (rekvid, userid, kpv, asutusId, selg, dok, muud, dokid) values (

			32,  v_journal.userid, v_journal.kpv, v_journal.asutusId, v_journal.selg, v_journal.dok, v_journal.muud, v_journal.dokid);



			select id into lnId from journal where rekvid = 32 order by id desc limit 1;

		

			insert into journal1 (parentid , summa , dokument , muud, kood1, kood2 , kood3 , kood4 , kood5 , 

				deebet ,  lisa_k , kreedit , lisa_d , valuuta , kuurs , valsumma , tunnus)

			select lnid , summa , dokument , muud, kood1, kood2 , kood3 , kood4 , kood5 , 

			deebet ,  lisa_k , kreedit , lisa_d , valuuta , kuurs , valsumma , tunnus from journal1 where parentid = v_journal.id;
		

			select * into v_journalid from journalid where journalid = v_journal.id;



			update journalid set number = v_journalId.number where journalid = lnId and rekvid = 32;





		end loop;



     return 1;

end;

$$;

ALTER FUNCTION haridus() OWNER TO vlad;

