CREATE FUNCTION trigi_markused_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin

	UPDATE DBASE SET LASTNUM = NEW.ID WHERE id = 115;	 

	return NULL;

end;

$$;

ALTER FUNCTION trigi_markused_after() OWNER TO vlad;

