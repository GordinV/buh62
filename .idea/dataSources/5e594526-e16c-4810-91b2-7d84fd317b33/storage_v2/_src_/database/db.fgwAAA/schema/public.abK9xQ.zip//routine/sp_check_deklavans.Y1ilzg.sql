CREATE FUNCTION sp_check_deklavans(integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	tnid alias for $1;
	lnSumma numeric;
	lnResult int; 
	v_avans record;
	v_dekl record;
begin
	lnresult = 1;
	select * into v_dekl from toiming where id = tnId;
		-- check for avans
		select sum(summa) into lnSumma from dekltasu where deklId = 0 and parentId = v_dekl.ParentId;
		if lnSumma > 0 then
			-- on avans
			raise notice 'on avans';
			lnSumma = v_dekl.Summa;
			for v_avans in
				select * from dekltasu where deklId = 0 and parentID = v_dekl.parentId
			loop
				-- osa maks
				if v_avans.summa > lnSumma then
					-- kui avans suurem kui dekl.summa siis 
					raise notice 'avansi summa suurem kui dekl summa';
					update dekltasu 
						set deklId = v_dekl.Id,
						summa = tnSumma 
						where id = v_avans.id;
					
					insert into dekltasu (parentid, deklId, tasuId, tasuKpv, volgKpv, summa) values
						(v_avans.parentid, 0, v_avans.tasuid, v_avans.kpv, 0, (v_avans.summa - v_dekl.Summa));


					-- parandame dekl. status
					raise notice 'parandame dekl. status';
					perform sp_muuda_deklstaatus(v_dekl.Id, 3);


					exit;
				else
					-- avans vaiksem kui dekl.summa
					raise notice 'avansi summa vaiksem kui dekl summa';
					update dekltasu set deklid = v_dekl.id where id = v_avans.id;

					-- parandame dekl. status
					raise notice 'parandame dekl. status';
					perform sp_muuda_deklstaatus(v_dekl.Id, 2);

					lnSumma = lnSumma - v_avans.summa;

					raise notice 'dekl summa jaak %',lnSumma;
					-- lnSumma - avansi jaak
					if lnSumma = 0 then
						exit;
					end if;
				end if;
	


			end loop;
		end if;


return  lnResult;
end;
$$;

ALTER FUNCTION sp_check_deklavans(INTEGER) OWNER TO vlad;

