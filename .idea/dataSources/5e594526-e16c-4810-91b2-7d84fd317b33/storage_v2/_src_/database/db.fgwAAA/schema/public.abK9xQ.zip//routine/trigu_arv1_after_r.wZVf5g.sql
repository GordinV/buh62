CREATE FUNCTION trigu_arv1_after_r() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare
	lcSql text;
	lnUsrID int;
begin

lcSql:=
	case when old.parentid <> new.parentid then 
		'parentid:' + old.parentid::text + '
'  else ''
	end +
	
	case when old.nomid <> new.nomid then 
		'nomid:' + old.nomid::text + '
'  else ''
	end +
	
	case when old.kogus <> new.kogus then 
		'kogus:' + old.kogus::text + '
'  else ''
	end +
	
	case when old.hind <> new.hind then 
		'hind:' + old.hind::text + '
'  else ''
	end +
	
	case when old.soodus <> new.soodus then 
		'soodus:' + old.soodus::text + '
'  else ''
	end +
	
	case when old.kbm <> new.kbm then 
		'kbm:' + old.kbm::text + '
'  else ''
	end +
	
	case when old.maha <> new.maha then 
		'maha:' + old.maha::text + '
'  else ''
	end +
	
	case when old.summa <> new.summa then 
		'summa:' + old.summa::text + '
'  else ''
	end +
	
	case when old.muud <> new.muud or (IfNull(old.muud,space(1)) <> IfNull(new.muud,space(1))) then 
		'muud:' + case when ifNull(old.muud,space(1)) = space(1) then space(1) + '
'  else old.muud::text + '
'  end else ''
	end +
	
	case when old.kood1 <> new.kood1 then 
		'kood1:' + old.kood1::text + '
'  else ''
	end +
	
	case when old.kood2 <> new.kood2 then 
		'kood2:' + old.kood2::text + '
'  else ''
	end +
	
	case when old.kood3 <> new.kood3 then 
		'kood3:' + old.kood3::text + '
'  else ''
	end +
	
	case when old.kood4 <> new.kood4 then 
		'kood4:' + old.kood4::text + '
'  else ''
	end +
	
	case when old.kood5 <> new.kood5 then 
		'kood5:' + old.kood5::text + '
'  else ''
	end +
	
	case when old.konto <> new.konto then 
		'konto:' + old.konto::text + '
'  else ''
	end +
	
	case when old.tp <> new.tp then 
		'tp:' + old.tp::text + '
'  else ''
	end +
	
	case when old.kbmta <> new.kbmta then 
		'kbmta:' + old.kbmta::text + '
'  else ''
	end +
	
	case when old.isikid <> new.isikid then 
		'isikid:' + old.isikid::text + '
'  else ''
	end +
	
	case when old.tunnus <> new.tunnus then 
		'tunnus:' + old.tunnus::text + '
'  else ''
	end;
	SELECT id INTO lnUsrID from userid WHERE kasutaja = CURRENT_USER::VARCHAR;
	INSERT INTO raamat (rekvid,userid,operatsioon,dokument,dokid,sql) 
		VALUES (0,lnUsrId,TG_OP::VARCHAR,TG_RELNAME::VARCHAR,new.id,lcSql);
	return null;
end;
$$;

ALTER FUNCTION trigu_arv1_after_r() OWNER TO vlad;

