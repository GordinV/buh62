CREATE FUNCTION trigiu_toiming_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 

	lnresult int;

begin
	if ifnull(new.journalid,0) = 0 then
		new.journalid = 0;
	end if; 

	lnresult = sp_recalc_rekljaak(new.lubaid);



	return null;

end;

$$;

ALTER FUNCTION trigiu_toiming_after() OWNER TO vlad;

