CREATE FUNCTION trigi_palk_kaart_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin



	if  empty (new.libId) or empty (new.lepingId) or empty (new.summa) then


		-- ŠæŃ€Š¾Š²ŠµŃ€ŠŗŠ° Š½Š° Š½Š°Š»ŠøŃ‡ŠøŠµ Š´Š°Š½Š½Ń‹Ń…


		raise notice ' Puudub andmed';


		return null;


	end if;
	if (select count(id) from palk_kaart where lepingid = new.lepingid and libid = new.libid and id <> new.id) > 0 then
		raise notice ' Andmed koorduvad ';
		return null;
	end if;




	return new;

end;

$$;

ALTER FUNCTION trigi_palk_kaart_before() OWNER TO vlad;

