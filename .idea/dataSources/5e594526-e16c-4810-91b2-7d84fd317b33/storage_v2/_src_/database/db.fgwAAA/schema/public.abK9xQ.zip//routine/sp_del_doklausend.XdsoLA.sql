CREATE FUNCTION sp_del_doklausend(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 
	tnId alias for $1;
	lnCount int4;




begin



	DELETE FROM doklausend WHERE parentid = tnId;



	DELETE FROM doklausheader WHERE id = tnId;



	Return 1;



end;


$$;

ALTER FUNCTION sp_del_doklausend(INTEGER, INTEGER) OWNER TO vlad;

