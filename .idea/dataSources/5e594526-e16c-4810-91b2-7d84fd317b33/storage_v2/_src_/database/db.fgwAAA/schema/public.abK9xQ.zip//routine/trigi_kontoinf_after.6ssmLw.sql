CREATE FUNCTION trigi_kontoinf_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin

	UPDATE DBASE SET LASTNUM = NEW.ID WHERE id = 102;	 

	return NULL;

end;

$$;

ALTER FUNCTION trigi_kontoinf_after() OWNER TO vlad;

