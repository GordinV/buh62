CREATE VIEW com_tululiigid(id, kood, nimetus, rekvid, tun1, tun2, tun3, tun4, tun5) AS
SELECT qry.id,
       qry.kood,
       qry.nimetus,
       qry.rekvid,
       qry.tun1,
       qry.tun2,
       qry.tun3,
       qry.tun4,
       qry.tun5
FROM (SELECT 0                         AS id,
             ''::CHARACTER VARYING(20) AS kood,
             ''::CHARACTER VARYING(20) AS nimetus,
             NULL::INTEGER             AS rekvid,
             NULL::INTEGER             AS tun1,
             NULL::INTEGER             AS tun2,
             NULL::INTEGER             AS tun3,
             NULL::INTEGER             AS tun4,
             NULL::INTEGER             AS tun5
      UNION
      SELECT l.id,
             l.kood,
             l.nimetus,
             l.rekvid,
             l.tun1,
             l.tun2,
             l.tun3,
             l.tun4,
             l.tun5
      FROM libs.library l
      WHERE ((l.library = 'MAKSUKOOD'::BPCHAR) AND (l.status <> 3))) qry
ORDER BY qry.kood;

ALTER TABLE com_tululiigid
    OWNER TO vlad;

