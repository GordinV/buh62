CREATE FUNCTION ifnull(integer, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
begin
	if $1 isnull then
		 return  $2;
	else
		return $1;
	end if;
end;
$$;

ALTER FUNCTION ifnull(INTEGER, INTEGER) OWNER TO vlad;

