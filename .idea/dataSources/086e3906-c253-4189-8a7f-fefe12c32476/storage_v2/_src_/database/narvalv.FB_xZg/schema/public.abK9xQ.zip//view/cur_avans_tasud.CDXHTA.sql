CREATE VIEW cur_avans_tasud(dok_number, dok_kpv, isik, isikukood, id, parentid, dokid, liik, muud, summa, kpv, selg,
                            number, rekvid) AS
SELECT a1.number AS dok_number,
       a1.kpv    AS dok_kpv,
       a.nimetus AS isik,
       a.regkood AS isikukood,
       a3.id,
       a3.parentid,
       a3.dokid,
       a3.liik,
       a3.muud,
       a3.summa,
       j.kpv,
       j.selg,
       jid.number,
       j.rekvid
FROM ((((docs.avans3 a3
    JOIN docs.avans1 a1 ON ((a1.id = a3.parentid)))
    JOIN libs.asutus a ON ((a.id = a1.asutusid)))
    LEFT JOIN docs.journal j ON ((j.parentid = a3.dokid)))
         LEFT JOIN docs.journalid jid ON ((jid.journalid = j.id)));

ALTER TABLE cur_avans_tasud
    OWNER TO vlad;

