CREATE VIEW curladujaak(rekvid, hind, jaak, kpv, kood, nimetus, uhik, grupp, minjaak, tahtaeg) AS
SELECT ladu_jaak.rekvid,
       ladu_jaak.hind,
       ladu_jaak.jaak,
       ladu_jaak.kpv,
       nomenklatuur.kood,
       nomenklatuur.nimetus,
       nomenklatuur.uhik,
       grupp.nimetus      AS grupp,
       nomenklatuur.kogus AS minjaak,
       arv1.tahtaeg
FROM ((((ladu_jaak
    JOIN nomenklatuur ON ((ladu_jaak.nomid = nomenklatuur.id)))
    JOIN arv1 ON ((ladu_jaak.dokitemid = arv1.id)))
    JOIN ladu_grupp ON ((ladu_grupp.nomid = nomenklatuur.id)))
         JOIN library grupp ON ((grupp.id = ladu_grupp.parentid)));

ALTER TABLE curladujaak
    OWNER TO vlad;

