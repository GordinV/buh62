CREATE VIEW qryjournalid(id, number, rekvid, aasta, journal1id) AS
SELECT journalid.id,
       journalid.number,
       journalid.rekvid,
       journalid.aasta,
       journal1.id AS journal1id
FROM (journalid
         JOIN journal1 ON ((journalid.journalid = journal1.parentid)));

ALTER TABLE qryjournalid
    OWNER TO vlad;

