CREATE VIEW v_saldoaruanne(konto, tp, tegev, allikas, rahavoo, db, kr) AS
SELECT qrysaldoaruanne.konto,
       qrysaldoaruanne.tp,
       qrysaldoaruanne.tegev,
       qrysaldoaruanne.allikas,
       qrysaldoaruanne.rahavoo,
       sum(qrysaldoaruanne.deebet)  AS db,
       sum(qrysaldoaruanne.kreedit) AS kr
FROM (SELECT curjournal.deebet   AS konto,
             curjournal.lisa_d   AS tp,
             curjournal.kood1    AS tegev,
             curjournal.kood2    AS allikas,
             curjournal.kood3    AS rahavoo,
             curjournal.summa    AS deebet,
             (0)::NUMERIC(12, 4) AS kreedit
      FROM curjournal
      UNION ALL
      SELECT curjournal.kreedit  AS konto,
             curjournal.lisa_d   AS tp,
             curjournal.kood1    AS tegev,
             curjournal.kood2    AS allikas,
             curjournal.kood3    AS rahavoo,
             (0)::NUMERIC(12, 4) AS deebet,
             curjournal.summa    AS kreedit
      FROM curjournal) qrysaldoaruanne
GROUP BY qrysaldoaruanne.konto, qrysaldoaruanne.tp, qrysaldoaruanne.tegev, qrysaldoaruanne.allikas,
         qrysaldoaruanne.rahavoo
ORDER BY qrysaldoaruanne.konto, qrysaldoaruanne.tp, qrysaldoaruanne.tegev, qrysaldoaruanne.allikas,
         qrysaldoaruanne.rahavoo;

ALTER TABLE v_saldoaruanne
    OWNER TO vlad;

