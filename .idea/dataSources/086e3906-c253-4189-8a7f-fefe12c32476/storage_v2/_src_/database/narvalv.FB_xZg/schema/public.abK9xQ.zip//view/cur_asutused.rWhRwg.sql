CREATE VIEW cur_asutused(id, regkood, nimetus, omvorm, aadress, tp, email, mark, kehtivus, staatus) AS
SELECT a.id,
       a.regkood,
       a.nimetus,
       a.omvorm,
       a.aadress,
       a.tp,
       a.email,
       a.mark,
       (COALESCE((((a.properties ->> 'kehtivus'::TEXT))::DATE)::TIMESTAMP WITHOUT TIME ZONE,
                 (CURRENT_DATE + '10 years'::INTERVAL)))::DATE AS kehtivus,
       a.staatus
FROM libs.asutus a
WHERE (a.staatus <> 3);

ALTER TABLE cur_asutused
    OWNER TO vlad;

