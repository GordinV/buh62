CREATE FUNCTION month() RETURNS integer
    LANGUAGE plpgsql
AS
$$
begin
         return  cast(extract(month from date()) as int4);
end;
$$;

ALTER FUNCTION month() OWNER TO vlad;

