CREATE FUNCTION "isnull"(numeric, numeric) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
begin
	if $1 is null then
		 return  $2;
	end if;
end;
$$;

ALTER FUNCTION "isnull"(NUMERIC, NUMERIC) OWNER TO vlad;

