CREATE FUNCTION "_diffmonth"(date_begin date, date_end date) RETURNS integer
    LANGUAGE SQL
AS
$$
select (case 
	when (date_part('day',$2)>=date_part('day',$1) or date_part('day',$2+1)=1) then 0 else -1 end
+(date_part('year',$2)-date_part('year',$1))*12
+(date_part('month',$2)-date_part('month',$1)))::integer;
$$;

ALTER FUNCTION "_diffmonth"(DATE, DATE) OWNER TO vlad;

