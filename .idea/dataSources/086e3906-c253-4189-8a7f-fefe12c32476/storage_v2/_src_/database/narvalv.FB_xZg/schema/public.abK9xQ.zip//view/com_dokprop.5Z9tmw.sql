CREATE VIEW com_dokprop(id, nimetus, dok, kood, konto, kbmkonto, kood1, kood2, kood3, kood5, asutusid, rekvid) AS
SELECT d.id,
       d.selg                                                    AS nimetus,
       l.nimetus                                                 AS dok,
       l.kood,
       ((d.details ->> 'konto'::TEXT))::CHARACTER VARYING(20)    AS konto,
       ((d.details ->> 'kbmkonto'::TEXT))::CHARACTER VARYING(20) AS kbmkonto,
       ((d.details ->> 'kood1'::TEXT))::CHARACTER VARYING(20)    AS kood1,
       ((d.details ->> 'kood2'::TEXT))::CHARACTER VARYING(20)    AS kood2,
       ((d.details ->> 'kood3'::TEXT))::CHARACTER VARYING(20)    AS kood3,
       ((d.details ->> 'kood5'::TEXT))::CHARACTER VARYING(20)    AS kood5,
       d.asutusid,
       d.rekvid
FROM (libs.library l
         JOIN libs.dokprop d ON ((l.id = d.parentid)))
WHERE ((l.library = 'DOK'::BPCHAR) AND (d.status <> 3))
ORDER BY l.kood;

ALTER TABLE com_dokprop
    OWNER TO vlad;

