CREATE VIEW cur_eelarve_taitmine_arhiiv(docs_ids, kuu, aasta, rekvid, asutus, parentid, tunnus, summa, artikkel, tegev,
                                        allikas, nimetus, is_kulud) AS
SELECT NULL::INTEGER[] AS docs_ids,
       e.kuu,
       e.aasta,
       e.rekvid,
       rekv.nimetus    AS asutus,
       rekv.parentid,
       e.tunnus,
       sum(e.summa)    AS summa,
       e.kood5         AS artikkel,
       e.kood1         AS tegev,
       e.kood2         AS allikas,
       l.nimetus,
       e.is_kulud
FROM ((eelarve.eeltaitmine e
    JOIN ou.rekv rekv ON ((e.rekvid = rekv.id)))
         LEFT JOIN libs.library l ON (((l.kood = e.kood5) AND (l.library = 'TULUDEALLIKAD'::BPCHAR) AND (l.tun5 = 1))))
GROUP BY e.aasta, e.kuu, e.rekvid, rekv.parentid, rekv.nimetus, e.kood1, e.kood5, e.kood2, e.tunnus, l.nimetus,
         e.is_kulud;

ALTER TABLE cur_eelarve_taitmine_arhiiv
    OWNER TO vlad;

