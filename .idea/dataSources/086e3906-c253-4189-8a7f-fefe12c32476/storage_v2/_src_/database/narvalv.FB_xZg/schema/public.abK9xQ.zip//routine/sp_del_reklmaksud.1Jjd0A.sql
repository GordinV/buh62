CREATE FUNCTION sp_del_reklmaksud(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 
	tnId alias for $1;
	lnJournalId int;
begin

	select journalid into lnJournalId from toiming where id = tnId;
	if lnJournalId > 0 then
		perform sp_del_journal(lnJournalId,1);
	end if;

	DELETE FROM toiming WHERE id = tnId;


	Return 1;


end;


$$;

ALTER FUNCTION sp_del_reklmaksud(INTEGER, INTEGER) OWNER TO vlad;

