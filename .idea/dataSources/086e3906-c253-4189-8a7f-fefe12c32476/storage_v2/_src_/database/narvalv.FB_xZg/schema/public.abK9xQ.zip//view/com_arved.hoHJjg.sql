CREATE VIEW com_arved(id, arv_id, number, kpv, summa, liik, asutus, asutusid, arvid, tasudok, tasud, rekvid, jaak) AS
SELECT d.id,
       arv.id                                                           AS arv_id,
       arv.number,
       arv.kpv,
       arv.summa,
       arv.liik,
       ((rtrim((asutus.nimetus)::TEXT) || ' '::TEXT) ||
        ((rtrim((asutus.omvorm)::TEXT))::CHARACTER VARYING(120))::TEXT) AS asutus,
       arv.asutusid,
       arv.arvid,
       arv.tasudok,
       arv.tasud,
       arv.rekvid,
       arv.jaak
FROM ((docs.doc d
    JOIN docs.arv arv ON ((d.id = arv.parentid)))
         JOIN libs.asutus asutus ON ((asutus.id = arv.asutusid)))
ORDER BY arv.number;

ALTER TABLE com_arved
    OWNER TO vlad;

