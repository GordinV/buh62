CREATE FUNCTION fncarvviimanesaldo(integer) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
declare 
	tnArvId ALIAS FOR $1;
	lnJaak numeric;
	lnArvSumma numeric;
	lnTasuSumma numeric;

BEGIN

	select sum(summa*ifnull(dokvaluuta1.kuurs,1)) into lnArvSumma 
		from arv left outer join  dokvaluuta1 on (arv.id = dokvaluuta1.dokid and dokvaluuta1.dokliik = 3)  
		where arv.id = tnArvId;

	select summa * ifnull(dokvaluuta1.kuurs,1) into lnTasuSumma 
		from arvtasu left outer join dokvaluuta1 on (arvtasu.id = dokvaluuta1.dokid and dokvaluuta1.dokliik = 21)
		where arvid = tnArvId order by kpv desc limit 1;

	lnJaak = ifnull(lnTasuSumma ,0);
	if lnJaak = 0 then
		lnJaak = lnArvSumma;
	end if;	


RETURN lnJaak;


end;


$$;

ALTER FUNCTION fncarvviimanesaldo(INTEGER) OWNER TO vlad;

