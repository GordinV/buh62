CREATE FUNCTION "isnull"(character, character) RETURNS character
    LANGUAGE plpgsql
AS
$$
begin
	if $1 is null then
		 return  $2;
	end if;
end;
$$;

ALTER FUNCTION "isnull"(CHAR, CHAR) OWNER TO vlad;

