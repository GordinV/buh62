CREATE VIEW fakttulud(kood) AS
SELECT DISTINCT "left"(((ltrim(rtrim((library.kood)::TEXT)))::BPCHAR + '%'::BPCHAR), 20) AS kood
FROM library
WHERE (library.library = 'TULUKONTOD'::BPCHAR)
ORDER BY ("left"(((ltrim(rtrim((library.kood)::TEXT)))::BPCHAR + '%'::BPCHAR), 20));

ALTER TABLE fakttulud
    OWNER TO vlad;

