CREATE FUNCTION empty(date) RETURNS boolean
    LANGUAGE plpgsql
AS
$$
begin

	if $1 is null or year($1) <  year (now()::date)-100 then

		return true;

	else

		return false;

	end if;

end;

$$;

ALTER FUNCTION empty(DATE) OWNER TO vlad;

