CREATE VIEW curvaravendor(id, rekvid, regkood, nimetus, omvorm, aadress, kontakt, tel, faks, email, muud, nomid) AS
SELECT asutus.id,
       asutus.rekvid,
       asutus.regkood,
       asutus.nimetus,
       asutus.omvorm,
       asutus.aadress,
       asutus.kontakt,
       asutus.tel,
       asutus.faks,
       asutus.email,
       asutus.muud,
       arv1.nomid
FROM ((asutus
    JOIN arv ON ((arv.asutusid = asutus.id)))
         JOIN arv1 ON ((arv1.parentid = arv.id)))
WHERE ((arv.liik = 1) AND (arv1.nomid IN (SELECT curnomjaak.nomid
                                          FROM curnomjaak)));

ALTER TABLE curvaravendor
    OWNER TO vlad;

