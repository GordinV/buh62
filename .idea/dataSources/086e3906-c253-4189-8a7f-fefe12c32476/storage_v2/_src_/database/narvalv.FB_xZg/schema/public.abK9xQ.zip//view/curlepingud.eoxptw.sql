CREATE VIEW curlepingud(id, rekvid, number, kpv, tahtaeg, selgitus, asutus, asutusid, objkood, objnimi, maja, korter,
                        pakett) AS
SELECT leping1.id,
       leping1.rekvid,
       leping1.number,
       leping1.kpv,
       ifnull((dtoc(leping1.tahtaeg))::BPCHAR, space(20))                                                            AS tahtaeg,
       (leping1.selgitus)::BPCHAR                                                                                    AS selgitus,
       (((ltrim(rtrim((asutus.nimetus)::TEXT)))::BPCHAR + space(1)) +
        (ltrim(rtrim((asutus.omvorm)::TEXT)))::BPCHAR)                                                               AS asutus,
       asutus.id                                                                                                     AS asutusid,
       (ifnull(objekt.kood, space(20)))::CHARACTER VARYING                                                           AS objkood,
       (ifnull(objekt.nimetus, space(254)))::CHARACTER VARYING                                                       AS objnimi,
       ifnull(obj.nait14, (0)::NUMERIC)                                                                              AS maja,
       ifnull(obj.nait15, (0)::NUMERIC)                                                                              AS korter,
       (ifnull(pakett.kood, space(20)))::CHARACTER VARYING                                                           AS pakett
FROM ((((leping1
    JOIN asutus ON ((leping1.asutusid = asutus.id)))
    LEFT JOIN library objekt ON ((objekt.id = leping1.objektid)))
    LEFT JOIN objekt obj ON ((objekt.id = obj.parentid)))
         LEFT JOIN library pakett ON ((pakett.id = leping1.pakettid)));

ALTER TABLE curlepingud
    OWNER TO vlad;

