CREATE VIEW com_ladu_oper(id, kood, nimetus, rekvid, liik) AS
SELECT qry.id,
       qry.kood,
       qry.nimetus,
       qry.rekvid,
       qry.liik
FROM (SELECT 0                         AS id,
             ''::CHARACTER VARYING(20) AS kood,
             ''::CHARACTER VARYING(20) AS nimetus,
             NULL::INTEGER             AS rekvid,
             0                         AS liik
      UNION
      SELECT l.id,
             l.kood,
             l.nimetus,
             l.rekvid,
             l.tun1 AS liik
      FROM libs.library l
      WHERE ((l.library = 'LADU_OPER'::BPCHAR) AND (l.status <> 3))) qry
ORDER BY qry.kood;

ALTER TABLE com_ladu_oper
    OWNER TO vlad;

