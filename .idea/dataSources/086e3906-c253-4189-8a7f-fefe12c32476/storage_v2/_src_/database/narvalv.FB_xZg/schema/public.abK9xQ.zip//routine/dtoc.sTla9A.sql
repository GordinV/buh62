CREATE FUNCTION dtoc(date) RETURNS character varying
    LANGUAGE plpgsql
AS
$$
declare
       lcString varchar;
begin
     return to_char($1,'DD.MM.YYYY')::varchar;
end;
$$;

ALTER FUNCTION dtoc(DATE) OWNER TO vlad;

