CREATE VIEW cur_lepingud(id, rekvid, number, kpv, tahtaeg, selgitus, asutus, asutusid, maja, korter, pakett, objkood,
                         objnimi) AS
SELECT d.id,
       l.rekvid,
       l.number,
       l.kpv,
       l.tahtaeg,
       (l.selgitus)::CHARACTER VARYING(254)                                                          AS selgitus,
       (ltrim(rtrim((a.nimetus)::TEXT)))::CHARACTER VARYING(254)                                     AS asutus,
       l.asutusid,
       COALESCE((((objekt.properties)::JSONB ->> 'nait14'::TEXT))::NUMERIC, (0)::NUMERIC)            AS maja,
       COALESCE((((objekt.properties)::JSONB ->> 'nait15'::TEXT))::NUMERIC, (0)::NUMERIC)            AS korter,
       (COALESCE(((objekt.properties)::JSONB ->> 'pakett'::TEXT), ''::TEXT))::CHARACTER VARYING(254) AS pakett,
       (COALESCE(objekt.kood, ''::BPCHAR))::CHARACTER VARYING(20)                                    AS objkood,
       (COALESCE(objekt.nimetus, ''::BPCHAR))::CHARACTER VARYING(254)                                AS objnimi
FROM (((docs.doc d
    JOIN docs.leping1 l ON ((l.parentid = d.id)))
    JOIN libs.asutus a ON ((l.asutusid = a.id)))
         LEFT JOIN libs.library objekt ON ((objekt.id = l.objektid)));

ALTER TABLE cur_lepingud
    OWNER TO vlad;

