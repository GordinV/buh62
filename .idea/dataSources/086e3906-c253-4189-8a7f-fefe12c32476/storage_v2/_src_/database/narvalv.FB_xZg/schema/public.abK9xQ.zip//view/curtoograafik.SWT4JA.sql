CREATE VIEW curtoograafik(isik, osakond, amet, id, lepingid, kuu, aasta, tund, rekvid, asutusid) AS
SELECT comtooleping.isik,
       comtooleping.osakond,
       comtooleping.amet,
       toograf.id,
       toograf.lepingid,
       toograf.kuu,
       toograf.aasta,
       toograf.tund,
       comtooleping.rekvid,
       comtooleping.parentid AS asutusid
FROM (comtooleping
         JOIN toograf ON ((comtooleping.id = toograf.lepingid)));

ALTER TABLE curtoograafik
    OWNER TO vlad;

