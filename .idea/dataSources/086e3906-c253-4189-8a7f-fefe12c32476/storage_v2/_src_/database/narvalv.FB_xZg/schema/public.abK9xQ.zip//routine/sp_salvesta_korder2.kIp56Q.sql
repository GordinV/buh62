CREATE FUNCTION sp_salvesta_korder2(integer, integer, integer, character, numeric, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, numeric, character varying) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	tnid alias for $1;
	tnparentid alias for $2;
	tnnomid alias for $3;
	tcnimetus alias for $4;
	tnsumma alias for $5;
	tckonto alias for $6;
	tckood1 alias for $7;
	tckood2 alias for $8;
	tckood3 alias for $9;
	tckood4 alias for $10;
	tckood5 alias for $11;
	tctp alias for $12;
	tctunnus alias for $13;
	tcValuuta alias for $14;
	tnKuurs alias for $15;
	tcProj alias for $16;
	lnkorder2Id int;
	lnId int; 
	lrCurRec record;
	v_dokvaluuta record;
begin

if tnId = 0 then
	-- uus kiri
	insert into korder2 (parentid,nomid,nimetus,summa,konto,kood1,kood2,kood3,kood4,kood5,tp,tunnus,proj) 
		values (tnparentid,tnnomid,tcnimetus,tnsumma,tckonto,tckood1,tckood2,tckood3,tckood4,tckood5,tctp,tctunnus,tcProj) returning id into lnkorder2Id;

	if lnkorder2Id is null or lnkorder2Id = 0 then
		raise exception ':%','Ei saa lisada kiri';
	else	
		raise notice 'lnkorder2Id %', lnkorder2Id;
	end if;

	-- valuuta

	insert into dokvaluuta1 (dokid, dokliik, valuuta, kuurs, muud) 
		values (lnkorder2Id,11,tcValuuta, tnKuurs, 'insert valuuta');


else
	-- muuda 
	
	update korder2 set 
		parentid = tnparentid,
		nomid = tnnomid,
		nimetus = tcnimetus,
		summa = tnsumma,
		konto = tckonto,
		kood1 = tckood1,
		kood2 = tckood2,
		kood3 = tckood3,
		kood4 = tckood4,
		kood5 = tckood5,
		tp = tctp,
		proj = tcProj,
		tunnus = tctunnus
	where id = tnId;
	
	lnkorder2Id := tnId;



end if;


	-- kontrollin valuuta arv taabelis

	if (select count(id) from dokvaluuta1 where dokliik = 10 and dokid = tnParentId) = 0 then
	
		insert into dokvaluuta1 (dokid, dokliik, valuuta, kuurs, muud) 
			values (tnParentId,10,tcValuuta, tnKuurs, 'insert dok valuuta');

	end if;

         return  lnkorder2Id;
end;
$$;

ALTER FUNCTION sp_salvesta_korder2(INTEGER, INTEGER, INTEGER, CHAR, NUMERIC, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, NUMERIC, VARCHAR) OWNER TO vlad;

