CREATE FUNCTION get_menu(in_modules text[], in_groups text[]) RETURNS TABLE(id integer, pad character varying, bar character varying, idx integer, name character varying, eesti character varying, vene character varying, proc text, groups text, modules text, level text, message character varying, keyshortcut text)
    LANGUAGE SQL
AS
$$
SELECT id , pad , bar , idx , name, eesti, vene, proc , groups, modules, level, message, keyshortcut
FROM ou.cur_menu
WHERE modules :: JSONB ?| in_modules
      AND groups :: JSONB ?| in_groups
$$;

ALTER FUNCTION get_menu(TEXT[], TEXT[]) OWNER TO vlad;

