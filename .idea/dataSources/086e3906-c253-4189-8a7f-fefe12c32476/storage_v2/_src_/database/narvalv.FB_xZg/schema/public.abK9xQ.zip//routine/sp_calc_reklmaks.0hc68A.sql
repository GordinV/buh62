CREATE FUNCTION sp_calc_reklmaks(integer, integer, date, character varying) RETURNS character varying
    LANGUAGE plpgsql
AS
$$
DECLARE tnrekvid alias for $1;
	tnAsutusId alias for $2;
	tdKpv alias for $3;
	tcKonto alias for $4;
	lcReturn varchar;
	lcString varchar;
	lcPnimi varchar;
	lnCount int;
	qryAsutused record;
	qryArved record;
	qryTasud record;
	qryArv record;
	lnAlgsaldo numeric (14,4);
	lnVolg numeric (14,4);
	lcKonto varchar;
	lnpaevad int;
	ldKpv date;
	ldTahtaeg date;
	ldJargTahtaeg date;
	lnId int;
	lcdate varchar;
	lnAsu1 int;
	lnAsu2 int;
	lnTasudKokku numeric;
begin	

	

	select count(*) into lnCount from pg_class where relname = 'tmp_viivis';

	if lnCount = 1 then

		drop table tmp_viivis;

		CREATE TABLE tmp_viivis (  dkpv date DEFAULT date(), Timestamp varchar(20),  id int4, rekvid int4,  asutusid int4,  konto varchar(20),
		  algjaak numeric(14,4), algkpv date,  arvnumber varchar(20), tahtaeg date, summa numeric(14,4), 
		  tasud1 date,  tasun1 numeric(14,4) default 0,  paev1 int4 default 0,  volg1 numeric(14,4) default 0,  
		  tasud2 date,  tasun2 numeric(14,4) default 0,  paev2 int4 default 0,  volg2 numeric(14,4) default 0, 
		  tasud3 date,  tasun3 numeric(14,4) default 0,  paev3 int4 default 0,   volg3 numeric(14,4) default 0,   
		  tasud4 date,   tasun4 numeric(14,4) default 0,   paev4 int4 default 0,  volg4 numeric(14,4) default 0,
		  tasud5 date,   tasun5 numeric(14,4) default 0,  paev5 int4 default 0,  volg5 numeric(14,4) default 0,  
		  tasud6 date,  tasun6 numeric(14,4) default 0,  paev6 int4 default 0,  volg6 numeric(14,4) default 0,
		  tasud7 date,  tasun7 numeric(14,4) default 0,  paev7 int4 default 0,  volg7 numeric(14,4) default 0,
		  tasud8 date,  tasun8 numeric(14,4) default 0,  paev8 int4 default 0,  volg8 numeric(14,4) default 0,
		  tasud9 date,  tasun9 numeric(14,4) default 0,  paev9 int4 default 0,  volg9 numeric(14,4) default 0
		) WITH OIDS;

		GRANT ALL ON TABLE public.toograf TO vlad WITH GRANT OPTION;
		GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE public.toograf TO GROUP dbpeakasutaja;
		GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE public.toograf TO GROUP dbkasutaja;
		GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE public.toograf TO GROUP dbadmin;
		GRANT SELECT ON TABLE public.toograf TO GROUP dbvaatleja;


	end if;
	
	delete from tmp_viivis where dkpv < date() and rekvid = tnrekvId;

	lcreturn := to_char(now(), 'YYYYMMDDMISS');
	lcKonto := space(1);
	lnAlgsaldo := 0;
	lnVolg := 0;
	lnid := 0;
	

	if tnAsutusId > 0 then
		lnAsu1 := tnAsutusId;
		lnAsu2 := tnAsutusId;
	else
		lnAsu1 := 0;
		lnAsu2 := 999999999;
	end if;

	for qryAsutused in select asutusId from curJournal 
		where curJournal.rekvId = tnrekvid 
		and kpv <= tdKpv 
		and  curJournal.kreedit = tcKonto
		and asutusId >= lnAsu1
		and asutusId <= lnAsu2
		group by asutusId
		order by asutusId
	loop

		-- kokku arvestatud

		for qryArved in select asutusId, date_part('quarter',kpv) as quarter, year(kpv) as aasta, sum(summa) as summa
			from curJournal 
			where curJournal.rekvId = tnrekvid 
			and kpv <= tdKpv 
			and  curJournal.kreedit = tcKonto
			and asutusId = qryAsutused.asutusid
			group by asutusId, date_part('quarter',kpv), year(kpv)
			order by asutusId, date_part('quarter',kpv), year(kpv)
		loop
		
			if qryArved.quarter = 1 then
				ldtahtaeg := date(qryArved.aasta,04,05);
			end if;
			if qryArved.quarter = 2 then
				ldtahtaeg := date(qryArved.aasta,07,05);
			end if;
			if qryArved.quarter = 3 then
				ldtahtaeg := date(qryArved.aasta,10,05);
			end if;
			if qryArved.quarter = 4 then
				ldtahtaeg := date(qryArved.aasta+1,01,05);
			end if;

			raise notice 'ldtahtaeg %',ldtahtaeg;
			lnId:= lnId + 1;

			insert into tmp_viivis (Timestamp, id, rekvId , asutusId , konto , tahtaeg , summa)
				values (lcreturn,lnid, tnRekvId, qryArved.AsutusId, tcKonto,ldtahtaeg, qryArved.summa);


		end loop;	
		lnVolg := 0;
		for qryArv in select tahtaeg, summa, id from tmp_viivis where timestamp = lcreturn and asutusId = qryAsutused.asutusId
			loop

				lnVolg := qryArv.summa;
				-- tasud
				lnCount := 0;
				raise notice ' Alg lnVolg %',lnVolg;

				for qryTasud in select kpv, sum(summa) as summa from curJournal 
					where asutusId = qryAsutused.asutusId and deebet = tcKonto and kpv <= tdKpv 
					group by kpv
					order by kpv
				loop	

					lnCount := lnCount + 1;
					-- arvestame paevad
					raise notice ' qryTasud.summa %',qryTasud.summa;
					
					lnPaevad := qryTasud.kpv - (qryArv.tahtaeg + 1);
					select (tasun1+tasun2+tasun3+tasun4+tasun5+tasun6+tasun7+tasun8+tasun9) into lnTasudKokku from tmp_viivis where id = qryArv.Id and Timestamp = lcreturn ; 
					if lnCount = 1 then
						update tmp_viivis set tasud1 = qryTasud.kpv, tasun1 = qryTasud.summa, paev1 = lnPaevad, 
							volg1 = qryArv.summa - (qryTasud.summa +lnTasudKokku) 
							where id = qryArv.Id and Timestamp = lcreturn ;

					end if;
					if lnCount = 2 then
						update tmp_viivis set tasud2 = qryTasud.kpv, tasun2 = qryTasud.summa, paev2 = lnPaevad, 
							volg2 = qryArv.summa - (qryTasud.summa +lnTasudKokku)
							where id = qryArv.Id and Timestamp = lcreturn ;

					end if;
					if lnCount = 3 then
						update tmp_viivis set tasud3 = qryTasud.kpv, tasun3 = qryTasud.summa, paev3 = lnPaevad, 
							volg3 = qryArv.summa - (qryTasud.summa +lnTasudKokku)
							where id = qryArv.Id and Timestamp = lcreturn ;

					end if;
					if lnCount = 4 then
						update tmp_viivis set tasud1 = qryTasud.kpv, tasun4 = qryTasud.summa, paev4 = lnPaevad, 
							volg4 = qryArv.summa - (qryTasud.summa +lnTasudKokku)
							where id = qryArv.Id and Timestamp = lcreturn ;

					end if;
					if lnCount = 5 then
						update tmp_viivis set tasud5 = qryTasud.kpv, tasun5 = qryTasud.summa, paev5 = lnPaevad, 
							volg5 = (qryTasud.summa +lnTasudKokku)
							where id = qryArv.Id and Timestamp = lcreturn ;

					end if;
					if lnCount = 6 then
						update tmp_viivis set tasud6 = qryTasud.kpv, tasun6 = qryTasud.summa, paev6 = lnPaevad, 
							volg6 = (qryTasud.summa +lnTasudKokku)
							where id = qryArv.Id and Timestamp = lcreturn ;

					end if;
					if lnCount = 7 then
						update tmp_viivis set tasud7 = qryTasud.kpv, tasun7 = qryTasud.summa, paev7 = lnPaevad, 
							volg7 = (qryTasud.summa +lnTasudKokku) 
							where id = qryArv.Id and Timestamp = lcreturn ;

					end if;
					if lnCount = 8 then
						update tmp_viivis set tasud8 = qryTasud.kpv, tasun8 = qryTasud.summa, paev8 = lnPaevad, 
							volg8 = (qryTasud.summa +lnTasudKokku)
							where id = qryArv.Id and Timestamp = lcreturn ;

					end if;
					if lnCount = 9 then
						update tmp_viivis set tasud9 = qryTasud.kpv, tasun9 = qryTasud.summa, paev9 = lnPaevad, 
							volg9 = (qryTasud.summa +lnTasudKokku)
							where id = qryArv.Id and Timestamp = lcreturn ;

					end if;
/*
					lnVolg := lnVolg - qryTasud.summa;
					if lnVolg <= 0 then 
						raise notice ' lnVolg %',lnVolg;
						raise notice ' lncount %',lncount;
						lnCount := 0;					
						raise notice ' lnVolg %',lnVolg;
						update tmp_viivis set algjaak =  lnVolg where id = qryArv.Id+1 and Timestamp = lcreturn;			
						lnVolg := 0;
					end if;
*/
				end loop;


			end loop;




	end loop;

/*
			ldtahtaeg := ldjargTahtaeg; 
		end loop;
		-- arvestame kokku arvestatud
			

			lnCount := 0;

			for qryTasud in select kpv, summa from arvtasu 
				where arvtasu.arvId = qryArved.id  
				order by kpv
			loop
				lnCount := lnCount + 1;
				-- arvestame paevad


				lnPaevad := qryTasud.kpv - (qryArved.tahtaeg + 1);
				lnVolg := lnVolg - qryTasud.summa;

				if lnCount = 1 then
					update tmp_viivis set tasud1 = qryTasud.kpv,
						tasun1 = qryTasud.summa,
						paev1 = lnPaevad,
						volg1 = lnVolg
						where id = qryArved.id
						and Timestamp = lcreturn;
				end if;

				if lnCount = 2 then
					update tmp_viivis set tasud1 = qryTasud.kpv,
						tasun2 = qryTasud.summa,
						paev2 = lnPaevad,
						volg2 = lnVolg
						where id = qryArved.id
						and Timestamp = lcreturn;
				end if;


			end loop;
			if lnCount = 0 then
				lnPaevad := qryTasud.kpv - (qryArved.tahtaeg + 1);

					update tmp_viivis set 
						paev6 = tdKpv - (qryArved.tahtaeg + 1),
						volg6 = lnVolg
						where id = qryArved.id
						and Timestamp = lcreturn;
				
			end if;

	end loop;
*/

	return LCRETURN;
end;

$$;

ALTER FUNCTION sp_calc_reklmaks(INTEGER, INTEGER, DATE, VARCHAR) OWNER TO vlad;

