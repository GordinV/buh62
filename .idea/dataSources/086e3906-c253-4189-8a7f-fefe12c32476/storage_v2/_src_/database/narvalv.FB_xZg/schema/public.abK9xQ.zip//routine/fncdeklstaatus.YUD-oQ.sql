CREATE FUNCTION fncdeklstaatus(integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	tnDeklId alias for $1;

	v_dekl record;

	lnDeklStatus int;
	lnSumma numeric;
	lnStaatus int;
begin
	lnStaatus = 1;
	-- laekused

	select sum(summa) into lnSumma from dekltasu where deklid = tnDeklId;
	lnSumma = ifnull(lnSumma,0);

	-- deklsumma
	
	select toiming.id, toiming.summa, toiming.kpv, toiming.tahtaeg, toiming.staatus, ifnull(dokvaluuta1.valuuta,'EEK')::varchar as valuuta, ifnull(dokvaluuta1.kuurs,1)::numeric as kuurs into v_dekl 
		from toiming left outer join dokvaluuta1 on (dokvaluuta1.dokid = toiming.id and dokliik = 24)
		where toiming.Id = tnDeklId;


	-- status	
	lnStaatus = v_dekl.staatus;

	
	if lnSumma > 0 then
		if round(ifnull(lnSumma,0),1) >= round(v_dekl.summa * v_dekl.kuurs,1) then
			-- tasud
			lnStaatus = 3;	
		else
			-- tasud osaline
			lnStaatus = 2;	
		end if;
	else	
		lnStaatus = 1;
	end if;

	if lnStaatus <> v_dekl.staatus then
		perform sp_muuda_deklstaatus(v_dekl.Id, lnStaatus);
	end if;

return  lnStaatus;
end;
$$;

ALTER FUNCTION fncdeklstaatus(INTEGER) OWNER TO vlad;

