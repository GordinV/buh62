CREATE FUNCTION sp_salvesta_failid(integer, integer, integer, character varying, integer, text) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	tnid alias for $1;
	tnlubaid alias for $2;
	tnversiaid alias for $3;
	tcfail alias for $4;
	tnAllkiri alias for $5;
	ttmuud alias for $6;
	lnId int; 
	lnBlob int;
begin

if tnId = 0 then
	-- uus kiri

	if ttmuud <> 'local' then
		lnBlob = lo_import(tcfail);

		lnBlob = ifnull(lnBlob,0);
	else
		lnBlob = 0;
	end if;

	insert into failid (lubaid,versiaid,name,allkiri,muud, fail) 
		values (tnlubaid,tnversiaid,lnBlob,tnallkiri,ttmuud, tcfail);

	lnId:= cast(CURRVAL('public.failid_id_seq') as int4);

else
	-- muuda 
	update failid set 
		lubaid = tnrekvid,
		versiaid = tnversiaid,
		allkiri = tnAllkiri,
		fail = tcfail,
		muud = ttMuud
	where id = tnId;

	lnId := tnId;

end if;

         return  lnId;
end;
$$;

ALTER FUNCTION sp_salvesta_failid(INTEGER, INTEGER, INTEGER, VARCHAR, INTEGER, TEXT) OWNER TO vlad;

