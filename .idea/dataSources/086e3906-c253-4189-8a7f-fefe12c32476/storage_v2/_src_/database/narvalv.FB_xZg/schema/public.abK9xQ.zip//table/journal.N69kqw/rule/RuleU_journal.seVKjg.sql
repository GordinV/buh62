CREATE RULE "RuleU_journal" AS
    ON UPDATE TO public.journal
   WHERE (new.kpv < date(2004, 1, 1)) DO INSTEAD NOTHING;

