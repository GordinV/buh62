CREATE VIEW curarved(id, rekvid, number, kpv, tahtaeg, summa, tasud, tasudok, userid, asutus, asutusid, journalid, liik,
                     operid, jaak, objektid, doklausid, konto, muud, valuuta, kuurs, objekt, ametnik) AS
SELECT arv.id,
       arv.rekvid,
       arv.number,
       arv.kpv,
       arv.tahtaeg,
       arv.summa,
       arv.tasud,
       arv.tasudok,
       arv.userid,
       asutus.nimetus                                                            AS asutus,
       arv.asutusid,
       arv.journalid,
       arv.liik,
       arv.operid,
       arv.jaak,
       arv.objektid,
       arv.doklausid,
       ifnull((dokprop.konto)::BPCHAR, space(20))                                AS konto,
       arv.muud,
       (ifnull((dokvaluuta1.valuuta)::BPCHAR, 'EEK'::BPCHAR))::CHARACTER VARYING AS valuuta,
       ifnull(dokvaluuta1.kuurs, (1)::NUMERIC)                                   AS kuurs,
       (ifnull((arv.objekt)::BPCHAR, space(20)))::CHARACTER VARYING              AS objekt,
       userid.ametnik
FROM ((((arv
    JOIN asutus asutus ON ((asutus.id = arv.asutusid)))
    JOIN userid ON ((arv.userid = userid.id)))
    LEFT JOIN dokprop ON ((dokprop.id = arv.doklausid)))
         LEFT JOIN dokvaluuta1 ON (((arv.id = dokvaluuta1.dokid) AND (dokvaluuta1.dokliik = 3))));

ALTER TABLE curarved
    OWNER TO vlad;

