CREATE VIEW cur_objekt(id, rekvid, kood, nimetus, asutus, nait14, nait15) AS
SELECT l.id,
       l.rekvid,
       l.kood,
       l.nimetus,
       COALESCE(a.nimetus, ''::BPCHAR)                       AS asutus,
       (((l.properties)::JSONB ->> 'nait14'::TEXT))::NUMERIC AS nait14,
       (((l.properties)::JSONB ->> 'nait15'::TEXT))::NUMERIC AS nait15
FROM (libs.library l
         LEFT JOIN libs.asutus a ON (((((l.properties)::JSONB ->> 'asutusid'::TEXT))::INTEGER = a.id)))
WHERE ((l.library = 'OBJEKT'::BPCHAR) AND (l.status <> 3));

ALTER TABLE cur_objekt
    OWNER TO vlad;

