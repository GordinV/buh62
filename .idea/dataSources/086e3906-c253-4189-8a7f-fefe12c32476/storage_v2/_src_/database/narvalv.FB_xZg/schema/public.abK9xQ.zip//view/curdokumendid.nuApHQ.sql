CREATE VIEW curdokumendid(rekvid, asutusid, lausend, arved, palk, pv, kassa, mk, reklaam, vanemtasu, muud) AS
SELECT tmpdokumendid.rekvid,
       tmpdokumendid.asutusid,
       sum(tmpdokumendid.lausend)   AS lausend,
       sum(tmpdokumendid.arved)     AS arved,
       sum(tmpdokumendid.palk)      AS palk,
       sum(tmpdokumendid.pv)        AS pv,
       sum(tmpdokumendid.kassa)     AS kassa,
       sum(tmpdokumendid.mk)        AS mk,
       sum(tmpdokumendid.reklaam)   AS reklaam,
       sum(tmpdokumendid.vanemtasu) AS vanemtasu,
       sum(tmpdokumendid.muud)      AS muud
FROM (SELECT journal.asutusid,
             (count(journal.id))::INTEGER AS lausend,
             0                            AS arved,
             0                            AS palk,
             0                            AS pv,
             0                            AS kassa,
             0                            AS mk,
             0                            AS reklaam,
             0                            AS vanemtasu,
             0                            AS muud,
             journal.rekvid
      FROM journal
      GROUP BY journal.rekvid, journal.asutusid
      UNION ALL
      SELECT arv.asutusid,
             0                        AS lausend,
             (count(arv.id))::INTEGER AS arved,
             0                        AS palk,
             0                        AS pv,
             0                        AS kassa,
             0                        AS mk,
             0                        AS reklaam,
             0                        AS vanemtasu,
             0                        AS muud,
             arv.rekvid
      FROM arv
      GROUP BY arv.rekvid, arv.asutusid
      UNION ALL
      SELECT curpalkoper.isikid               AS asutusid,
             0                                AS lausend,
             0                                AS arved,
             (count(curpalkoper.id))::INTEGER AS palk,
             0                                AS pv,
             0                                AS kassa,
             0                                AS mk,
             0                                AS reklaam,
             0                                AS vanemtasu,
             0                                AS muud,
             curpalkoper.rekvid
      FROM curpalkoper
      GROUP BY curpalkoper.rekvid, curpalkoper.isikid
      UNION ALL
      SELECT pv_oper.asutusid,
             0                            AS lausend,
             0                            AS arved,
             0                            AS palk,
             (count(pv_oper.id))::INTEGER AS pv,
             0                            AS kassa,
             0                            AS mk,
             0                            AS reklaam,
             0                            AS vanemtasu,
             0                            AS muud,
             library.rekvid
      FROM (pv_oper
               JOIN library ON ((library.id = pv_oper.parentid)))
      GROUP BY library.rekvid, pv_oper.asutusid
      UNION ALL
      SELECT korder1.asutusid,
             0                            AS lausend,
             0                            AS arved,
             0                            AS palk,
             0                            AS pv,
             (count(korder1.id))::INTEGER AS kassa,
             0                            AS mk,
             0                            AS reklaam,
             0                            AS vanemtasu,
             0                            AS muud,
             korder1.rekvid
      FROM korder1
      GROUP BY korder1.rekvid, korder1.asutusid
      UNION ALL
      SELECT mk1.asutusid,
             0                        AS lausend,
             0                        AS arved,
             0                        AS palk,
             0                        AS pv,
             0                        AS kassa,
             (count(mk1.id))::INTEGER AS mk,
             0                        AS reklaam,
             0                        AS vanemtasu,
             0                        AS muud,
             mk.rekvid
      FROM (mk1
               JOIN mk ON ((mk.id = mk1.parentid)))
      GROUP BY mk.rekvid, mk1.asutusid
      UNION ALL
      SELECT toiming.parentid             AS asutusid,
             0                            AS lausend,
             0                            AS arved,
             0                            AS palk,
             0                            AS pv,
             0                            AS kassa,
             0                            AS mk,
             (count(toiming.id))::INTEGER AS reklaam,
             0                            AS vanemtasu,
             0                            AS muud,
             luba.rekvid
      FROM (toiming
               JOIN luba ON ((luba.id = toiming.lubaid)))
      GROUP BY luba.rekvid, toiming.parentid
      UNION ALL
      SELECT vanemtasu4.isikid               AS asutusid,
             0                               AS lausend,
             0                               AS arved,
             0                               AS palk,
             0                               AS pv,
             0                               AS kassa,
             0                               AS mk,
             0                               AS reklaam,
             (count(vanemtasu4.id))::INTEGER AS vanemtasu,
             0                               AS muud,
             vanemtasu3.rekvid
      FROM (vanemtasu4
               JOIN vanemtasu3 ON ((vanemtasu3.id = vanemtasu4.parentid)))
      GROUP BY vanemtasu3.rekvid, vanemtasu4.isikid) tmpdokumendid
GROUP BY tmpdokumendid.asutusid, tmpdokumendid.rekvid
ORDER BY tmpdokumendid.asutusid, tmpdokumendid.rekvid;

ALTER TABLE curdokumendid
    OWNER TO vlad;

