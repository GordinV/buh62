CREATE FUNCTION round_maksud(integer, date, integer) RETURNS boolean
    LANGUAGE plpgsql
AS
$$
declare 
	tnIsikId alias for $1;
	tdDate alias for $2;
	tnRekvId alias for $3;

	l_tulemus boolean = false;
	l_tulud numeric(14,2) = 0;
	l_pm numeric(14,2) = 0;
	l_tki numeric(14,2) = 0;
	l_tapsestus numeric(14,2) = 0;

begin
	-- kontrollime arvestused
	if (select count(id) 
		from palk_oper 
		where lepingid in (select id from tooleping where parentid = tnIsikId) 
		and kpv = tdDate 
		and libId in (select parentid from palk_lib where liik = 1)) > 1 then
		-- on arvestused. rohkem kui 1
		-- Tulud
		select sum(summa) into l_tulud 
			from palk_oper po 
			inner join palk_lib pl on pl.parentid = po.libid
			where lepingid in (select id from tooleping where parentid = tnIsikId and rekvid = tnRekvId)
			and kpv = tdDate
			and libId in (select l.id from palk_lib pl inner join library l on l.id = pl.parentid where rekvid = tnRekvId and liik = 1);

		
		-- arvestame PM
		select sum(summa) into l_pm 
			from palk_oper po
			inner join palk_lib pl on pl.parentid = po.libid
			where lepingid in (select id from tooleping where parentid = tnIsikId and rekvid = tnRekvId)
			and kpv = tdDate
			and libId in (select l.id from palk_lib pl inner join library l on l.id = pl.parentid where rekvid = tnRekvId and liik = 8);
			
		
		l_tapsestus = l_tulud * (select summa 
			from palk_kaart 
			where lepingId in (select id from tooleping where parentid = tnIsikId and rekvid = tnRekvId and pohikoht = 1) 
			and libId in (select l.id from palk_lib pl inner join library l on l.id = pl.parentid where rekvid = tnRekvId and liik = 8) -- PM
			and status = 1 
			order by id desc limit 1
			) * 0.01 - l_pm;

		raise notice 'l_tulud %, l_pm  %, l_tapsestus %', l_tulud, l_pm, l_tapsestus;

		if l_tapsestus <> 0 then 

			l_tulemus = true;
			l_tapsestus = 0;
		end if;	


		-- arvestame TKI
		select sum(summa) into l_tki 
			from palk_oper po
			inner join palk_lib pl on pl.parentid = po.libid
			where lepingid in (select id from tooleping where parentid = tnIsikId and rekvid = tnRekvId)
			and kpv = tdDate
			and libId in (select l.id from palk_lib pl inner join library l on l.id = pl.parentid where rekvid = tnRekvId and liik = 7 and asutusest = 0);
			
		if (l_tki > 0) then
			l_tapsestus = l_tulud * (select summa 
				from palk_kaart 
				where lepingId in (select id from tooleping where parentid = tnIsikId and rekvid = tnRekvId and pohikoht = 1) 
				and libId in (select l.id from palk_lib pl inner join library l on l.id = pl.parentid where rekvid = tnRekvId and liik = 7 and asutusest = 0) -- PM
				and status = 1 
				order by id desc limit 1
				) * 0.01 - l_tki;
		end if;
		raise notice 'l_tulud %, l_tki  %, l_tapsestus %', l_tulud, l_tki, l_tapsestus;

		if l_tapsestus <> 0 then 
			l_tulemus = true;
			l_tapsestus = 0;
		end if;	

			
	end if;

         return  l_tulemus;
end;
$$;

ALTER FUNCTION round_maksud(INTEGER, DATE, INTEGER) OWNER TO vlad;

