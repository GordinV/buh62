CREATE VIEW com_laod(id, kood, nimetus, rekvid) AS
SELECT qry.id,
       qry.kood,
       qry.nimetus,
       qry.rekvid
FROM (SELECT 0                         AS id,
             ''::CHARACTER VARYING(20) AS kood,
             ''::CHARACTER VARYING(20) AS nimetus,
             NULL::INTEGER             AS rekvid
      UNION
      SELECT l.id,
             l.kood,
             l.nimetus,
             l.rekvid
      FROM libs.library l
      WHERE ((l.library = 'LADU'::BPCHAR) AND (l.status <> 3))) qry
ORDER BY qry.kood;

ALTER TABLE com_laod
    OWNER TO vlad;

