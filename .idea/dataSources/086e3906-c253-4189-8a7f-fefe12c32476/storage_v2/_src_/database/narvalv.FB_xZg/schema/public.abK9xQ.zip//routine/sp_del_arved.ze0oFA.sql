CREATE FUNCTION sp_del_arved(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 


	tnId alias for $1;
	lnCount int;

	v_arv record;

begin

	select * into v_arv from arv where id = tnId;

	DELETE FROM arv WHERE id = tnid;

	-- arveldused
	select count(*) into lnCount from pg_stat_all_tables where UPPER(relname) = 'COUNTER';
	if ifnull(lnCount,0) > 0 then
		update counter set muud = null where ifnull(muud,'null') <> 'null' and muud = ltrim(rtrim(str(tnid)));
	end if; 

	perform sp_recalc_ladujaak (v_arv.rekvid,0,v_arv.id);
	
	Return 1;


end;


$$;

ALTER FUNCTION sp_del_arved(INTEGER, INTEGER) OWNER TO vlad;

