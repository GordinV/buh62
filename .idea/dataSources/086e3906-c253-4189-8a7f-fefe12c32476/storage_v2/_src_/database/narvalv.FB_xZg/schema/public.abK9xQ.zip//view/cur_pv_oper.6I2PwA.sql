CREATE VIEW cur_pv_oper(id, rekvid, summa, liik, kpv, pv_kaart_id, konto, kood1, kood2, kood3, kood5, tunnus, proj, tp,
                        journalid, kood, nimetus, number, valuuta, kuurs) AS
SELECT dd.id,
       dd.rekvid,
       po.summa,
       po.liik,
       po.kpv,
       po.pv_kaart_id,
       po.konto,
       po.kood1,
       po.kood2,
       po.kood3,
       po.kood5,
       po.tunnus,
       po.proj,
       po.tp,
       po.journalid,
       n.kood,
       n.nimetus,
       COALESCE(jid.number, 0)  AS number,
       'EUR'::CHARACTER VARYING AS valuuta,
       (1)::NUMERIC             AS kuurs
FROM (((((docs.pv_oper po
    JOIN docs.doc dd ON ((dd.id = po.parentid)))
    JOIN libs.nomenklatuur n ON ((n.id = po.nomid)))
    LEFT JOIN docs.doc d ON ((d.id = po.journalid)))
    LEFT JOIN docs.journal j ON ((j.parentid = d.id)))
         LEFT JOIN docs.journalid jid ON ((j.id = jid.journalid)));

ALTER TABLE cur_pv_oper
    OWNER TO vlad;

