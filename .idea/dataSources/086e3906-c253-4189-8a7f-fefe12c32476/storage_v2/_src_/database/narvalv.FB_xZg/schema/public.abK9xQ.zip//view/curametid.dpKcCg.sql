CREATE VIEW curametid(id, amet, osakond, rekvid, kogus, vaba, palgamaar) AS
SELECT ametid.id,
       ametid.nimetus  AS amet,
       osakond.nimetus AS osakond,
       palk_asutus.rekvid,
       palk_asutus.kogus,
       palk_asutus.vaba,
       palk_asutus.palgamaar
FROM ((library ametid
    JOIN palk_asutus ON ((ametid.id = palk_asutus.ametid)))
         JOIN library osakond ON ((palk_asutus.osakondid = osakond.id)));

ALTER TABLE curametid
    OWNER TO vlad;

