CREATE FUNCTION sp_kontrol() RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	lnReturn int; 
	lnError int;
	lnCount1 int;
	lnCount2 int;
	lnLubaId int;
	lnToimingId int;
	lnfailId int;
begin
lnError = 1;
raise notice 'insert luba';
	select count(*) into lnCount1 from luba;	
raise notice 'insert luba: count%',lnCount1;

lnReturn = sp_salvesta_luba(0, 170, 1, 0, date(2006,01,01), date(2006,12,31), '001',10,0, 250, 125, date(2006,12,31),  'alus', 0, 1, 'muud');

raise notice 'insert luba, result%',lnReturn;
if lnReturn <= 0 then
	lnError = 0;
	raise notice 'insert luba, viga';
end if;
if lnReturn > 0 then
	select count(*) into lnCount2 from luba;	
	lnCount2 = lnCount2 - lnCount1;
	raise notice 'kokku inserted: %',lnCount2;
	
	lnLubaId := lnReturn;

	raise notice 'insert toiming';
	select count(*) into lnCount1 from toiming;	
	lnreturn := sp_salvesta_toiming(0, 170, lnReturn, date(), 'alus','ettekirjutus', date() + 31, 250, 1, 'tyyp', 'muud',0, 0);
	raise notice 'insert toiming, result%',lnReturn;
	lnToimingId = lnReturn;
end if;
if lnReturn > 0 then
	select count(*) into lnCount2 from toiming;	
	lnCount2 = lnCount2 - lnCount1;
	raise notice 'kokku inserted: %',lnCount2;
	
	lnLubaId := lnReturn;

	raise notice 'insert failid';
	select count(*) into lnCount1 from failid;	

	lnreturn := sp_salvesta_failid(0, LnLubaId, 1,1,'',1, 'muud');
	lnfailId = lnReturn;
	raise notice 'insert failid, result%',lnReturn;
	select count(*) into lnCount2 from failid;	
	lnCount2 = lnCount2 - lnCount1;
	raise notice 'kokku inserted: %',lnCount2;
end if;
if lnReturn > 0 then
	raise notice 'delete proc. kontrol..';
end if;
if lnreturn > 0 then

	select count(*) into lnCount1 from toiming where id = lnToimingid;	
	raise notice 'delete toiming: count%',lnCount1;
	lnReturn = sp_del_toiming(lnToimingId);

	select count(*) into lnCount1 from toiming where id = lnToimingId;	
	raise notice 'kokku deleted: %',lnCount1;
	if lnCount1 = 0 then
		raise notice 'Toiming deleted';		
	end if;

end if;
if lnreturn > 0 then

	select count(*) into lnCount1 from failid where id = lnToimingid;	
	raise notice 'delete toiming: count%',lnCount1;
	lnReturn = sp_del_toiming(lnToimingId);

	select count(*) into lnCount1 from toiming where id = lnToimingId;	
	raise notice 'kokku deleted: %',lnCount1;
	if lnCount1 = 0 then
		raise notice 'Toiming deleted';		
	end if;

end if;


if lnreturn > 0 then

	select count(*) into lnCount1 from luba where id = lnLubaid;	
	raise notice 'delete luba: count%',lnCount1;
	lnReturn = sp_del_luba(lnLubaId);

	select count(*) into lnCount1 from luba where id = lnLubaid;	
	raise notice 'kokku deleted: %',lnCount1;
	if lnCount1 = 0 then
		raise notice 'Luba deleted';		
	end if;

end if;



if lnReturn <= 0 then
	lnError = 0;
	raise notice 'insert toiming, viga';
end if;




return  lnError;
end;
$$;

ALTER FUNCTION sp_kontrol() OWNER TO vlad;

