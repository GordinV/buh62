CREATE VIEW curpalkjaak(rekvid, parentid, regkood, nimetus, aadress, tel, kuu, aasta, id, jaak, arvestatud, kinni, tka,
                        tki, pm, tulumaks, sotsmaks, muud, osakond, g31, osakondid) AS
SELECT rekv.id      AS rekvid,
       rekv.parentid,
       asutus.regkood,
       asutus.nimetus,
       asutus.aadress,
       asutus.tel,
       palk_jaak.kuu,
       palk_jaak.aasta,
       palk_jaak.id,
       palk_jaak.jaak,
       palk_jaak.arvestatud,
       palk_jaak.kinni,
       palk_jaak.tka,
       palk_jaak.tki,
       palk_jaak.pm,
       palk_jaak.tulumaks,
       palk_jaak.sotsmaks,
       palk_jaak.muud,
       library.kood AS osakond,
       palk_jaak.g31,
       tooleping.osakondid
FROM ((((palk_jaak
    JOIN tooleping ON ((palk_jaak.lepingid = tooleping.id)))
    JOIN rekv ON ((rekv.id = tooleping.rekvid)))
    JOIN asutus ON ((tooleping.parentid = asutus.id)))
         JOIN library ON ((tooleping.osakondid = library.id)));

ALTER TABLE curpalkjaak
    OWNER TO vlad;

