CREATE FUNCTION sp_del_pv_oper(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 
	tnId alias for $1;
	tnOpt alias for $2;
	lnParentId integer;
begin
	select parentid into lnParentid from pv_oper where id = tnId;
	DELETE FROM pv_oper WHERE id = tnid;
	if found then
		perform sp_update_pv_jaak(lnParentId);
		Return 1;
	else
		Return 0;
	end if;
end;
$$;

ALTER FUNCTION sp_del_pv_oper(INTEGER, INTEGER) OWNER TO vlad;

