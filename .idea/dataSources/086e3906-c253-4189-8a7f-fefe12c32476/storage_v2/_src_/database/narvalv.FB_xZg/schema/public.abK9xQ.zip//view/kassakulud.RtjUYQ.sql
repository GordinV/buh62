CREATE VIEW kassakulud(kood) AS
SELECT DISTINCT "left"(((ltrim(rtrim((library.kood)::TEXT)))::BPCHAR + '%'::BPCHAR), 20) AS kood
FROM library
WHERE (library.library = 'KASSAKULUD'::BPCHAR)
ORDER BY ("left"(((ltrim(rtrim((library.kood)::TEXT)))::BPCHAR + '%'::BPCHAR), 20));

ALTER TABLE kassakulud
    OWNER TO vlad;

