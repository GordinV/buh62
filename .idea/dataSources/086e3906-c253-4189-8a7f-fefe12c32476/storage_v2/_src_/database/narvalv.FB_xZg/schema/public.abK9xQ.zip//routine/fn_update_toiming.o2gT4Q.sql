CREATE FUNCTION fn_update_toiming() RETURNS character varying
    LANGUAGE plpgsql
AS
$$
declare
       lcString varchar;
	v_toim record;
	v_luba record;
	lnNum int4;
begin
	for v_luba in 
		select Lubaid from toiming group by lubaid order by lubaid 
	loop
		lnNum = 0;
		for v_toim in
		select id from toiming where lubaid = v_luba.lubaid and tyyp = 'DEKL' order by kpv 
		loop
			lnNum = lnNum +1;
			update toiming set number = lnNum where id = v_toim.id;
		end loop;

	end loop;

     return  lcString;
end;
$$;

ALTER FUNCTION fn_update_toiming() OWNER TO vlad;

