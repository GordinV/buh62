CREATE FUNCTION date() RETURNS date
    LANGUAGE plpgsql
AS
$$
begin
         return  current_date;
end;
$$;

ALTER FUNCTION date() OWNER TO vlad;

