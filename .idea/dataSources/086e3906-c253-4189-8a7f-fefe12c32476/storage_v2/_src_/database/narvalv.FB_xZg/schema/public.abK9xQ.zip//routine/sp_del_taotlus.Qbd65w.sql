CREATE FUNCTION sp_del_taotlus(integer, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare

	tnId alias for $1;
	v_taotlus record;
begin

	select * into v_taotlus from taotlus where id = tnId;
--	if v_taotlus.staatus > 1 then
--		raise exception 'Ei saa kustuta taotlus';
--	end if;
	delete from eelarve where id in (select eelarveid from taotlus1 where parentid = tnId and eelarveid > 0);
	DELETE FROM taotlus1 WHERE parentId = tnId;
	DELETE FROM taotlus WHERE Id = tnId;

	if found then

		return 1;

	else

		return 0;

	end if;

end;
$$;

ALTER FUNCTION sp_del_taotlus(INTEGER, INTEGER) OWNER TO vlad;

