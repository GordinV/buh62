CREATE FUNCTION sp_salvesta_aasta(integer, integer, integer, integer, integer, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	tnid alias for $1;
	tnrekvid alias for $2;
	tnaasta alias for $3;
	tnkuu alias for $4;
	tnkinni alias for $5;
	tndefault_ alias for $6;
	lnaastaId int;
	lnId int; 
	lrCurRec record;
begin

if tnId = 0 then
	-- uus kiri
	insert into aasta (rekvid,aasta,kuu,kinni,default_) 
		values (tnrekvid,tnaasta,tnkuu,tnkinni,tndefault_);

	GET DIAGNOSTICS lnId = ROW_COUNT;

	if lnId > 0 then
		raise notice 'lnId %',lnId;
		lnaastaId:= cast(CURRVAL('public.aasta_id_seq') as int4);
		raise notice 'lnaastaId %',lnaastaId;
	else
		lnAastaId = 0;
	end if;
else
	-- muuda 
	select * into lrCurRec from aasta where id = tnId;
	if lrCurRec.rekvid <> tnrekvid or lrCurRec.aasta <> tnaasta or lrCurRec.kuu <> tnkuu or lrCurRec.kinni <> tnkinni or lrCurRec.default_ <> tndefault_ then 
	update aasta set 
		rekvid = tnrekvid,
		aasta = tnaasta,
		kuu = tnkuu,
		kinni = tnkinni,
		default_ = tndefault_
	where id = tnId;
	end if;
	lnaastaId := tnId;
end if;

         return  lnaastaId;
end;
$$;

ALTER FUNCTION sp_salvesta_aasta(INTEGER, INTEGER, INTEGER, INTEGER, INTEGER, INTEGER) OWNER TO vlad;

