CREATE FUNCTION sp_salvesta_failid(integer, integer, integer, integer, character varying, integer, text) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	tnid alias for $1;
	tnlubaid alias for $2;
	tnversiaid alias for $3;
	tnname alias for $4;
	tcfail alias for $5;
	tnAllkiri alias for $6;
	ttmuud alias for $7;
	lnId int; 
begin

if tnId = 0 then
	-- uus kiri
	insert into failid (lubaid,versiaid,name,fail,allkiri,muud) 
		values (tnlubaid,tnversiaid,tnname,tcfail,tnallkiri,ttmuud);

	lnId:= cast(CURRVAL('public.failid_id_seq') as int4);

else
	-- muuda 
	update failid set 
		lubaid = tnrekvid,
		versiaid = tnversiaid,
		name = tnName,
		fail = tcfail,
		allkiri = tnAllkiri,
		muud = ttMuud
	where id = tnId;

	lnId := tnId;

end if;

         return  lnId;
end;
$$;

ALTER FUNCTION sp_salvesta_failid(INTEGER, INTEGER, INTEGER, INTEGER, VARCHAR, INTEGER, TEXT) OWNER TO vlad;

