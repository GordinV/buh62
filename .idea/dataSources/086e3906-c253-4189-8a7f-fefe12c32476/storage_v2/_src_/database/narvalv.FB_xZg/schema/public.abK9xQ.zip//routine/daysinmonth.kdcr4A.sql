CREATE FUNCTION daysinmonth(date) RETURNS integer
    LANGUAGE plpgsql
AS
$$
DECLARE tdKpv alias for $1;
	ldKpv1 date;
	ldKpv2 date;
begin
	ldKpv1 = date(YEAR(tdKpv),month(tdKpv),1);
	ldKpv2 = gomonth(ldKpv1,1);


         return  ldKpv2 - ldKpv1;

end;

$$;

ALTER FUNCTION daysinmonth(DATE) OWNER TO vlad;

