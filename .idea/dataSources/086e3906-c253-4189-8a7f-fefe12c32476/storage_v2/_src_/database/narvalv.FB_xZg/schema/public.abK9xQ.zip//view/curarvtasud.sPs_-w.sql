CREATE VIEW curarvtasud(arvid, rekvid, number, arvkpv, arvsumma, tahtaeg, liik, asutus, kpv, summa, dok, id, journalid,
                        pankkassa, sorderid, objekt, tasuliik, valuuta, kuurs) AS
SELECT arv.id                                                                        AS arvid,
       arv.rekvid,
       arv.number,
       arv.kpv                                                                       AS arvkpv,
       arv.summa                                                                     AS arvsumma,
       arv.tahtaeg,
       arv.liik,
       asutus.nimetus                                                                AS asutus,
       arvtasu.kpv,
       arvtasu.summa,
       arvtasu.dok,
       arvtasu.id,
       arvtasu.journalid,
       arvtasu.pankkassa,
       arvtasu.sorderid,
       (ifnull((arv.objekt)::BPCHAR, space(20)))::CHARACTER VARYING                  AS objekt,
       CASE
           WHEN (arvtasu.pankkassa = 1) THEN 'MK'::CHARACTER VARYING
           WHEN (arvtasu.pankkassa = 2) THEN 'KASSA'::CHARACTER VARYING
           WHEN (arvtasu.pankkassa = 3) THEN 'RAAMAT'::CHARACTER VARYING
           ELSE 'MUUD'::CHARACTER VARYING
           END                                                                       AS tasuliik,
       (ifnull((dokvaluuta1.valuuta)::BPCHAR, 'EEK'::BPCHAR))::CHARACTER VARYING(20) AS valuuta,
       ifnull(dokvaluuta1.kuurs, (1)::NUMERIC)                                       AS kuurs
FROM (((arvtasu arvtasu
    JOIN arv ON ((arvtasu.arvid = arv.id)))
    JOIN asutus ON ((asutus.id = arv.asutusid)))
         LEFT JOIN dokvaluuta1 ON (((arvtasu.id = dokvaluuta1.dokid) AND (dokvaluuta1.dokliik = 10))));

ALTER TABLE curarvtasud
    OWNER TO vlad;

