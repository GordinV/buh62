CREATE VIEW faktkulud(kood) AS
SELECT DISTINCT ((ltrim(rtrim((library.kood)::TEXT)))::BPCHAR + '%'::BPCHAR) AS kood
FROM library
WHERE (library.library = 'KULUKONTOD'::BPCHAR)
ORDER BY ((ltrim(rtrim((library.kood)::TEXT)))::BPCHAR + '%'::BPCHAR);

ALTER TABLE faktkulud
    OWNER TO vlad;

