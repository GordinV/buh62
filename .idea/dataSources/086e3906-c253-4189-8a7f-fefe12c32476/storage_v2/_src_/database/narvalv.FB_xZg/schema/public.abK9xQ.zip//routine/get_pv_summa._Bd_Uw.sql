CREATE FUNCTION get_pv_summa(integer) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
DECLARE tnPvKaartId alias for $1;
	lnParandatudSumma numeric (12,4);
	lnUmberhindatudSumma numeric (12,4);
	lnUmberhindatudKpv date;

	v_pvkaart record;
begin	

	select summa, kpv into lnUmberhindatudSumma, lnUmberhindatudKpv from pv_oper
		where parentId = tnPvKaartId and liik = 5 order by kpv desc limit 1;

	if not found then
		select pv_kaart.soetmaks, soetkpv into lnUmberhindatudSumma, lnUmberhindatudKpv  
			from pv_kaart where parentId = tnPvKaartId;
	end if;


	select sum(summa) into lnParandatudSumma from pv_oper
			where parentId = tnPvKaartId and liik = 3 and kpv >= lnUmberhindatudKpv;

	lnParandatudSumma := ifnull(lnParandatudSumma,0) + ifnull(lnUmberhindatudSumma,0);



	return lnParandatudSumma;
end;
$$;

ALTER FUNCTION get_pv_summa(INTEGER) OWNER TO vlad;

