CREATE FUNCTION dow(date) RETURNS integer
    LANGUAGE plpgsql
AS
$$
begin
         return  date_part ('DOW', $1);
end;
$$;

ALTER FUNCTION dow(DATE) OWNER TO vlad;

