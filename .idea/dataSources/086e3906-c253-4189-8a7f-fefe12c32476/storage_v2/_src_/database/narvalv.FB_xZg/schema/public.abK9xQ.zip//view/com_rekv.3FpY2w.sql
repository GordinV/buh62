CREATE VIEW com_rekv(id, regkood, parentid, nimetus) AS
SELECT r.id,
       r.regkood,
       r.parentid,
       r.nimetus
FROM ou.rekv r
WHERE ((r.parentid < 999) OR (r.status <> 3))
ORDER BY r.regkood;

ALTER TABLE com_rekv
    OWNER TO vlad;

