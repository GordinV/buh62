CREATE VIEW comtooleping(id, isik, isikukood, osakond, osakondid, amet, ametid, algab, lopp, toopaev, palk, palgamaar,
                         pohikoht, koormus, ametnik, pank, aa, rekvid, parentid) AS
SELECT tooleping.id,
       asutus.nimetus AS isik,
       asutus.regkood AS isikukood,
       osakonnad.kood AS osakond,
       osakonnad.id   AS osakondid,
       ametid.kood    AS amet,
       ametid.id      AS ametid,
       tooleping.algab,
       tooleping.lopp,
       tooleping.toopaev,
       tooleping.palk,
       tooleping.palgamaar,
       tooleping.pohikoht,
       tooleping.koormus,
       tooleping.ametnik,
       tooleping.pank,
       tooleping.aa,
       tooleping.rekvid,
       tooleping.parentid
FROM (((asutus
    JOIN tooleping ON ((asutus.id = tooleping.parentid)))
    JOIN library osakonnad ON ((tooleping.osakondid = osakonnad.id)))
         JOIN library ametid ON ((tooleping.ametid = ametid.id)));

ALTER TABLE comtooleping
    OWNER TO vlad;

