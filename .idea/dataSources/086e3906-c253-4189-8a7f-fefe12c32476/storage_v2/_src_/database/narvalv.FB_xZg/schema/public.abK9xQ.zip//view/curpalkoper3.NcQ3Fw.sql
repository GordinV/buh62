CREATE VIEW curpalkoper3(summa, kpv, rekvid, isik, isikid, isikukood, liik, asutusest, okood, akood, kuurs, valuuta) AS
SELECT palk_oper.summa,
       palk_oper.kpv,
       palk_oper.rekvid,
       asutus.nimetus                                                            AS isik,
       asutus.id                                                                 AS isikid,
       asutus.regkood                                                            AS isikukood,
       palk_lib.liik,
       palk_lib.asutusest,
       osakond.kood                                                              AS okood,
       amet.kood                                                                 AS akood,
       ifnull(dokvaluuta1.kuurs, (1)::NUMERIC)                                   AS kuurs,
       (ifnull((dokvaluuta1.valuuta)::BPCHAR, 'EEK'::BPCHAR))::CHARACTER VARYING AS valuuta
FROM (((((((palk_oper
    JOIN palk_lib ON ((palk_oper.libid = palk_lib.parentid)))
    JOIN library lib ON ((lib.id = palk_lib.parentid)))
    JOIN tooleping ON ((palk_oper.lepingid = tooleping.id)))
    JOIN asutus ON ((tooleping.parentid = asutus.id)))
    JOIN library osakond ON ((osakond.id = tooleping.osakondid)))
    JOIN library amet ON ((amet.id = tooleping.ametid)))
         LEFT JOIN dokvaluuta1 ON (((palk_oper.id = dokvaluuta1.dokid) AND (dokvaluuta1.dokliik = 12))));

ALTER TABLE curpalkoper3
    OWNER TO vlad;

