CREATE VIEW curtsd1(id, rekvid, isikukood, isik, pohikoht, osakondid, liik, asutusest, algoritm, kpv, summa, form,
                    palk26, palk_02, palk_03, palk_04, palk_05, palk_06, palk_07, palk_08, palk_09, palk_10, palk_11,
                    palk_12, palk_13, palk_14, palk_15, palk_16, palk_17, palk_18, palk_19, palk_20, palk_21, palk_22,
                    palk15, palk10, palk5, palk0, tm, atm, pm, tulumaks, sotsmaks, elatis, palksots) AS
SELECT palk_oper.id,
       palk_oper.rekvid,
       asutus.regkood                                                        AS isikukood,
       asutus.nimetus                                                        AS isik,
       comtooleping.pohikoht,
       comtooleping.osakondid,
       palk_lib.liik,
       palk_lib.asutusest,
       palk_lib.algoritm,
       palk_oper.kpv,
       (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))           AS summa,
       (((rtrim(ltrim((str((palk_lib.liik)::INTEGER))::TEXT)))::BPCHAR + '-'::BPCHAR) +
        (ltrim(rtrim((str((palk_kaart.tulumaar)::INTEGER))::TEXT)))::BPCHAR) AS form,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '01'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk26,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '02'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_02,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '03'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_03,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '04'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_04,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '05'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_05,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '06'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_06,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '07'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_07,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '08'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_08,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '09'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_09,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '10'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_10,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '11'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_11,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '12'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_12,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '13'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_13,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '14'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_14,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '15'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_15,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '16'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_16,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '17'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_17,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '18'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_18,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '19'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_19,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '20'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_20,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '21'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_21,
       CASE
           WHEN ((palk_lib.liik = 1) AND (ltrim(rtrim((palk_lib.tululiik)::TEXT)) = '22'::TEXT))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk_22,
       CASE
           WHEN ((((rtrim(ltrim((str((palk_lib.liik)::INTEGER))::TEXT)))::BPCHAR + '-'::BPCHAR) +
                  (ltrim(rtrim((str((palk_kaart.tulumaar)::INTEGER))::TEXT)))::BPCHAR) = '1-15'::BPCHAR)
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk15,
       CASE
           WHEN ((((rtrim(ltrim((str((palk_lib.liik)::INTEGER))::TEXT)))::BPCHAR + '-'::BPCHAR) +
                  (ltrim(rtrim((str((palk_kaart.tulumaar)::INTEGER))::TEXT)))::BPCHAR) = '1-10'::BPCHAR)
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk10,
       CASE
           WHEN ((((rtrim(ltrim((str((palk_lib.liik)::INTEGER))::TEXT)))::BPCHAR + '-'::BPCHAR) +
                  (ltrim(rtrim((str((palk_kaart.tulumaar)::INTEGER))::TEXT)))::BPCHAR) = '1-5'::BPCHAR)
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk5,
       CASE
           WHEN ((((rtrim(ltrim((str((palk_lib.liik)::INTEGER))::TEXT)))::BPCHAR + '-'::BPCHAR) +
                  (ltrim(rtrim((str((palk_kaart.tulumaar)::INTEGER))::TEXT)))::BPCHAR) = '1-0'::BPCHAR)
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palk0,
       CASE
           WHEN ((((rtrim(ltrim((str((palk_lib.liik)::INTEGER))::TEXT)))::BPCHAR + '-'::BPCHAR) +
                  (ltrim(rtrim((str((palk_lib.asutusest)::INTEGER))::TEXT)))::BPCHAR) = '7-0'::BPCHAR)
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS tm,
       CASE
           WHEN ((((rtrim(ltrim((str((palk_lib.liik)::INTEGER))::TEXT)))::BPCHAR + '-'::BPCHAR) +
                  (ltrim(rtrim((str((palk_lib.asutusest)::INTEGER))::TEXT)))::BPCHAR) = '7-1'::BPCHAR)
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS atm,
       CASE
           WHEN (palk_lib.liik = 8) THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS pm,
       CASE
           WHEN (palk_lib.liik = 4) THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS tulumaks,
       CASE
           WHEN (palk_lib.liik = 5) THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS sotsmaks,
       CASE
           WHEN ((palk_lib.elatis = 1) AND (palk_lib.liik = 2))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS elatis,
       CASE
           WHEN ((palk_lib.liik = 1) AND (palk_lib.sots = 1))
               THEN (palk_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))
           ELSE (0)::NUMERIC
           END                                                               AS palksots
FROM (((((palk_oper
    JOIN comtooleping ON ((comtooleping.id = palk_oper.lepingid)))
    JOIN asutus ON ((asutus.id = comtooleping.parentid)))
    JOIN palk_lib ON ((palk_oper.libid = palk_lib.parentid)))
    JOIN palk_kaart ON (((palk_kaart.lepingid = comtooleping.id) AND (palk_kaart.libid = palk_lib.parentid))))
         LEFT JOIN dokvaluuta1 ON (((palk_oper.id = dokvaluuta1.dokid) AND (dokvaluuta1.dokliik = 12))));

ALTER TABLE curtsd1
    OWNER TO vlad;

