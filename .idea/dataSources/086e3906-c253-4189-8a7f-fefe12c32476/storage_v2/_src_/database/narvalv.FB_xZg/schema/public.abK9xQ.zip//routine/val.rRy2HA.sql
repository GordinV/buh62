CREATE FUNCTION val(character varying) RETURNS integer
    LANGUAGE plpgsql
AS
$$
begin
         return  ltrim($1)::int;
end;
$$;

ALTER FUNCTION val(VARCHAR) OWNER TO vlad;

