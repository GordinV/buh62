CREATE FUNCTION trigd_leping1_before() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	lnCount int4;

	v_userid record;

begin

	delete from leping2 where parentid = old.id;

	return OLD;

end;
$$;

ALTER FUNCTION trigd_leping1_before() OWNER TO vlad;

