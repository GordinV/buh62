CREATE VIEW curpohivara(id, kood, nimetus, rekvid, vastisikid, vastisik, algkulum, kulum, soetmaks, parhind, soetkpv,
                        grupp, konto, gruppid, tunnus, mahakantud, rentnik, liik, valuuta, kuurs, selgitus, otsus) AS
SELECT library.id,
       library.kood,
       library.nimetus,
       library.rekvid,
       pv_kaart.vastisikid,
       ifnull(asutus.nimetus, space(254))                                        AS vastisik,
       pv_kaart.algkulum,
       pv_kaart.kulum,
       pv_kaart.soetmaks,
       pv_kaart.parhind,
       pv_kaart.soetkpv,
       grupp.nimetus                                                             AS grupp,
       pv_kaart.konto,
       pv_kaart.gruppid,
       pv_kaart.tunnus,
       pv_kaart.mahakantud,
       (pv_kaart.muud)::CHARACTER VARYING(254)                                   AS rentnik,
       CASE
           WHEN (pv_kaart.kulum > (0)::NUMERIC) THEN 'Pohivara'::TEXT
           ELSE 'Vaikevahendid'::TEXT
           END                                                                   AS liik,
       (ifnull((dokvaluuta1.valuuta)::BPCHAR, 'EEK'::BPCHAR))::CHARACTER VARYING AS valuuta,
       ifnull(dokvaluuta1.kuurs, (1)::NUMERIC)                                   AS kuurs,
       library.muud                                                              AS selgitus,
       pv_kaart.otsus
FROM ((((library
    JOIN pv_kaart ON ((library.id = pv_kaart.parentid)))
    LEFT JOIN dokvaluuta1 ON (((dokvaluuta1.dokid = pv_kaart.id) AND (dokvaluuta1.dokliik = 18))))
    JOIN library grupp ON (((pv_kaart.gruppid = grupp.id) AND (library.rekvid = grupp.rekvid))))
         LEFT JOIN asutus ON ((pv_kaart.vastisikid = asutus.id)));

ALTER TABLE curpohivara
    OWNER TO vlad;

