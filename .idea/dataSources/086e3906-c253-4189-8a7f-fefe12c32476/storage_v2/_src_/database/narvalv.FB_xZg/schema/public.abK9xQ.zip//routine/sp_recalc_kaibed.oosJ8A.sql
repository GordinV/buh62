CREATE FUNCTION sp_recalc_kaibed() RETURNS boolean
    LANGUAGE plpgsql
AS
$$
begin

	-- kustuta vana andmed

	delete from saldo ;
	
	-- new andmed insert
	-- deebet kaibed

	insert into saldo (rekvid, konto, dbkaibed, kuu, aasta, kpv, asutusId, tunnus)
	select CURjOURNAL.REKVID, curJournal.deebet, SUM(SUMMA) , kuu, aasta, date(aasta, kuu, sp_viimanepaev(kuu, aasta)), CURjOURNAL.ASUTUSiD, CURjOURNAL.TUNNUS   
	from curjournal inner join library on (curJournal.deebet =  library.kood and library.library = 'KONTOD') 
	GROUP BY CURjOURNAL.REkvid, tunnus, asutusId, kuu, aasta, deebet ;

	-- kreedit kaibed

	insert into saldo (rekvid, konto, krkaibed, kuu, aasta, kpv, asutusId, tunnus)
	select CURjOURNAL.REKVID, curJournal.kreedit, SUM(SUMMA) , kuu, aasta, date(aasta, kuu, sp_viimanepaev(kuu, aasta)), CURjOURNAL.ASUTUSiD, CURjOURNAL.TUNNUS   
	from curjournal inner join library on (curJournal.kreedit =  library.kood and library.library = 'KONTOD') 
	GROUP BY CURjOURNAL.REkvid, tunnus, asutusId, kuu, aasta, kreedit ;

	return true;

end;

$$;

ALTER FUNCTION sp_recalc_kaibed() OWNER TO vlad;

