CREATE FUNCTION sp_del_tuludeallikad(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 
	tnId alias for $1;
	tnOpt alias for $2;
begin
		Return sp_del_library(tnid);
end;
$$;

ALTER FUNCTION sp_del_tuludeallikad(INTEGER, INTEGER) OWNER TO vlad;

