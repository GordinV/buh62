CREATE FUNCTION trigi_arv3_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin
	UPDATE DBASE SET LASTNUM = NEW.ID WHERE id = 84;	 
	return NULL;
end;
$$;

ALTER FUNCTION trigi_arv3_after() OWNER TO vlad;

