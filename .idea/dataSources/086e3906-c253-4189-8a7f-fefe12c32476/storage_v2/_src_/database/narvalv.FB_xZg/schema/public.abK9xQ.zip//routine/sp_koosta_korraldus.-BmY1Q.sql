CREATE FUNCTION sp_koosta_korraldus(integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 

	tnId alias for $1;
	v_luba record;
	v_dekl record;
	lnresult int;
	lcAlus varchar;

begin
	lnresult = 0;
	select * into v_dekl from toiming where id = tnId;
	select * into v_luba from luba where id = v_dekl.lubaid;

	if v_luba.staatus = 0 then
		raise exception 'Luba anulleritud';
		return 0;
	end if;
	lcAlus = 'Dekl. number:'+ltrim(rtrim(v_luba.number))+space(1)+v_dekl.kpv::varchar;

	lnresult =  sp_salvesta_toiming(0, v_luba.parentid,v_luba.id, date(), lcAlus, '', date()+10, 0, 0, 'KORRALDUS', '', 0, 0);
	Return lnresult;

end;

$$;

ALTER FUNCTION sp_koosta_korraldus(INTEGER) OWNER TO vlad;

