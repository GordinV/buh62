CREATE FUNCTION del_twin_tootaja_ho(integer, integer) RETURNS character varying
    LANGUAGE plpgsql
AS
$$
declare 

	tnOige alias for $1;
	tnVale alias for $2;
	cMess varchar;
	lnCount int;
begin

/*
	update tooleping set parentid = tnOige where parentid = tnVale and rekvid = 31;

	update journal set asutusid = tnOige where asutusid = tnVale and rekvid = 31;

	update mk1 set asutusid = tnOige where asutusid = tnVale and parentid in (select id from mk where rekvid = 31);

--	delete from tooleping where rekvid = 51 and parentid in (tnVale);
--	muudetud 2005/01/18
*/
	update tooleping set parentid = tnOige where parentid = tnVale and rekvid = 51;
/*
	delete from asutus where id = tnVale;

	select count(*) into lnCount from asutus where id = tnVale;
	if lnCount < 2 then
		cmess := 'kustutatud';
	else
		cmess := 'ei ole kustutatud';

	end if;
*/

         return  cmess;
end;
$$;

ALTER FUNCTION del_twin_tootaja_ho(INTEGER, INTEGER) OWNER TO vlad;

