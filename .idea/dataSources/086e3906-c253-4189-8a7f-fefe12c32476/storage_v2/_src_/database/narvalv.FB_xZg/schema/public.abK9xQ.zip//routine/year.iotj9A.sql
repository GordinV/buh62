CREATE FUNCTION year(date) RETURNS integer
    LANGUAGE plpgsql
AS
$$
begin
         return  cast(extract(year from $1) as int);
end;
$$;

ALTER FUNCTION year(DATE) OWNER TO vlad;

