CREATE VIEW com_ladu_jaak(id, kood, jaak, rekvid, laduid) AS
SELECT qry.id,
       qry.kood,
       qry.jaak,
       qry.rekvid,
       qry.laduid
FROM (SELECT 0                         AS id,
             ''::CHARACTER VARYING(20) AS kood,
             (0)::NUMERIC              AS jaak,
             NULL::INTEGER             AS rekvid,
             NULL::INTEGER             AS laduid
      UNION
      SELECT n.id,
             n.kood,
             sum(j.jaak) AS jaak,
             j.rekvid,
             j.laduid
      FROM (libs.ladu_jaak j
               JOIN libs.nomenklatuur n ON ((n.id = j.nomid)))
      WHERE (n.status <> 3)
      GROUP BY n.id, n.kood, j.rekvid, j.laduid) qry
ORDER BY qry.kood, qry.jaak DESC;

ALTER TABLE com_ladu_jaak
    OWNER TO vlad;

