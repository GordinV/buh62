CREATE VIEW cur_eelproj(id, rekvid, aasta, kuu, status, dok_status, muud, regkood, parentid, asutus, kinnitaja,
                        cstaatus) AS
SELECT e.id,
       e.rekvid,
       e.aasta,
       e.kuu,
       e.status,
       ((enum_range(NULL::DOK_STATUS))[e.status])::TEXT          AS dok_status,
       (e.muud)::CHARACTER VARYING(254)                          AS muud,
       rekv.regkood,
       rekv.parentid,
       (rekv.nimetus)::CHARACTER VARYING(254)                    AS asutus,
       (COALESCE(u.ametnik, space(254)))::CHARACTER VARYING(254) AS kinnitaja,
       l.nimetus                                                 AS cstaatus
FROM (((eelarve.eelproj e
    JOIN ou.rekv rekv ON ((e.rekvid = rekv.id)))
    LEFT JOIN libs.library l ON ((((l.kood)::TEXT = (e.status)::TEXT) AND (l.library = 'STATUS'::BPCHAR))))
         LEFT JOIN ou.userid u ON ((e.kinnitaja = u.id)));

ALTER TABLE cur_eelproj
    OWNER TO vlad;

