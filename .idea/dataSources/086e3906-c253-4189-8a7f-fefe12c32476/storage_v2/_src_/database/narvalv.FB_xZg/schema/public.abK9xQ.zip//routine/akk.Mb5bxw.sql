CREATE FUNCTION akk(character varying, integer, integer, date, date) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
DECLARE tcKontogrupp alias for $1;
	tnAsutusid alias for $2;
	tnrekvid alias for $3;
	tdKpv1 alias for $3;
	tdKpv2 alias for $5;
	lnKr numeric (12,4);
begin	

	-- arv. kreedit kaibed
	select sum(summa) into lnKr from journal1 
		where ltrim(rtrim(kreedit)) = ltrim(rtrim(tcKontogrupp))
		and parentid in (select id from journal where rekvId = tnRekvId and asutusid = tnAsutusid 
		and kpv >= tdKpv1 and kpv <= tdKpv2);


	return ifnull(lnKr,0);
end;
$$;

ALTER FUNCTION akk(VARCHAR, INTEGER, INTEGER, DATE, DATE) OWNER TO vlad;

