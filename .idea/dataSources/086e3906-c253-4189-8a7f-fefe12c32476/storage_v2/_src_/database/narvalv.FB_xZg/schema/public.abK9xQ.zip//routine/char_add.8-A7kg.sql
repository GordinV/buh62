CREATE FUNCTION char_add(character, character) RETURNS character
    LANGUAGE plpgsql
AS
$$
begin
         return  $1||$2;
end;
$$;

ALTER FUNCTION char_add(CHAR, CHAR) OWNER TO vlad;

