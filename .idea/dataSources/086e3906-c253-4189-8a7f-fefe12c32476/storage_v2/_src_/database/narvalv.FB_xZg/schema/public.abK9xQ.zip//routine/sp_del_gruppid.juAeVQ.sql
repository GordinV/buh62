CREATE FUNCTION sp_del_gruppid(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 	
	tnId alias for $1;
	lnError int2;
begin
	DELETE FROM ladu_grupp WHERE parentid = tnId;
		lnError := 1;
		DELETE FROM gruppOmandus WHERE parentid = tnId;
		lnError := sp_del_library(tnid);
	if lnError > 0 then
		return 1;
	else
		return 0;
	end if;
end;
$$;

ALTER FUNCTION sp_del_gruppid(INTEGER, INTEGER) OWNER TO vlad;

