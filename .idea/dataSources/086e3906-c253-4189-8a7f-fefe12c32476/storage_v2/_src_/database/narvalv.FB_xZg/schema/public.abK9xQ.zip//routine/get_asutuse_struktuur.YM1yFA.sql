CREATE FUNCTION get_asutuse_struktuur(integer) RETURNS TABLE(rekv_id integer, parent_id integer)
    LANGUAGE SQL
AS
$$
WITH RECURSIVE chield_rekv(id, parentid) AS (
  SELECT
    id,
    parentid
  FROM ou.rekv
    where id = $1
  UNION
  SELECT
    rekv.id,
    rekv.parentid
  FROM chield_rekv, ou.rekv rekv
  WHERE rekv.parentid = chield_rekv.id

)
SELECT
  id,
  parentid
FROM chield_rekv;

$$;

ALTER FUNCTION get_asutuse_struktuur(INTEGER) OWNER TO vlad;

