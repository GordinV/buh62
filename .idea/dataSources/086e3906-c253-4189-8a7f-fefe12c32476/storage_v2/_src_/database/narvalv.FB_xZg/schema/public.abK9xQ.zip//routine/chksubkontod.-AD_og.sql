CREATE FUNCTION chksubkontod() RETURNS boolean
    LANGUAGE plpgsql
AS
$$
declare 
	v_alias1 record;
	lnCount int;
	lcString varchar;
begin
	
		
	for v_alias1 in select distinct rekvId, asutusid, kontoid from vmatrix 
	loop
		select count(*) into lnCount from subkonto where asutusId = v_alias1.asutusId and rekvid = v_alias1.rekvid and kontoid = v_alias1.kontoid; 
		if ifnull(lnCount,0) < 1 then
			lcString :=str(v_alias1.rekvid)+ str(v_alias1.asutusId)+str( v_alias1.kontoid);
			raise notice ' lisatud subkonto %', lcString;
			insert into subkonto (rekvId, asutusId, kontoid) values (v_alias1.rekvid, v_alias1.asutusId, v_alias1.kontoid);
		end if;

	End loop;
	return true;
end;

$$;

ALTER FUNCTION chksubkontod() OWNER TO vlad;

