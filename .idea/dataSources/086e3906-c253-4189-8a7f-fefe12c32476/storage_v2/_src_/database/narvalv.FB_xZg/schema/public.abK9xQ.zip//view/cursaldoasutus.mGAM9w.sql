CREATE VIEW cursaldoasutus(kpv, rekvid, konto, deebet, kreedit, opt, asutusid) AS
    SELECT date(2000, 1, 1) AS kpv,
           subkonto.rekvid,
           library.kood     AS konto,
           CASE
               WHEN (subkonto.algsaldo >= (0)::NUMERIC) THEN subkonto.algsaldo
               ELSE (0)::NUMERIC(12, 4)
               END          AS deebet,
           CASE
               WHEN (subkonto.algsaldo < (0)::NUMERIC) THEN ((- (1)::NUMERIC) * subkonto.algsaldo)
               ELSE (0)::NUMERIC(12, 4)
               END          AS kreedit,
           2                AS opt,
           subkonto.asutusid
    FROM (library
             JOIN subkonto ON ((library.id = subkonto.kontoid)))
    UNION ALL
    SELECT curjournal.kpv,
           curjournal.rekvid,
           curjournal.deebet   AS konto,
           curjournal.summa    AS deebet,
           (0)::NUMERIC(12, 4) AS kreedit,
           4                   AS opt,
           curjournal.asutusid
    FROM curjournal
    UNION ALL
    SELECT curjournal.kpv,
           curjournal.rekvid,
           curjournal.kreedit  AS konto,
           (0)::NUMERIC(12, 4) AS deebet,
           curjournal.summa    AS kreedit,
           4                   AS opt,
           curjournal.asutusid
    FROM curjournal;

ALTER TABLE cursaldoasutus
    OWNER TO vlad;

