CREATE VIEW cur_tunnus(id, kood, nimetus, rekvid) AS
SELECT l.id,
       l.kood,
       l.nimetus,
       l.rekvid
FROM libs.library l
WHERE ((l.library = 'TUNNUS'::BPCHAR) AND (l.status <> 3));

ALTER TABLE cur_tunnus
    OWNER TO postgres;

