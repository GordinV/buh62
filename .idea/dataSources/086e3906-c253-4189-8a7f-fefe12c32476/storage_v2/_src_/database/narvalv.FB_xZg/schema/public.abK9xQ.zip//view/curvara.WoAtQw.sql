CREATE VIEW curvara(id, kood, rekvid, nimetus, grupp, uhik, hind) AS
SELECT nomenklatuur.id,
       nomenklatuur.kood,
       nomenklatuur.rekvid,
       nomenklatuur.nimetus,
       gruppid.nimetus AS grupp,
       nomenklatuur.uhik,
       nomenklatuur.hind
FROM ((nomenklatuur
    JOIN ladu_grupp ON ((nomenklatuur.id = ladu_grupp.nomid)))
         JOIN library gruppid ON ((ladu_grupp.parentid = gruppid.id)));

ALTER TABLE curvara
    OWNER TO vlad;

