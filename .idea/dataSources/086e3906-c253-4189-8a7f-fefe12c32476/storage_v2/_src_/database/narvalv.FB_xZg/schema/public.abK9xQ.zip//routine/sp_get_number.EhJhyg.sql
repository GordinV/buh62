CREATE FUNCTION sp_get_number(integer, character varying) RETURNS character varying
    LANGUAGE plpgsql
AS
$$
DECLARE tnrekvid alias for $1;
	tcDok alias for $2;
	lcNumber varchar(20);
begin
	lcNumber := space(1);
	if tcDok = 'ARV' then
		select number into lcNumber from arv where rekvid = tnRekvId and liik = 0 order by id desc limit 1;
	end if;
	if tcDok = 'SORDER' then
		select number into lcNumber from korder1 where rekvid = tnRekvId and tyyp = 1 order by id desc limit 1;
	end if;
	if tcDok = 'VORDER' then
		select number into lcNumber from korder1 where rekvid = tnRekvId and tyyp = 2 order by id desc limit 1;
	end if;
	if tcDok = 'MK' then
		select number into lcNumber from mk where rekvid = tnRekvId and OPT = 1 order by id desc limit 1;
	end if;
	if tcDok = 'AVANS' then
		select number into lcNumber from avans1 where rekvid = tnRekvId   order by id desc limit 1;
	end if;

        return lcNumber ;
end;
$$;

ALTER FUNCTION sp_get_number(INTEGER, VARCHAR) OWNER TO vlad;

