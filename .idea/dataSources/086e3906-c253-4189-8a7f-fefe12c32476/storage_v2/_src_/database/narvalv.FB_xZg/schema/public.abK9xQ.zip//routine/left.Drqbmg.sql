CREATE FUNCTION "left"(character, integer) RETURNS character
    LANGUAGE plpgsql
AS
$$
begin
         return  lpad($1,$2);
end;
$$;

ALTER FUNCTION "left"(CHAR, INTEGER) OWNER TO vlad;

