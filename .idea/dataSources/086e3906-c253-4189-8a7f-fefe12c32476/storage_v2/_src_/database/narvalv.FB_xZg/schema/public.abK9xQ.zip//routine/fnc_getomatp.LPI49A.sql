CREATE FUNCTION fnc_getomatp(integer, integer) RETURNS character
    LANGUAGE plpgsql
AS
$$
DECLARE 
	tnrekvid alias for $1;
	tnAasta alias for $2;
	lcOmaTp character(20);
begin
lcOmaTp = '185101';

		SELECT TP INTO lcOmaTp FROM Aa WHERE Aa.parentid = tnrekvid  AND Aa.kassa = 2 ORDER BY ID DESC LIMIT 1;
		lcOmaTp = ifnull(lcOmaTp,'');
	return lcOmaTp;
end;

$$;

ALTER FUNCTION fnc_getomatp(INTEGER, INTEGER) OWNER TO vlad;

