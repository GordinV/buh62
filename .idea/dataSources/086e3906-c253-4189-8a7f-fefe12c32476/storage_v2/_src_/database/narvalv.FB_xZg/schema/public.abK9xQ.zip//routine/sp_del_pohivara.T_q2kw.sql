CREATE FUNCTION sp_del_pohivara(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 
	tnId alias for $1;
	tnOpt alias for $2;

begin

--	begin work;

	DELETE FROM pv_kaart WHERE parentid = tnId;

	if sp_del_library (tnId) > 0 then

--		commit work;

		return 1;

	else

--		rollback work;
		Return 0;
	end if;
end;
$$;

ALTER FUNCTION sp_del_pohivara(INTEGER, INTEGER) OWNER TO vlad;

