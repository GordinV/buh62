CREATE FUNCTION sp_del_tpr(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 
	tnId alias for $1;
	lnreturn int2;
begin
	select sp_del_library(tnId) into lnReturn;
	Return lnreturn;
end;
$$;

ALTER FUNCTION sp_del_tpr(INTEGER, INTEGER) OWNER TO vlad;

