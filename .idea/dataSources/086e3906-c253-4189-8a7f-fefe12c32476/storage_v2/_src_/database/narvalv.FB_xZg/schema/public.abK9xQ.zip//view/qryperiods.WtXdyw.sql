CREATE VIEW qryperiods(rekvid, kuu, aasta) AS
SELECT DISTINCT journal.rekvid,
                month(journal.kpv) AS kuu,
                year(journal.kpv)  AS aasta
FROM journal
ORDER BY journal.rekvid, (month(journal.kpv)), (year(journal.kpv));

ALTER TABLE qryperiods
    OWNER TO vlad;

