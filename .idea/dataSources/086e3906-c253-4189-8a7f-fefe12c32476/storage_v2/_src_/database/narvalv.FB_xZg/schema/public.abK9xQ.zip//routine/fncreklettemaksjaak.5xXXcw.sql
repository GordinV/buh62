CREATE FUNCTION fncreklettemaksjaak(tnasutusid integer, tdkpv date) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
declare
	lnSumma numeric(18,6);
	
begin
lnSumma = 0;

select sum(summa) into lnSumma from ettemaksud where asutusId = tnAsutusId and kpv <= tdKpv;
lnSumma = ifnull(lnSumma,0);

return lnSumma;
end;


$$;

ALTER FUNCTION fncreklettemaksjaak(INTEGER, DATE) OWNER TO vlad;

