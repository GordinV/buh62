CREATE FUNCTION exec_aasta_kinnitamine(integer, integer, integer) RETURNS boolean
    LANGUAGE plpgsql
AS
$$
declare tnRekvid alias for $1;
	tnAasta alias for $2;
	tnKuu alias for $3;

	v_rekv record;
	lnRekvid1 int;
	lnRekvId2 int;
	lnKuu1 int;
	lnKuu2 int;

	lnreturn int;
begin
	lnreturn = 1;
	lnRekvId1 = 0;
	lnRekvid2 = 9999;

	lnKuu1 = 0;
	lnKuu2 = 12;


	if tnrekvid > 0 then
		lnrekvId1 = tnRekvId;
		lnrekvId2 = tnRekvId;
	end if;

	if tnKuu > 0 then
		lnKuu1 = tnKuu;
		lnKuu2 = tnKuu;
	end if;

	for v_rekv in 
		select id, nimetus from rekv where id >= lnRekvId1 and id <= lnRekvId2
		loop
			if lnReturn = 1 then
				raise notice ' asutus %', v_rekv.nimetus;
				raise notice ' taitmine, kustutan vana andmed.. ';

				delete from eeltaitmine where rekvid = v_rekv.id and kuu >= lnKuu1 and kuu <= lnKuu2  and aasta = tnAasta;

				raise notice ' taitmine, lisan kulud andmed.. ';
	
				insert into eeltaitmine (rekvid,aasta,kuu,kood1,kood2,kood5,summa)
				select rekvid, aasta,kuu,tegev,kood2,kood,sum(summa) from curkassakuludetaitmine 
				where rekvid = v_rekv.id and kuu >= lnKuu1 and kuu <= lnKuu2  and aasta = tnAasta
				group by rekvid, aasta,kuu,tegev,kood2,kood;

				raise notice ' taitmine, lisan tulud andmed.. ';
	
				insert into eeltaitmine (rekvid,aasta,kuu,kood1,kood2, kood5,summa)
				select rekvid, aasta,kuu,tegev,kood2, kood,sum(summa) from curkassatuludetaitmine 
				where rekvid = v_rekv.id and kuu >= lnKuu1 and kuu <= lnKuu2  and aasta = tnAasta
				group by rekvid, aasta,kuu,tegev,kood2,kood;


				-- lnReturn :=  sp_kinnitaperiod_algsaldokoopia(v_rekv.id);


			end if;
		end loop;
	return true;
end;

$$;

ALTER FUNCTION exec_aasta_kinnitamine(INTEGER, INTEGER, INTEGER) OWNER TO vlad;

