CREATE FUNCTION del_twin_journalid() RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare 
	v_journalid record;
	lnId int;
	lnCount int;
	lnNumber int;
begin
	for v_journalid in 
		select journalid from journalid group by journalid having count(journalid) > 1
	loop

		select count(*) into lnCount from journalid where journalid = v_journalid.journalid;

		raise notice 'journalid %',v_journalid.journalid;
		raise notice 'lnCount %',lnCount;
		select id, number into lnId, lnNumber from journalid where journalid = v_journalid.journalid order by number limit 1;
		raise notice 'lnId %',lnId;
		update journal set dokid = lnNumber where id = v_journalid.journalid;
		delete from journalid where id = lnId;

	end loop;

         return  1;
end;
$$;

ALTER FUNCTION del_twin_journalid() OWNER TO vlad;

