CREATE FUNCTION sp_backup() RETURNS opaque
    LANGUAGE plpgsql
AS
$$
BEGIN
--declare @retvalue int
--exec @retvalue = sp_helpdevice "buhdata5" 
--if @retvalue = 1
--	EXEC sp_addumpdevice 'disk', 'buhdata5', 'c:ackupuhdata5.bak'

--BACKUP DATABASE buhdata5 TO buhdata5
end;
$$;

ALTER FUNCTION sp_backup() OWNER TO vlad;

