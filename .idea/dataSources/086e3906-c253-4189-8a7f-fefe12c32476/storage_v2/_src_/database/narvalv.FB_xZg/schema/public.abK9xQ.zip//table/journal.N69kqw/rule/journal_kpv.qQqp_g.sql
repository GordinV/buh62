CREATE RULE journal_kpv AS
    ON INSERT TO public.journal
   WHERE (new.kpv < date(2004, 1, 1)) DO INSTEAD NOTHING;

