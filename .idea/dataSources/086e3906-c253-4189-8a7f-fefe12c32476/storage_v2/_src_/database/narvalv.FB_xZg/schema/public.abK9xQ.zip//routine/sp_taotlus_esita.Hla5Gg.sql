CREATE FUNCTION sp_taotlus_esita(integer, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
DECLARE tnId alias for $1;
	tnAmetnikId alias for $2;

	lnresult integer;
	lnAllkiri integer;
	lnEelProjId integer;
begin	

lnEelProjId = 0;
lnresult = 0;

SELECT allkiri INTO lnAllkiri from taotlus WHERE id = tnid;
IF  ifnull(lnallkiri,0) = 1 then
	UPDATE taotlus SET staatus = 2, AmetnikID = tnAmetnikId WHERE id = tnid;
	lnresult = 1;	
ELSE
	lnresult = 0;
END IF;


RETURN lnresult;

end;

$$;

ALTER FUNCTION sp_taotlus_esita(INTEGER, INTEGER) OWNER TO vlad;

