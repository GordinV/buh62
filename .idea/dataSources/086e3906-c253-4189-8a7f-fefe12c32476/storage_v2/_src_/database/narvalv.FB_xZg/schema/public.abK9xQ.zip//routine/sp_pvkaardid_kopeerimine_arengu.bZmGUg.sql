CREATE FUNCTION sp_pvkaardid_kopeerimine_arengu(integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	tnrekvid alias for $1;

	lnNomMahaId int;
	lnNomPaigId int;
	lnPvOperId int;
	v_dokvaluuta record;
	lnId int; 
	lrPvKaardid record;
	ldKpv date;
	ldSoetKpv date;
	lcKood varchar(20);
	lcVanaKood varchar(20);
	lnTaastamine int;
	lnHind numeric(14,6);
	lnSoetmaks numeric(14,6);
	lnKulum numeric(14,6);
	lnAlgKulum numeric(14,6);
	lnUmberHind int;
	lnJournalId int;
	lnJournal1Id int;

	lnPvGrupp integer;
	l_count_id integer = 0;
begin

lnTaastamine = 0;
ldKpv = date(2015,03,2);
-- uus nom. operatsioon
lnId = 0;
select id into lnNomMahaId from nomenklatuur where rekvid = 28 and kood = 'PVMAHA' order by id desc limit 1;

if ifnull(lnNomMahaId,0) = 0 then
	-- operatsioon puudub, lisame
	lnNomMahaId = sp_salvesta_nomenklatuur(0, 28, 0, 'MAHAKANDMINE','PVMAHA', 'PV kaardid mahakandmine', '', 0, 'Rahandusameti korraldus',0, 0, '', 'EUR', 1);
end if;

select id into lnNomPaigId from nomenklatuur where rekvid = 29 and kood = 'PVPAIG' order by id desc limit 1;
if ifnull(lnNomPaigId,0) = 0 then
	-- operatsioon puudub, lisame
	lnNomPaigId = sp_salvesta_nomenklatuur(0, 29, 0, 'PAIGUTUS','PVPAIG', 'PV kaardid paigaldamine', '', 0, 'Rahandusameti korraldus',0, 0, '', 'EUR', 1);
end if;



for lrPvKaardid  in
	select * from curPohivara where rekvid = 28 and tunnus = 1  
	and kood not in ('S155400-01', 'S155400-02','MUU-0001','MUU-0008', 'MUU-0009', 'MUU-78/1-4', 'MUU-79', 'MUU155600-01', 'MUU155600-02', 'IMM156600-3', 'IMM156600-4',
		'MAA1400', 'KORT880')
	and konto not in ('155500')
	and mahakantud is null

	--and id = 36051
loop
	raise notice 'PV kaart: %',lrPvKaardid.kood;

	-- otsime
	if (select count(*) from curPohivara where rekvid = 29 and kood = lrPvKaardid.kood) = 0 then
		raise notice 'Import';
		-- pv grupp
		select id into lnPvGrupp from library where rekvid = 29 and alltrim(nimetus) = alltrim(lrPvKaardid.grupp) and library = 'PVGRUPP';
		if lnPvGrupp is null then
			insert into library (rekvid, kood, nimetus, library, tun1, tun2, tun5)
				select 29, kood, nimetus, library, tun1, tun2, tun5 from library where rekvid = 28 and alltrim(nimetus) = alltrim(lrPvKaardid.grupp) and library = 'PVGRUPP';
			select id into lnPvGrupp from library where rekvid = 28 and alltrim(nimetus) = alltrim(lrPvKaardid.grupp) and library = 'PVGRUPP';
			if lnPvGrupp is null then
				raise exception 'PV Grupp';
			end if;

		end if;
		-- uus kaart

		insert into library (rekvid, kood,  nimetus, library, muud,  tun1, tun2, tun3, tun4, tun5) 
			select 29, kood, nimetus, library.library, library.muud, library.tun1, library.tun2, library.tun3, library.tun4, library.tun5
				from library where id = lrPvKaardid.id;
				
		select id into lnId from library order by id desc;		 
		

		insert into pv_kaart (parentid, vastisikid, soetmaks, soetkpv, kulum , algkulum, gruppid,  konto, tunnus, otsus, muud, parhind)
			select lnid, vastisikid, parhind, date(2015,03,02), kulum , 
				coalesce ((select sum(summa) from pv_oper where liik = 2 and parentid = lrPvKaardid.id) + lrPvKaardid.algkulum,0),			
				lnPvGrupp,  konto, tunnus, otsus, muud, parhind  
			from pv_kaart where parentid = lrPvKaardid.id;

		raise notice 'Salvestatud PV kaart, lnId %', lnId;	

		-- paigaldus

		lnPvOperId = sp_salvesta_pv_oper(0, lnid, lnNomPaigId, 0, 1, ldKpv, lrPvKaardid.parhind, 'Paigaldamine', '', '', '', '', '', '', '', 0, '', 'PAIG', 'EUR', 1);		raise notice 'Salvestatud PV kaart, lnId %', lnId;	

		raise notice 'Salvestatud PV oper, lnPvOperId %', lnPvOperId;	

		-- mahakandmine
		
		lnPvOperId = sp_salvesta_pv_oper(0, lrPvKaardid.id, lnNomMahaId, 0, 4, ldKpv, lrPvKaardid.parhind, 'Mahakandmine', '', '', '', '', '', '', '', 0, '', 'MAHA', 'EUR', 1);

		raise notice 'Salvestatud PV mahakandmine, lnPvOperId %', lnPvOperId;	
		l_count_id  = l_count_id  +1;
	else
		raise notice 'Juba on';
	end if;
	raise notice 'l_count_id  %', l_count_id ;
end loop;

return lnId;
         
end;
$$;

ALTER FUNCTION sp_pvkaardid_kopeerimine_arengu(INTEGER) OWNER TO vlad;

