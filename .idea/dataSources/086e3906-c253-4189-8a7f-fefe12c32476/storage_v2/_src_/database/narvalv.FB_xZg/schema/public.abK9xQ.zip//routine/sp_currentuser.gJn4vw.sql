CREATE FUNCTION sp_currentuser(character varying, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare 
	tcKasutaja alias for $1;
	tnRekvid alias for $2;
	lnuserid int;
begin
	if ifnull(tnrekvid,0) = 0 or ifnull(lnuserid,0) = 0 then
		select id into lnuserid from userid where userid.kasutaja = tcKasutaja order by id desc limit 1;
	 end if;
	if ifnull(tnrekvid,0) > 0 then
		select id into lnuserid from userid where rekvid = tnrekvid and userid.kasutaja = tckasutaja;
	end if;

	return ifnull(lnUserid,0);
end;
$$;

ALTER FUNCTION sp_currentuser(VARCHAR, INTEGER) OWNER TO vlad;

