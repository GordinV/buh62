CREATE FUNCTION sp_taotlus_tagastada(integer, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
DECLARE tnId alias for $1;
	tnAmetnikId alias for $2;

	lnresult integer;
	lnStaatus integer;
	tmpEelProj record; 
begin	

lnresult = 0;
lnStaatus = 0;

SELECT staatus into lnStaatus from taotlus WHERE id = tnid;
 
IF  ifnull(lnstaatus,0) = 2 or  ifnull(lnstaatus,0) = 3 then
	raise notice 'tagastame ';
	UPDATE taotlus SET staatus = 4, AktseptID = tnAmetnikId WHERE id = tnid;
	lnresult = 1;	
ELSE
	raise notice 'ei saa tagastada ';
	lnresult = 0;
END IF;

RETURN lnresult;

end;

$$;

ALTER FUNCTION sp_taotlus_tagastada(INTEGER, INTEGER) OWNER TO vlad;

