CREATE FUNCTION sp_createsqlstring_for_saldo1(integer, integer, date, date, character, integer) RETURNS character
    LANGUAGE plpgsql
AS
$$
declare

	tnrekvid alias for $1;

	tnOpt alias for $2;

	tdKpv1 alias for $3;

	tdKpv2 alias for $4;

	tcKonto alias for $5;

	tnAsutusId alias for $6;

	lcString bpchar; 

	lnAlgKuu int2; 

	lnAasta int2;
	lcKpv1 varchar;

	lcKpv2 varchar;


begin

	lcString:= space(1);

--	tnAsutusId := ifnull(tnAsutusId,0);

	Select  aasta , kuu into lnAasta, lnAlgkuu From aasta Where kinni = 1 Order By kinni Desc, aasta Desc, kuu Desc limit 1;

	If not found then 

		raise notice 'Not found ';

		Select aasta, 1 into lnAasta, lnAlgkuu From aasta Order By aasta Asc, kuu Asc limit 1;

	End if;

	raise notice 'lnaasta ', lnaasta;

	raise notice 'lnKuu ', lnAlgKuu;

--	IF EMPTY(tdKpv1) OR tdKpv1 <= DATE(lnAasta, lnAlgKuu,1) AND tnOpt = 1 then

		if tnAsutusId = 0 then

			lcString := 'Select kontoinf.rekvid, Library.kood As konto, case when kontoinf.algsaldo >= 0 then kontoinf.algsaldo, 0::numeric(12,4) end As deebet,

				case when kontoinf.algsaldo < 0 then -1 * kontoinf.algsaldo, 0::numeric(12,4) end As kreedit 

				from Library INNER Join kontoinf On Library.Id = kontoinf.parentId ';

		else

			lcString := 'Select subkonto.rekvid, Library.kood As konto, case when subkonto.algsaldo >= 0 then subkonto.algsaldo, 0::numeric(12,4) end As deebet,

				case when subkonto.algsaldo < 0 then -1 * subkonto.algsaldo, 0::numeric(12,4) end As kreedit 

				from Library INNER Join subkonto On Library.Id = subkonto.KontoId ';

		end if;			

--	end if;

--				where kontoinf.rekvid = '+tnRekvid::varchar + ' And kood Like '+tckonto+';

--				where subkonto.rekvid = '+tnRekvid::varchar + ' And kood Like '+tckonto+'
--				and subkonto.asutusId = '+tnAsutusId::varchar ;





        return  lcstring;
end;
$$;

ALTER FUNCTION sp_createsqlstring_for_saldo1(INTEGER, INTEGER, DATE, DATE, CHAR, INTEGER) OWNER TO vlad;

