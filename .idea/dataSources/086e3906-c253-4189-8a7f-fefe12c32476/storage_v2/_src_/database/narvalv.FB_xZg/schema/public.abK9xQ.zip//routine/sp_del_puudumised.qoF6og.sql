CREATE FUNCTION sp_del_puudumised(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 
	tnId alias for $1;
	tnOpt alias for $2;
begin
	DELETE FROM puudumine WHERE id = tnid;
	if found then
		Return 1;
	else
		Return 0;
	end if;
end;
$$;

ALTER FUNCTION sp_del_puudumised(INTEGER, INTEGER) OWNER TO vlad;

