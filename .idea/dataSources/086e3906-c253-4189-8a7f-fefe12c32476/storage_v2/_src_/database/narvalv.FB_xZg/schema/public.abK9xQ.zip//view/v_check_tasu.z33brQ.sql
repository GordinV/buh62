CREATE VIEW v_check_tasu(id, kpv, rekvid, asutusid, dok, summa, arvid, nomid, number) AS
SELECT journal.id,
       journal.kpv,
       journal.rekvid,
       journal.asutusid,
       journal.dok,
       journal1.summa,
       arv.id          AS arvid,
       nomenklatuur.id AS nomid,
       arv.number
FROM ((((journal
    JOIN journal1 ON ((journal.id = journal1.parentid)))
    JOIN klassiflib ON ((((klassiflib.konto)::TEXT = (journal1.deebet)::TEXT) OR
                         ((klassiflib.konto)::TEXT = (journal1.kreedit)::TEXT))))
    JOIN nomenklatuur ON ((nomenklatuur.id = klassiflib.nomid)))
         JOIN arv ON ((arv.number = journal.dok)))
WHERE ((nomenklatuur.dok = 'TASU'::BPCHAR) AND (len((ltrim(rtrim((journal.dok)::TEXT)))::CHARACTER VARYING) > 0) AND
       (NOT (journal.id IN (SELECT arvtasu.journalid
                            FROM arvtasu))));

ALTER TABLE v_check_tasu
    OWNER TO vlad;

