CREATE FUNCTION sp_del_pvgruppid(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 

	tnId alias for $1;

	tnOpt alias for $2;

begin

	if sp_del_library(tnId) > 0 then


		Return 1;

	else


		Return 0;


	end if;


end;

$$;

ALTER FUNCTION sp_del_pvgruppid(INTEGER, INTEGER) OWNER TO vlad;

