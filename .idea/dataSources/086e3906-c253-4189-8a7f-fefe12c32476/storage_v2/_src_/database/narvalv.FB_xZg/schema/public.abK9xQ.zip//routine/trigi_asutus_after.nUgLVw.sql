CREATE FUNCTION trigi_asutus_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin
	UPDATE DBASE SET LASTNUM = NEW.ID WHERE id = 86;	 
	return NULL;
end;
$$;

ALTER FUNCTION trigi_asutus_after() OWNER TO vlad;

