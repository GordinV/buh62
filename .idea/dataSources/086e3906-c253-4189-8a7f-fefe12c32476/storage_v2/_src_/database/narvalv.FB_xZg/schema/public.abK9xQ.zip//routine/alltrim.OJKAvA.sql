CREATE FUNCTION alltrim(character) RETURNS character
    LANGUAGE plpgsql
AS
$$
begin
         return  trim(both chr(32) from $1);
end;
$$;

ALTER FUNCTION alltrim(CHAR) OWNER TO vlad;

