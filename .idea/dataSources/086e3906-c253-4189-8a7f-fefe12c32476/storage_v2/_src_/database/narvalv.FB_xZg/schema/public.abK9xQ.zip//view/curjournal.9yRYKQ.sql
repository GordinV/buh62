CREATE VIEW curjournal(id, rekvid, kpv, asutusid, kuu, aasta, selg, dok, summa, valsumma, valuuta, kuurs, kood1, kood2,
                       kood3, kood4, kood5, proj, deebet, kreedit, lisa_d, lisa_k, asutus, tunnus, number) AS
SELECT journal.id,
       journal.rekvid,
       journal.kpv,
       journal.asutusid,
       month(journal.kpv)                                                            AS kuu,
       year(journal.kpv)                                                             AS aasta,
       (journal.selg)::CHARACTER VARYING(254)                                        AS selg,
       journal.dok,
       journal1.summa,
       journal1.valsumma,
       (ifnull((dokvaluuta1.valuuta)::BPCHAR, 'EEK'::BPCHAR))::CHARACTER VARYING(20) AS valuuta,
       (ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))::NUMERIC(12, 6)                     AS kuurs,
       journal1.kood1,
       journal1.kood2,
       journal1.kood3,
       journal1.kood4,
       journal1.kood5,
       journal1.proj,
       journal1.deebet,
       journal1.kreedit,
       journal1.lisa_d,
       journal1.lisa_k,
       ifnull((((ltrim(rtrim((asutus.nimetus)::TEXT)))::BPCHAR + space(1)) +
               (ltrim(rtrim((asutus.omvorm)::TEXT)))::BPCHAR), space(120))           AS asutus,
       journal1.tunnus,
       journalid.number
FROM ((((journal
    JOIN journal1 ON ((journal.id = journal1.parentid)))
    JOIN journalid ON ((journal.id = journalid.journalid)))
    LEFT JOIN asutus ON ((journal.asutusid = asutus.id)))
         LEFT JOIN dokvaluuta1 ON (((journal1.id = dokvaluuta1.dokid) AND (dokvaluuta1.dokliik = 1))));

ALTER TABLE curjournal
    OWNER TO vlad;

