CREATE VIEW com_palklib(id, kood, nimetus, rekvid, liik, tund, maks, asutusest, palgafond, sots, round, konto) AS
SELECT qry.id,
       qry.kood,
       qry.nimetus,
       qry.rekvid,
       qry.liik,
       qry.tund,
       qry.maks,
       qry.asutusest,
       qry.palgafond,
       qry.sots,
       qry.round,
       qry.konto
FROM (SELECT 0                           AS id,
             ''::CHARACTER VARYING(20)   AS kood,
             ''::CHARACTER VARYING(20)   AS nimetus,
             NULL::INTEGER               AS rekvid,
             NULL::INTEGER               AS liik,
             NULL::INTEGER               AS tund,
             NULL::INTEGER               AS maks,
             NULL::INTEGER               AS asutusest,
             NULL::INTEGER               AS palgafond,
             NULL::INTEGER               AS sots,
             NULL::NUMERIC(12, 4)        AS round,
             NULL::CHARACTER VARYING(20) AS konto
      UNION
      SELECT l.id,
             l.kood,
             l.nimetus,
             l.rekvid,
             (((l.properties)::JSONB ->> 'liik'::TEXT))::INTEGER                AS liik,
             (((l.properties)::JSONB ->> 'tund'::TEXT))::INTEGER                AS tund,
             (((l.properties)::JSONB ->> 'maks'::TEXT))::INTEGER                AS maks,
             (((l.properties)::JSONB ->> 'asutusest'::TEXT))::INTEGER           AS asutusest,
             (((l.properties)::JSONB ->> 'palgafond'::TEXT))::INTEGER           AS palgafond,
             (((l.properties)::JSONB ->> 'sots'::TEXT))::INTEGER                AS sots,
             (((l.properties)::JSONB ->> 'round'::TEXT))::NUMERIC(12, 4)        AS round,
             (((l.properties)::JSONB ->> 'konto'::TEXT))::CHARACTER VARYING(20) AS konto
      FROM libs.library l
      WHERE ((l.library = 'PALK'::BPCHAR) AND (l.status <> 3))) qry
ORDER BY qry.kood;

ALTER TABLE com_palklib
    OWNER TO vlad;

