CREATE VIEW cur_avans(id, rekvid, created, lastupdate, userid, kpv, asutusid, isik, number, konto, kood5, tunnus,
                      dokpropid, summa, lausend, ametnik, nimetus, uritus, proj, jaak, valuuta, kuurs, kasutaja) AS
SELECT d.id,
       d.rekvid,
       to_char(d.created, 'DD.MM.YYYY HH:MM'::TEXT)              AS created,
       to_char(d.lastupdate, 'DD.MM.YYYY HH:MM'::TEXT)           AS lastupdate,
       a1.userid,
       a1.kpv,
       a1.asutusid,
       a.nimetus                                                 AS isik,
       a1.number,
       a2.konto,
       a2.kood5,
       a2.tunnus,
       a1.dokpropid,
       a2.summa,
       COALESCE(jid.number, 0)                                   AS lausend,
       u.ametnik,
       n.nimetus,
       a2.kood4                                                  AS uritus,
       a2.proj,
       a1.jaak,
       'EUR'::CHARACTER VARYING                                  AS valuuta,
       (1)::NUMERIC                                              AS kuurs,
       (COALESCE(u.ametnik, ''::BPCHAR))::CHARACTER VARYING(120) AS kasutaja
FROM ((((((((docs.doc d
    JOIN docs.avans1 a1 ON ((d.id = a1.parentid)))
    JOIN docs.avans2 a2 ON ((a1.id = a2.parentid)))
    JOIN libs.asutus a ON ((a.id = a1.asutusid)))
    JOIN libs.nomenklatuur n ON ((a2.nomid = n.id)))
    LEFT JOIN ou.userid u ON ((a1.userid = u.id)))
    LEFT JOIN docs.doc dd ON ((a1.journalid = dd.id)))
    LEFT JOIN docs.journal j ON ((j.parentid = dd.id)))
         LEFT JOIN docs.journalid jid ON ((jid.journalid = j.id)));

ALTER TABLE cur_avans
    OWNER TO vlad;

