CREATE VIEW cur_teenused(id, lastupdate, arv_id, number, rekvid, kpv, userid, asutusid, journalid, liik, operid, ladu,
                         asutus, regkood, kood, nimetus, uhik, hind, kogus, summa, kbm, kbmta, kaibemaks, objekt,
                         uritus, proj) AS
SELECT d.id,
       d.lastupdate,
       a.id                                                    AS arv_id,
       (btrim((a.number)::TEXT))::CHARACTER VARYING(20)        AS number,
       a.rekvid,
       a.kpv,
       a.userid,
       a.asutusid,
       a.journalid,
       a.liik,
       a.operid,
       ladu.kood                                               AS ladu,
       (btrim((asutus.nimetus)::TEXT))::CHARACTER VARYING(254) AS asutus,
       asutus.regkood,
       n.kood,
       n.nimetus,
       n.uhik,
       a1.hind,
       a1.kogus,
       a1.summa,
       a1.kbm,
       (a1.summa - a1.kbm)                                     AS kbmta,
       (n.properties ->> 'vat'::TEXT)                          AS kaibemaks,
       (COALESCE(o.kood, ''::BPCHAR))::CHARACTER VARYING(20)   AS objekt,
       a1.kood4                                                AS uritus,
       a1.proj
FROM (((((((docs.doc d
    JOIN docs.arv a ON ((a.parentid = d.id)))
    JOIN docs.arv1 a1 ON ((a1.parentid = a.id)))
    JOIN libs.nomenklatuur n ON ((n.id = a1.nomid)))
    LEFT JOIN libs.library o ON ((o.id = a.objektid)))
    LEFT JOIN libs.library ladu ON ((ladu.id = a.operid)))
    LEFT JOIN libs.asutus asutus ON ((a.asutusid = asutus.id)))
         LEFT JOIN ou.userid u ON ((u.id = a.userid)))
ORDER BY d.lastupdate DESC;

ALTER TABLE cur_teenused
    OWNER TO vlad;

