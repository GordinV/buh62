CREATE FUNCTION sp_calcrea_palkstat_aruanne231(integer, date, date, integer, character varying, character varying, integer, character varying, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
DECLARE 
	tnrekvid alias for $1;
	tdKpv1 alias for $2;
	tdKpv2 alias for $3;
	tnOsakond alias for $4;
	tcrea alias for $5;
	tcNimetus alias for $6;
	tnAmetkood alias for $7;
	lcreturn alias for $8;
	tnWorkdays alias for $9;
	ln1 numeric;
	ln2 numeric;
	ln3 numeric;
	ln4 numeric;
	ln5 numeric;
	ln6 numeric;
	lnOsakond1 int;
	lnOsakond2 int;
	v_tooaeg record;
	lnMehed	numeric;
	lnnaised numeric;
	lnMArv numeric;
	lnNarv numeric;
	lnMaeg numeric;
	lnNaeg numeric;
	
begin
--	raise notice ' start  ';
	

	if tnOsakond > 0 then
		lnOsakond1 := tnOsakond;
		lnOsakond2 := tnOsakond;
	else
		lnOsakond1 := 0;
		lnOsakond2 := 999999999;
	end if;
	lnMehed := 0;
	lnNaised := 0;
	lnMarv :=0;
	lnNarv := 0;
	lnMaeg :=0;
	lnNaeg := 0;

	for v_tooaeg  in
	select distinct toopaev from tooleping inner join palk_asutus on 
			(palk_asutus.osakondId = tooleping.osakondId and palk_asutus.ametid = tooleping.ametid)
			where tooleping.rekvId = tnRekvid 
			and tooleping.osakondId >= lnOsakond1 and tooleping.osakondId <= lnOsakond2
			and algab <= tdKpv1 and (empty(lopp) or lopp >= tdKpv2)
			and palk_asutus.vaba = tnAmetkood
			and toopaev > 0
	loop

--	raise notice ' 1  ';

		select count(*) into ln1 from tooleping inner join palk_asutus on 
			(palk_asutus.osakondId = tooleping.osakondId and palk_asutus.ametid = tooleping.ametid)
			where tooleping.rekvId = tnRekvid 
			and tooleping.osakondId >= lnOsakond1 and tooleping.osakondId <= lnOsakond2
			and algab <= tdKpv1 and (empty(lopp) or lopp >= tdKpv2)
			and palk_asutus.vaba = tnAmetkood
			and tooleping.toopaev = v_tooaeg.toopaev
			and tooleping.parentid in (select id from asutus where left(asutus.regkood,1) in ('3','5')	) ;

--	raise notice ' 2  ';

		select count(*) into ln4 from tooleping 
			inner join palk_asutus on (palk_asutus.osakondId = tooleping.osakondId and palk_asutus.ametid = tooleping.ametid)
			where tooleping.rekvId = tnRekvid 
			and tooleping.osakondId >= lnOsakond1 and tooleping.osakondId <= lnOsakond2
			and algab <= tdKpv1 and (empty(lopp) or lopp >= tdKpv2)
			and palk_asutus.vaba = tnAmetkood
			and tooleping.toopaev = v_tooaeg.toopaev
			and tooleping.parentid in (select id from asutus where left(asutus.regkood,1) in ('4','6')	) ;
--	raise notice ' 3  ';

		select sum(palk_taabel1.kokku) into ln2 from tooleping 
			inner join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId
			inner join palk_asutus on (palk_asutus.osakondId = tooleping.osakondId and palk_asutus.ametid = tooleping.ametid)
			where tooleping.rekvId = tnRekvid 
			and tooleping.osakondId >= lnOsakond1 and tooleping.osakondId <= lnOsakond2
			and algab <= tdKpv1 and (empty(lopp) or lopp >= tdKpv2)
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and palk_asutus.vaba = tnAmetkood
			and tooleping.parentid in (select id from asutus where left(asutus.regkood,1) in ('3','5')	) ;

--	raise notice ' 4  ';

		select sum(palk_taabel1.kokku) into ln5 from tooleping 
			inner join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId
			inner join palk_asutus on (palk_asutus.osakondId = tooleping.osakondId and palk_asutus.ametid = tooleping.ametid)
			where tooleping.rekvId = tnRekvid 
			and tooleping.osakondId >= lnOsakond1 and tooleping.osakondId <= lnOsakond2
			and algab <= tdKpv1 and (empty(lopp) or lopp >= tdKpv2)
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and palk_asutus.vaba = tnAmetkood
			and tooleping.parentid in (select id from asutus where left(asutus.regkood,1) in ('4','6')	) ;
	
--	raise notice ' 5  ';

		lnMArv := lnMArv + ln1 * v_tooaeg.toopaev::numeric;
		lnNArv := lnNArv + ln4 * v_tooaeg.toopaev::numeric;

		lnMehed := lnMehed + ln1; 
		lnNaised := lnNaised + ln4; 

		
	end loop;

	if lnMehed > 0 then
		-- average tunni mehed
		lnMehed := lnMarv / lnMehed;
		ln1 := ln2 / (lnmehed * tnWorkdays);
	end if;
	if lnNaised > 0 then
		-- average tunni naised
		lnnaised := lnNarv / lnNaised;
		ln4 := ln5 / (lnNaised*tnWorkdays);
	end if;
	
--	raise notice ' 6  ';

	select sum(palk_jaak.arvestatud) into ln3 from tooleping inner join palk_asutus on (palk_asutus.osakondId = tooleping.osakondId and palk_asutus.ametid = tooleping.ametid)
			inner join palk_jaak on tooleping.id = palk_jaak.lepingId
			where tooleping.rekvId = tnRekvid 
			and tooleping.osakondId >= lnOsakond1 and tooleping.osakondId <= lnOsakond2
			and algab <= tdKpv1 and (empty(lopp) or lopp >= tdKpv2) 
			and palk_jaak.kuu = month(tdKpv2)
			and palk_jaak.aasta = year(tdKpv2)
			and palk_asutus.vaba = tnAmetkood
			and tooleping.parentid in (select id from asutus where left(asutus.regkood,1) in ('3','5')	);

--	raise notice ' 7  ';

	select sum(palk_jaak.arvestatud) into ln6 from tooleping 
			 inner join palk_asutus on (palk_asutus.osakondId = tooleping.osakondId and palk_asutus.ametid = tooleping.ametid)
			inner join palk_jaak on tooleping.id = palk_jaak.lepingId
			where tooleping.rekvId = tnRekvid 
			and tooleping.osakondId >= lnOsakond1 and tooleping.osakondId <= lnOsakond2
			and algab <= tdKpv1 and (empty(lopp) or lopp >= tdKpv2)
			and palk_jaak.kuu = month(tdKpv2)
			and palk_jaak.aasta = year(tdKpv2)
			and palk_asutus.vaba = tnAmetkood
			and tooleping.parentid in (select id from asutus  where left(asutus.regkood,1) in ('4','6') );

--	raise notice ' 8  ';


	insert into tmp_palkstat2 (tbl, nimetus, rea, timestamp,rekvid,col1, col2, col3, col4, col5, col6)
		values (tcNimetus,str(tnAmetkood),tcRea,
		lcreturn, tnRekvid, ifnull(ln1,0), ifnull(ln2,0), ifnull(ln3,0),ifnull(ln4,0), ifnull(ln5,0), ifnull(ln6,0));


	return 1;

end;

$$;

ALTER FUNCTION sp_calcrea_palkstat_aruanne231(INTEGER, DATE, DATE, INTEGER, VARCHAR, VARCHAR, INTEGER, VARCHAR, INTEGER) OWNER TO vlad;

