CREATE FUNCTION sp_kinnitaperiod_algsaldokoopia(integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare 
	tnRekvId alias for $1;
begin
	raise notice ' tnrekvid %',tnrekvid;
--	update pg_trigger set tgenabled = false;

	-- kontrollime taabelid

		raise notice ' kustuta arved .. ';
		ALTER TABLE arv DISABLE TRIGGER ALL;
		update arv set journalid = 0 where kpv < date(2015,01,01) and rekvid = tnrekvId;
		ALTER TABLE arv enABLE TRIGGER ALL;

		raise notice ' kustuta mk .. ';
		ALTER TABLE mk DISABLE TRIGGER ALL;
		update mk set journalId = 0 where kpv < date(2015,01,01) and rekvid = tnrekvId;
		ALTER TABLE mk ENABLE TRIGGER ALL;

		raise notice ' kustuta korder1 .. ';
		ALTER TABLE korder1 DISABLE TRIGGER ALL;
		update korder1 set journalId = 0 where kpv < date(2015,01,01)and rekvid = tnrekvId;
		ALTER TABLE korder1 ENABLE TRIGGER ALL;

		raise notice ' kustuta palk_oper .. ';
		ALTER TABLE palk_oper DISABLE TRIGGER ALL;
		update palk_oper set journalId = 0 where kpv < date(2015,01,01)and rekvid = tnrekvId;
		ALTER TABLE palk_oper ENABLE TRIGGER ALL;

		raise notice ' kustuta avansiaruianned .. ';
		ALTER TABLE avans1 DISABLE TRIGGER ALL;
		update avans1 set journalId = 0 where kpv < date(2015,01,01) and rekvid = tnrekvId;
		ALTER TABLE avans1 ENABLE TRIGGER ALL;


		raise notice ' vaba pv_oper .. ';
		ALTER TABLE pv_oper DISABLE TRIGGER ALL;
		update pv_oper set journalId = 0 where kpv < date(2015,01,01) and parentid in (select id from curPohivara where rekvid = tnrekvId);
		ALTER TABLE pv_oper ENABLE TRIGGER ALL;

		raise notice ' vaba vanemtasu3 .. ';
		ALTER TABLE vanemtasu3 DISABLE TRIGGER ALL;
		update vanemtasu3 set journalId = 0 where kpv < date(2015,01,01) and rekvid = tnrekvId;
		ALTER TABLE vanemtasu3 ENABLE TRIGGER ALL;

		raise notice ' kustuta journal .. ';
		ALTER TABLE journal DISABLE TRIGGER ALL;
		ALTER TABLE journal1 DISABLE TRIGGER ALL;
		ALTER TABLE journalid DISABLE TRIGGER ALL;

		delete from journal1 where parentid in (select id from journal where kpv < date(2015,01,01) and rekvid = tnrekvId );

		delete from journalid where journalid in (select id from journal where kpv < date(2015,01,01) and rekvid = tnrekvId  );

		delete from journal where kpv < date(2015,01,01) and rekvid = tnrekvId;

--		raise notice ' kustuta journal1 .. ';

--		raise notice ' kustuta journalid .. ';

		ALTER TABLE journal ENABLE TRIGGER ALL;
		ALTER TABLE journal1 ENABLE TRIGGER ALL;
		ALTER TABLE journalid ENABLE TRIGGER ALL;


--	update pg_trigger set tgenabled = true;


	return 1;
end;
$$;

ALTER FUNCTION sp_kinnitaperiod_algsaldokoopia(INTEGER) OWNER TO vlad;

