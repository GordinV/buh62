CREATE FUNCTION ifnull(numeric, numeric) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
begin
	if $1 isnull then
		 return  $2;
	else
		return $1;
	end if;
end;
$$;

ALTER FUNCTION ifnull(NUMERIC, NUMERIC) OWNER TO vlad;

