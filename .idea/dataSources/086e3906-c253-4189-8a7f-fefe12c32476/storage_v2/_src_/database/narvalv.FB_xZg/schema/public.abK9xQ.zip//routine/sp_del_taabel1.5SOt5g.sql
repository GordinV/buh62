CREATE FUNCTION sp_del_taabel1(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 
	tnId alias for $1;
	tnOpt alias for $2;
begin
	DELETE FROM palk_taabel1 WHERE id = tnid;
	if found then
		Return 1;
	else
		Return 0;
	end if;
end;
$$;

ALTER FUNCTION sp_del_taabel1(INTEGER, INTEGER) OWNER TO vlad;

