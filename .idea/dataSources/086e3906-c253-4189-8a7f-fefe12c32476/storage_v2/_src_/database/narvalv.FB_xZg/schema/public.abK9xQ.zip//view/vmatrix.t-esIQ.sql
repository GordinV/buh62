CREATE VIEW vmatrix(asutusid, kontoid, rekvid) AS
    SELECT j.asutusid,
           l.id AS kontoid,
           j.rekvid
    FROM ((journal1 j1
        JOIN journal j ON ((j.id = j1.parentid)))
             JOIN library l ON ((((j1.deebet)::BPCHAR = l.kood) AND (l.library = 'KONTOD'::BPCHAR))))
    UNION ALL
    SELECT j.asutusid,
           l.id AS kontoid,
           j.rekvid
    FROM ((journal1 j1
        JOIN journal j ON ((j.id = j1.parentid)))
             JOIN library l ON ((((j1.kreedit)::BPCHAR = l.kood) AND (l.library = 'KONTOD'::BPCHAR))));

ALTER TABLE vmatrix
    OWNER TO vlad;

