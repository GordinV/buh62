CREATE FUNCTION sp_calc_vanemtasu_jaak(integer, integer, character varying) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
DECLARE tcTunnus alias for $3;
	tnRekvid alias for $2;
	tnisikid alias for $3;
	qryLapsed1 record;
	lnCount	int;
begin	
	lnCount := 0;
	for qryLapsed1  in 
		SELECT   sum( CASE WHEN vanemtasu3.opt = 1 THEN vanemtasu4.summa ELSE 0::numeric END) AS kassa, 
		 sum( CASE WHEN vanemtasu3.opt = 2 THEN vanemtasu4.summa ELSE 0::numeric END) AS fakt, 
		FROM vanemtasu3 INNER JOIN vanemtasu4 ON vanemtasu3.id = vanemtasu4.parentid;
		WHERE vanemtasu3.rekvId = tnrekvId
		vanemtasu4.isikid = tnIsikid	
		GROUP BY vanemtasu3.tunnus, vanemtasu4.isikId

--		AND IIF(!EMPTY(tcTunnus),vanemtasu3.tunnus,') = IIF(!EMPTY(tcTunnus),tcTunnus,');

	loop
		lnCount := lnCount + 1;
		UPDATE vanemtasu2 SET jaak = qryLapsed1.fakt - qryLapsed1.kassa WHERE isikId = qrylapsed1.isikId AND tunnus = qryLapsed1.tunnus and rekvid = tnrekvId;

	END loop;
	
	if lnCount = 0 then
		-- tühi
		UPDATE vanemtasu2 SET jaak = 0 WHERE isikId = tnIsikId AND tunnus = tcTunnus and rekvid = tnrekvId;
		
	end if;

		
	return 1;
end;
$$;

ALTER FUNCTION sp_calc_vanemtasu_jaak(INTEGER, INTEGER, VARCHAR) OWNER TO vlad;

