CREATE FUNCTION date(integer, integer, integer) RETURNS date
    LANGUAGE plpgsql
AS
$$
declare 

	tnYear alias for $1;

	tnMonth alias for $2;

	tnDay alias for $3;
	lcYear varchar(4);

	lcMonth varchar(2);

	lcDay varchar(2);

begin

	lcYear := str(tnYear,4);

	if tnMonth < 10 then

		lcMonth := '0'+str(tnMonth,1);

	else

		lcMonth:= str(tnMonth,2);

	end if;

	if tnDay < 10 then

		lcDay := '0'+str(tnDay,1);

	else

		lcDay:= str(tnday,2);

	end if;

         return  to_date(lcYear+lcMonth+lcDay,'YYYYMMDD');
end;
$$;

ALTER FUNCTION date(INTEGER, INTEGER, INTEGER) OWNER TO vlad;

