CREATE VIEW cur_volgnik(id, rekvid, regkood, nimetus, volg, jaak, intress) AS
SELECT qryvolgnik.id,
       qryvolgnik.rekvid,
       qryvolgnik.regkood,
       qryvolgnik.nimetus,
       qryvolgnik.volg,
       qryvolgnik.jaak,
       qryvolgnik.intress
FROM (SELECT a.id,
             l.rekvid,
             a.regkood,
             a.nimetus,
             sum(l.volg)    AS volg,
             sum(l.jaak)    AS jaak,
             sum(l.intress) AS intress
      FROM (libs.asutus a
               JOIN rekl.luba l ON ((a.id = l.asutusid)))
      WHERE ((l.staatus > 0) AND (l.staatus <> 3))
      GROUP BY a.id, a.regkood, a.nimetus, l.rekvid) qryvolgnik
WHERE (qryvolgnik.volg <> (0)::NUMERIC);

ALTER TABLE cur_volgnik
    OWNER TO vlad;

