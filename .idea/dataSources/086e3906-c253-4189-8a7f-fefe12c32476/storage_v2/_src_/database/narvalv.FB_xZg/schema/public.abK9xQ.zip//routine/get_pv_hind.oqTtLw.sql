CREATE FUNCTION get_pv_hind(integer, date) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
DECLARE tnPvKaartId alias for $1;
	tdKpv alias for $2;
	lnUmberhindatudSumma numeric (12,4);
begin	
	
	select summa into lnUmberhindatudSumma from pv_oper
		where parentId = tnPvKaartId and liik = 5 and kpv <= tdKpv 
		order by kpv desc limit 1;

	lnUmberhindatudSumma := ifnull(lnUmberhindatudSumma,0);

	return lnUmberhindatudSumma;
end;
$$;

ALTER FUNCTION get_pv_hind(INTEGER, DATE) OWNER TO vlad;

