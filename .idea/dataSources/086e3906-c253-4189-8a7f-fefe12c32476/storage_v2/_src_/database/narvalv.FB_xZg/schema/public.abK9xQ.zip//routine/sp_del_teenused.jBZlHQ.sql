CREATE FUNCTION sp_del_teenused(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 
	tnId alias for $1;
begin

	return sp_del_arved(tnId);
end;
$$;

ALTER FUNCTION sp_del_teenused(INTEGER, INTEGER) OWNER TO vlad;

