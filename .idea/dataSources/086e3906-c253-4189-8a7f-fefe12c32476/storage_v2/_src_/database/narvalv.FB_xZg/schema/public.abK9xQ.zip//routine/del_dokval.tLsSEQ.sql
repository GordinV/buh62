CREATE FUNCTION del_dokval() RETURNS numeric
    LANGUAGE plpgsql
AS
$$
DECLARE 
	lnId integer;
	lnCount integer;
	v_dokval record;
begin	
	lnCount = 0;

	for v_dokval in
		select  dokid from dokvaluuta1 where dokliik = 18 group by dokid, dokliik having count(dokid)>1
	loop
		select id into lnId from dokvaluuta1 where dokliik = 18 and dokid =v_dokval.dokid order by id limit 1;
		lnId = ifnull(lnId,0);
		if lnid > 0 then
			raise notice 'Found dokval %',v_dokval.dokid;
			delete from dokvaluuta1 where dokliik = 18 and dokid = v_dokval.dokid and id <> lnId;
		end if;
		lnCount = lnCount + 1;
	end loop;


	return lnCount;
end;
$$;

ALTER FUNCTION del_dokval() OWNER TO vlad;

