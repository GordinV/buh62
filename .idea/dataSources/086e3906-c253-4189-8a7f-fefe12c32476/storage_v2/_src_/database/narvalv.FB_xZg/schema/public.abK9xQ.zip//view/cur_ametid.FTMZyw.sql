CREATE VIEW cur_ametid(id, amet, osakond, rekvid, kogus, vaba, palgamaar) AS
SELECT a.id,
       a.nimetus                                                AS amet,
       o.nimetus                                                AS osakond,
       a.rekvid,
       (((a.properties)::JSONB ->> 'kogus'::TEXT))::NUMERIC     AS kogus,
       (((a.properties)::JSONB ->> 'vaba'::TEXT))::NUMERIC      AS vaba,
       (((a.properties)::JSONB ->> 'palgamaar'::TEXT))::INTEGER AS palgamaar
FROM (libs.library a
         JOIN libs.library o ON (((((a.properties)::JSONB ->> 'osakondid'::TEXT))::INTEGER = o.id)))
WHERE (a.status <> 3);

ALTER TABLE cur_ametid
    OWNER TO vlad;

