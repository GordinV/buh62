CREATE FUNCTION sp_check_twins(date, integer, integer, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	tdKpv alias for $1;
	tnLibId alias for $2;
	tnlepingId alias for $3;
	tnId alias for $4;
	v_palk_oper record;
	lnError int;


begin
	for v_palk_oper in 
		SELECT Palk_oper.id, palk_oper.libId, palk_lib.liik 
		FROM Palk_oper 
		inner join palk_lib on palk_oper.libId = palk_lib.Parentid
		WHERE Palk_oper.libId = tnLibId   
		AND Palk_oper.kpv = tdKpv
		AND Palk_oper.LepingId = tnLepingId
		and palk_lib.liik not in (6,9) 
		and palk_oper.id <> tnid 
		and palk_oper.summa <> 0 
	loop
		raise notice 'Kustutan v_palk_oper.id %', v_palk_oper.id;
		lnError := sp_del_palk_oper(v_palk_oper.id,1);
	end loop;


	return lnError;


end;

$$;

ALTER FUNCTION sp_check_twins(DATE, INTEGER, INTEGER, INTEGER) OWNER TO vlad;

