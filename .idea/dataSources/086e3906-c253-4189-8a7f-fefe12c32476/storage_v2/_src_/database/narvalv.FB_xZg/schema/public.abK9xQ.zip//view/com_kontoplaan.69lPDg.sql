CREATE VIEW com_kontoplaan(id, kood, nimetus, rekvid, tyyp, tun1, tun2, tun3, tun4) AS
SELECT qry.id,
       qry.kood,
       qry.nimetus,
       qry.rekvid,
       qry.tyyp,
       qry.tun1,
       qry.tun2,
       qry.tun3,
       qry.tun4
FROM (SELECT 0                         AS id,
             ''::CHARACTER VARYING(20) AS kood,
             ''::CHARACTER VARYING(20) AS nimetus,
             NULL::INTEGER             AS rekvid,
             1                         AS tyyp,
             0                         AS tun1,
             0                         AS tun2,
             0                         AS tun3,
             0                         AS tun4
      UNION
      SELECT l.id,
             l.kood,
             l.nimetus,
             l.rekvid,
             l.tun5 AS tyyp,
             l.tun1,
             l.tun2,
             l.tun3,
             l.tun4
      FROM libs.library l
      WHERE ((l.library = 'KONTOD'::BPCHAR) AND (l.status <> 3))) qry
ORDER BY qry.kood;

ALTER TABLE com_kontoplaan
    OWNER TO vlad;

