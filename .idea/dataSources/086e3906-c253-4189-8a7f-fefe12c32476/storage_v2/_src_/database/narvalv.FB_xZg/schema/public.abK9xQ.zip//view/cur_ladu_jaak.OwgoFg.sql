CREATE VIEW cur_ladu_jaak(id, kood, nimetus, jaak, hind, rekvid, laduid, ladu, grupp) AS
SELECT n.id,
       n.kood,
       n.nimetus,
       sum(j.jaak) AS jaak,
       j.hind,
       j.rekvid,
       j.laduid,
       l.kood      AS ladu,
       g.nimetus   AS grupp
FROM (((libs.ladu_jaak j
    JOIN libs.nomenklatuur n ON ((n.id = j.nomid)))
    JOIN libs.library g ON ((g.id = ((n.properties ->> 'gruppid'::TEXT))::INTEGER)))
         LEFT JOIN libs.library l ON ((l.id = j.laduid)))
WHERE (n.status <> 3)
GROUP BY n.id, n.kood, j.rekvid, j.laduid, j.hind, l.kood, g.nimetus;

ALTER TABLE cur_ladu_jaak
    OWNER TO vlad;

