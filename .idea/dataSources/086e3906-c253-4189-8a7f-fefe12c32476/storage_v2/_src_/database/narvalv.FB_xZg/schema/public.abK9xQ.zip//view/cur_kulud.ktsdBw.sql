CREATE VIEW cur_kulud(id, rekvid, aasta, summa, kood1, kood2, kood3, kood4, kood5, tunnus, asutus, regkood, parentid,
                      parasutus, parregkood, kuu, kpv, muud, is_parandus, valuuta, kuurs, tun, nimetus) AS
SELECT e.id,
       e.rekvid,
       e.aasta,
       e.summa,
       (COALESCE(e.kood1, ''::CHARACTER VARYING))::CHARACTER VARYING(20)  AS kood1,
       (COALESCE(e.kood2, ''::CHARACTER VARYING))::CHARACTER VARYING(20)  AS kood2,
       (COALESCE(e.kood3, ''::CHARACTER VARYING))::CHARACTER VARYING(20)  AS kood3,
       (COALESCE(e.kood4, ''::CHARACTER VARYING))::CHARACTER VARYING(20)  AS kood4,
       (COALESCE(e.kood5, ''::CHARACTER VARYING))::CHARACTER VARYING(20)  AS kood5,
       (COALESCE(e.tunnus, ''::CHARACTER VARYING))::CHARACTER VARYING(20) AS tunnus,
       (r.nimetus)::CHARACTER VARYING(254)                                AS asutus,
       r.regkood,
       r.parentid,
       (COALESCE(parent.nimetus, ''::TEXT))::CHARACTER VARYING(254)       AS parasutus,
       (COALESCE(parent.regkood, ''::BPCHAR))::CHARACTER VARYING(20)      AS parregkood,
       e.kuu,
       e.kpv,
       e.muud,
       e.is_parandus,
       'EUR'::CHARACTER VARYING                                           AS valuuta,
       (1)::NUMERIC                                                       AS kuurs,
       e.is_parandus                                                      AS tun,
       l.nimetus
FROM (((eelarve.kulud e
    JOIN ou.rekv r ON ((e.rekvid = r.id)))
    LEFT JOIN ou.rekv parent ON ((parent.id = r.parentid)))
         LEFT JOIN libs.library l
                   ON (((l.kood = (e.kood5)::BPCHAR) AND (l.library = 'TULUDEALLIKAD'::BPCHAR) AND (l.tun5 = 2))))
WHERE (e.status <> array_position(enum_range(NULL::DOK_STATUS), 'deleted'::DOK_STATUS));

ALTER TABLE cur_kulud
    OWNER TO vlad;

