CREATE VIEW cureelarvekulud(id, rekvid, aasta, allikasid, summa, kood1, kood2, kood3, kood4, kood5, tunnus, asutus,
                            regkood, parentid, parasutus, parregkood, kuu, kpv, muud, valuuta, kuurs, tun) AS
SELECT eelarve.id,
       eelarve.rekvid,
       eelarve.aasta,
       eelarve.allikasid,
       eelarve.summa,
       eelarve.kood1,
       eelarve.kood2,
       eelarve.kood3,
       eelarve.kood4,
       eelarve.kood5,
       (ifnull(t.kood, space(20)))::CHARACTER VARYING                            AS tunnus,
       rekv.nimetus                                                              AS asutus,
       rekv.regkood,
       rekv.parentid,
       ifnull(parent.nimetus, space(254))                                        AS parasutus,
       ifnull(parent.regkood, space(20))                                         AS parregkood,
       eelarve.kuu,
       eelarve.kpv,
       eelarve.muud,
       (ifnull((dokvaluuta1.valuuta)::BPCHAR, 'EEK'::BPCHAR))::CHARACTER VARYING AS valuuta,
       ifnull(dokvaluuta1.kuurs, (1)::NUMERIC)                                   AS kuurs,
       eelarve.tunnus                                                            AS tun
FROM (((((eelarve
    JOIN rekv ON ((eelarve.rekvid = rekv.id)))
    JOIN library ON ((((eelarve.kood5)::BPCHAR = library.kood) AND (library.library = 'TULUDEALLIKAD'::BPCHAR))))
    LEFT JOIN dokvaluuta1 ON (((eelarve.id = dokvaluuta1.dokid) AND (dokvaluuta1.dokliik = 8))))
    LEFT JOIN rekv parent ON ((parent.id = rekv.parentid)))
         LEFT JOIN library t ON ((t.id = eelarve.tunnusid)))
WHERE (library.tun5 = 2);

ALTER TABLE cureelarvekulud
    OWNER TO vlad;

