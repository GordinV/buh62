CREATE FUNCTION fnc_ntod(integer) RETURNS date
    LANGUAGE plpgsql
AS
$$
DECLARE 
	tnKpv alias for $1;
	lnAasta integer;
	lnKuu integer;
	lnPaev integer;
	lcKpv varchar;
	
	ldReturn date;
	inId int;
begin
ldReturn = date(2099,12,31);
	if tnKpv > 19000101 then
		lcKpv = str(tnKpv);
		lnAasta = val(left(lcKpv,4));
		raise notice 'lnAasta %',lnAasta;
		lnPaev = tnKpv - val(left(lcKpv,6))*100;
		raise notice 'lnPaev %',lnPaev;
		lnKuu = val(left(lcKpv,6)) - lnAasta*100;	
		raise notice 'lnKuu %',lnKuu;
		if (lnAasta < 1900 or lnAasta > 2100) or (lnKuu < 1 or lnKuu > 12) or (lnPaev < 1 or lnPaev > 31) then
			ldReturn = date(2099,12,31);
		else		
			ldReturn = date(lnAasta, lnKuu, lnPaev);
		end if;
	end if;
	
	return ldReturn;
end;
$$;

ALTER FUNCTION fnc_ntod(INTEGER) OWNER TO vlad;

