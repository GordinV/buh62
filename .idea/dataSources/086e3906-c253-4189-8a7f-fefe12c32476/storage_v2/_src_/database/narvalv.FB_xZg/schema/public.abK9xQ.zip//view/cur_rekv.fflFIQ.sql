CREATE VIEW cur_rekv(id, regkood, parentid, nimetus, status) AS
SELECT r.id,
       r.regkood,
       r.parentid,
       r.nimetus,
       r.status
FROM ou.rekv r
WHERE ((r.parentid < 999) OR (r.status <> 3))
ORDER BY r.regkood;

ALTER TABLE cur_rekv
    OWNER TO vlad;

