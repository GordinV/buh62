CREATE FUNCTION check_raamat_aeg() RETURNS integer
    LANGUAGE plpgsql
AS
$$
begin
	delete from raamat where  aeg < current_date - interval '3 month';
	return 1;
end;
$$;

ALTER FUNCTION check_raamat_aeg() OWNER TO vlad;

