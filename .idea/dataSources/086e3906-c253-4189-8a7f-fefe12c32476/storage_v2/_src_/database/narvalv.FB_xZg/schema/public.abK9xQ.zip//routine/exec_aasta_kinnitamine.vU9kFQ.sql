CREATE FUNCTION exec_aasta_kinnitamine() RETURNS boolean
    LANGUAGE plpgsql
AS
$$
declare v_rekv record;
	lnreturn int;
begin
	lnreturn = 1;
	for v_rekv in 
		select id, nimetus from rekv where id not in (5,7,8,9,11,13,25,30,31,32,35,51)
		loop
			if lnReturn = 1 then
			raise notice ' asutus %', v_rekv.nimetus;
			lnReturn :=  sp_kinnitaperiod_algsaldokoopia(v_rekv.id);
			end if;
		end loop;
	return true;
end;

$$;

ALTER FUNCTION exec_aasta_kinnitamine() OWNER TO vlad;

