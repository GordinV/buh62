CREATE FUNCTION datepart(character, date) RETURNS integer
    LANGUAGE plpgsql
AS
$$
begin
         return  date_part($1,$2);
end;
$$;

ALTER FUNCTION datepart(CHAR, DATE) OWNER TO vlad;

