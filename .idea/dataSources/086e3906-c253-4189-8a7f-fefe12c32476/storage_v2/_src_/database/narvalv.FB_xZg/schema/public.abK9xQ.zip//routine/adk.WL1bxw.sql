CREATE FUNCTION adk(character varying, integer, integer, date, date) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
DECLARE tcKontogrupp alias for $1;
	tnAsutusid alias for $2;
	tnrekvid alias for $3;
	tdKpv1 alias for $3;
	tdKpv2 alias for $5;
	lnDb numeric (12,4);

begin	

	-- arv. deebet kaibed
	select sum(summa) into lnDb from journal1 
		where ltrim(rtrim(deebet)) = ltrim(rtrim(tcKontogrupp))
		and parentid in (select id from journal where rekvId = tnRekvId and asutusid = tnAsutusid 
		and kpv >= tdKpv1 and kpv <= tdKpv2);


	return ifnull(lnDb,0);
end;
$$;

ALTER FUNCTION adk(VARCHAR, INTEGER, INTEGER, DATE, DATE) OWNER TO vlad;

