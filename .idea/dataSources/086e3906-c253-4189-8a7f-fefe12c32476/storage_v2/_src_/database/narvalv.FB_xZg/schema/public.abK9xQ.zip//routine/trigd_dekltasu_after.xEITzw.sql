CREATE FUNCTION trigd_dekltasu_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
declare 
	lnCount int4;
	lnSumma numeric(12,2);
begin

	-- kontrol dekl staatus
	if (select count(*) from dekltasu where deklid = old.deklId and id <> old.id) > 0  then
		-- on tasu infor dekl -> staatus = 2
		perform sp_muuda_deklstaatus(old.deklId, 2);
	else
		-- puudub -> staatus = 1
		perform sp_muuda_deklstaatus(old.deklId, 1);		
	end if;


	return NULL;
end;
$$;

ALTER FUNCTION trigd_dekltasu_after() OWNER TO vlad;

