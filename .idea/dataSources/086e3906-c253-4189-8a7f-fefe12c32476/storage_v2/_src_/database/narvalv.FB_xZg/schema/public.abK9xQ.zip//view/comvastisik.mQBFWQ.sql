CREATE VIEW comvastisik(id, isikid, rekvid, nimetus) AS
SELECT vastisikud.id,
       vastisikud.isikid,
       asutus.rekvid,
       asutus.nimetus
FROM (vastisikud
         JOIN asutus ON ((vastisikud.isikid = asutus.id)));

ALTER TABLE comvastisik
    OWNER TO vlad;

