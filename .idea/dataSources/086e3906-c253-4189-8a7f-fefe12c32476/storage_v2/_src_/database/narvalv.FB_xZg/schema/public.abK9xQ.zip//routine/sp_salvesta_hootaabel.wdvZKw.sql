CREATE FUNCTION sp_salvesta_hootaabel(integer, integer, integer, date, numeric, numeric, text) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	tnid alias for $1;
	tnIsikId alias for $2;
	tnNomId alias for $3;
	tdKpv alias for $4;
	tnKogus alias for $5;
	tnSumma alias for $6;
	ttmuud alias for $7;

	lnId int; 
	lrCurRec record;

begin

if tnId = 0 then
	-- uus kiri
	insert into hootaabel(isikid, nomid, kpv,kogus,summa, arvid,tuluarvid, muud) 
		values (tnisikid, tnnomid, tdkpv,tnkogus,tnsumma, 0,0, ttmuud);

	lnId:= cast(CURRVAL('public.hootaabel_id_seq') as int4);

else
	-- muuda 
	update hootaabel set 
		isikid = tnIsikId, 
		nomid = tnNomid, 
		kpv = tdKpv,
		kogus = tnKogus,
		summa = tnSumma, 
		muud = ttmuud
	where id = tnId;

	lnId := tnId;

end if;
return  lnId;

end;
$$;

ALTER FUNCTION sp_salvesta_hootaabel(INTEGER, INTEGER, INTEGER, DATE, NUMERIC, NUMERIC, TEXT) OWNER TO vlad;

