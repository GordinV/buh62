CREATE FUNCTION sp_del_varad(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 
	tnId alias for $1;
begin

	if sp_del_nomenklatuur(tnId,1) > 0 then

		delete from ladu_grupp where parentId = tnId;

		return 1;

	else

		return 0;

	end if;
end;
$$;

ALTER FUNCTION sp_del_varad(INTEGER, INTEGER) OWNER TO vlad;

