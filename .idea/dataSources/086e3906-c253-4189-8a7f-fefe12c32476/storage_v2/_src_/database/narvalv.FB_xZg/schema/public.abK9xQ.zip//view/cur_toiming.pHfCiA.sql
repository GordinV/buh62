CREATE VIEW cur_toiming(id, rekvid, created, lastupdate, number, asutusid, lubaid, kpv, tahtaeg, summa, tyyp, journalid,
                        lausend, status, saadetud, failid, jaak, deklid, parandus, fail, storage_type, staatus,
                        color) AS
SELECT qry.id,
       qry.rekvid,
       qry.created,
       qry.lastupdate,
       qry.number,
       qry.asutusid,
       qry.lubaid,
       qry.kpv,
       qry.tahtaeg,
       qry.summa,
       qry.tyyp,
       qry.journalid,
       qry.lausend,
       qry.status,
       qry.saadetud,
       qry.failid,
       qry.jaak,
       qry.deklid,
       qry.parandus,
       qry.fail,
       qry.storage_type,
       qry.staatus,
       (
           CASE
               WHEN ((qry.tyyp = 'DEKL'::REKL_TOIMING_LIIK) AND (qry.staatus IS NOT NULL) AND
                     (qry.saadetud IS NOT NULL) AND (qry.jaak <= (0)::NUMERIC)) THEN 'green'::TEXT
               WHEN ((qry.tyyp = 'DEKL'::REKL_TOIMING_LIIK) AND (qry.staatus IS NOT NULL) AND
                     (qry.saadetud IS NOT NULL) AND (COALESCE(qry.tahtaeg, CURRENT_DATE) > CURRENT_DATE) AND
                     (qry.jaak > (0)::NUMERIC)) THEN 'yellow'::TEXT
               WHEN ((qry.tyyp = 'DEKL'::REKL_TOIMING_LIIK) AND (qry.staatus IS NOT NULL) AND
                     (qry.saadetud IS NOT NULL) AND (COALESCE(qry.tahtaeg, CURRENT_DATE) < CURRENT_DATE) AND
                     (qry.jaak > (0)::NUMERIC)) THEN 'red'::TEXT
               WHEN ((qry.tyyp = 'INTRESS'::REKL_TOIMING_LIIK) AND (qry.staatus IS NULL)) THEN 'white'::TEXT
               WHEN ((qry.tyyp = 'INTRESS'::REKL_TOIMING_LIIK) AND (qry.staatus IS NOT NULL) AND
                     (COALESCE(qry.tahtaeg, CURRENT_DATE) < CURRENT_DATE) AND (qry.jaak > (0)::NUMERIC)) THEN 'red'::TEXT
               WHEN (((qry.tyyp = 'INTRESS'::REKL_TOIMING_LIIK) AND (qry.staatus IS NOT NULL) AND
                      (COALESCE(qry.tahtaeg, CURRENT_DATE) > CURRENT_DATE)) OR (qry.jaak <= (0)::NUMERIC)) THEN 'green'::TEXT
               ELSE 'white'::TEXT
               END)::CHARACTER VARYING(20) AS color
FROM (SELECT d.id,
             d.rekvid,
             to_char(d.created, 'DD.MM.YYYY HH:MM'::TEXT)                                         AS created,
             to_char(d.lastupdate, 'DD.MM.YYYY HH:MM'::TEXT)                                      AS lastupdate,
             (((ltrim(rtrim((l.number)::TEXT)))::BPCHAR + '-'::BPCHAR) +
              ((ltrim(rtrim(((t.number)::CHARACTER VARYING)::TEXT)))::CHARACTER VARYING)::BPCHAR) AS number,
             t.asutusid,
             t.lubaid,
             t.kpv,
             t.tahtaeg,
             t.summa,
             t.tyyp,
             t.journalid,
             COALESCE(jid.number, 0)                                                              AS lausend,
             COALESCE((t.staatus)::TEXT, ''::TEXT)                                                AS status,
             t.saadetud,
             t.failid,
             COALESCE(rekl.fnc_dekl_jaak(d.id), (0)::NUMERIC)                                     AS jaak,
             t.deklid,
             (COALESCE(('Dekl.nr:'::BPCHAR + (((SELECT tt.number
                                                FROM rekl.toiming tt
                                                WHERE (tt.id = t.deklid)))::CHARACTER VARYING)::BPCHAR),
                       ''::BPCHAR))::CHARACTER VARYING(20)                                        AS parandus,
             ((((t.lisa ->> 'failid'::TEXT))::JSONB ->> 'fail'::TEXT))::CHARACTER VARYING(254)    AS fail,
             ((((t.lisa ->> 'failid'::TEXT))::JSONB ->> 'tyyp'::TEXT))::CHARACTER VARYING(20)     AS storage_type,
             t.staatus
      FROM (((((docs.doc d
          JOIN rekl.toiming t ON ((t.parentid = d.id)))
          JOIN rekl.luba l ON ((t.lubaid = l.parentid)))
          LEFT JOIN docs.doc dd ON ((t.journalid = dd.id)))
          LEFT JOIN docs.journal j ON ((j.parentid = dd.id)))
               LEFT JOIN docs.journalid jid ON ((jid.journalid = j.id)))
      WHERE (COALESCE((t.staatus)::TEXT, ''::TEXT) <> 'deleted'::TEXT)) qry;

ALTER TABLE cur_toiming
    OWNER TO vlad;

