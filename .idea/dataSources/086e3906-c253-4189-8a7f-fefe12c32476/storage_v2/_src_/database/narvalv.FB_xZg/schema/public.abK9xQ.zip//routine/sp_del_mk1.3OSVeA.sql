CREATE FUNCTION sp_del_mk1(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 


	tnId alias for $1;
	tnOpt alias for $2;

	lnisikId integer;


begin

	Delete From mk Where Id = tnid;

	if found then
		delete from mk1 where parentid = tnId;
		delete from arvtasu where pankkassa = 1 and sorderid = tnid;
		select isikid into lnIsikId from hootehingud where ltrim(rtrim(doktyyp)) = 'PANK' and dokid = tnId order by id desc limit 1;
		delete from hootehingud where ltrim(rtrim(doktyyp)) = 'PANK' and dokid = tnId;

		if ifnull(lnIsikId,0) > 0 then
			perform sp_calc_hoojaak(lnIsikId);
		end if;
		Return 1;
	else
		Return 0;
	end if;





end;


$$;

ALTER FUNCTION sp_del_mk1(INTEGER, INTEGER) OWNER TO vlad;

