CREATE VIEW cur_tahtpaevad(id, nimetus, rekvid, paev, kuu, aasta, luhipaev) AS
SELECT l.id,
       l.nimetus,
       l.rekvid,
       (((l.properties)::JSONB ->> 'paev'::TEXT))::INTEGER     AS paev,
       (((l.properties)::JSONB ->> 'kuu'::TEXT))::INTEGER      AS kuu,
       (((l.properties)::JSONB ->> 'aasta'::TEXT))::INTEGER    AS aasta,
       (((l.properties)::JSONB ->> 'luhipaev'::TEXT))::INTEGER AS luhipaev
FROM libs.library l
WHERE ((l.library = 'TAHTPAEV'::BPCHAR) AND
       (l.status <> array_position(enum_range(NULL::DOK_STATUS), 'deleted'::DOK_STATUS)));

ALTER TABLE cur_tahtpaevad
    OWNER TO vlad;

