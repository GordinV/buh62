CREATE VIEW view_get_users_data(id, rekvid, kasutaja, ametnik, parool, kasutaja_, peakasutaja_, admin, muud, last_login,
                                asutus, allowed_access, allowed_libs) AS
SELECT u.id,
       u.rekvid,
       u.kasutaja,
       u.ametnik,
       u.parool,
       u.kasutaja_,
       u.peakasutaja_,
       u.admin,
       u.muud,
       u.last_login,
       r.nimetus AS asutus,
       rs.a      AS allowed_access,
       libs.libs AS allowed_libs
FROM (((ou.userid u
    JOIN ou.rekv r ON ((r.id = u.rekvid)))
    JOIN (SELECT u_1.kasutaja,
                 array_agg((((('{"id":'::TEXT || (u_1.rekvid)::TEXT) || ',"nimetus":"'::TEXT) ||
                             ltrim(rtrim(rekv.nimetus))) || '"}'::TEXT)) AS a
          FROM (ou.rekv
                   JOIN ou.userid u_1 ON ((u_1.rekvid = rekv.id)))
          GROUP BY u_1.kasutaja) rs ON ((rs.kasutaja = u.kasutaja)))
         JOIN (SELECT l.rekvid,
                      array_agg((((((('{"id":'::TEXT || (l.id)::TEXT) || ',"nimetus":"'::TEXT) ||
                                    ltrim(rtrim((l.nimetus)::TEXT))) || '","lib":"'::TEXT) ||
                                  ltrim(rtrim((l.library)::TEXT))) || '"}'::TEXT)) AS libs
               FROM libs.library l
               WHERE (l.library = 'DOK'::BPCHAR)
               GROUP BY l.rekvid) libs ON ((libs.rekvid = u.id)));

ALTER TABLE view_get_users_data
    OWNER TO postgres;

