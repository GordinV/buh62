CREATE VIEW cur_arved(id, docs_ids, arv_id, number, rekvid, kpv, summa, tahtaeg, jaak, tasud, tasudok, userid, asutusid,
                      journalid, liik, lisa, operid, objektid, asutus, regkood, omvorm, aadress, email, valuuta, kuurs,
                      objekt, created, lastupdate, status, ametnik, lausnr, markused, arve, viitenr) AS
SELECT d.id,
       d.docs_ids,
       a.id                                                               AS arv_id,
       btrim((a.number)::TEXT)                                            AS number,
       a.rekvid,
       a.kpv,
       a.summa,
       a.tahtaeg,
       a.jaak,
       a.tasud,
       a.tasudok,
       a.userid,
       a.asutusid,
       a.journalid,
       a.liik,
       a.lisa,
       a.operid,
       COALESCE(a.objektid, 0)                                            AS objektid,
       btrim((asutus.nimetus)::TEXT)                                      AS asutus,
       btrim((asutus.regkood)::TEXT)                                      AS regkood,
       btrim((asutus.omvorm)::TEXT)                                       AS omvorm,
       btrim(asutus.aadress)                                              AS aadress,
       btrim((asutus.email)::TEXT)                                        AS email,
       'EUR'::CHARACTER VARYING                                           AS valuuta,
       (1)::NUMERIC                                                       AS kuurs,
       (COALESCE(a.objekt, ''::CHARACTER VARYING))::CHARACTER VARYING(20) AS objekt,
       to_char(d.created, 'DD.MM.YYYY HH:MM'::TEXT)                       AS created,
       to_char(d.lastupdate, 'DD.MM.YYYY HH:MM'::TEXT)                    AS lastupdate,
       btrim((s.nimetus)::TEXT)                                           AS status,
       (COALESCE(u.ametnik, ''::BPCHAR))::CHARACTER VARYING(120)          AS ametnik,
       jid.number                                                         AS lausnr,
       a.muud                                                             AS markused,
       ((a.properties ->> 'aa'::TEXT))::CHARACTER VARYING(120)            AS arve,
       ((a.properties ->> 'viitenr'::TEXT))::CHARACTER VARYING(120)       AS viitenr
FROM ((((((docs.doc d
    JOIN docs.arv a ON ((a.parentid = d.id)))
    JOIN libs.library s ON ((((s.kood)::TEXT = (d.status)::TEXT) AND (s.library = 'STATUS'::BPCHAR))))
    LEFT JOIN libs.asutus asutus ON ((a.asutusid = asutus.id)))
    LEFT JOIN ou.userid u ON ((u.id = a.userid)))
    LEFT JOIN docs.journal j ON ((j.parentid = a.journalid)))
         LEFT JOIN docs.journalid jid ON ((jid.journalid = j.id)))
ORDER BY d.lastupdate DESC;

ALTER TABLE cur_arved
    OWNER TO vlad;

