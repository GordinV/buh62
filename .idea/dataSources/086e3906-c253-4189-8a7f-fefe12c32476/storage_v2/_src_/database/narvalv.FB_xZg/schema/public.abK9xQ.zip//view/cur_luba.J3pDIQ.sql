CREATE VIEW cur_luba(id, created, lastupdate, rekvid, lubaid, asutusid, number, algkpv, loppkpv, summa, jaak, volg,
                     asutus, regkood, status, staatus, ettemaks, parentid, intrjaak) AS
SELECT d.id,
       to_char(d.created, 'DD.MM.YYYY HH:MM'::TEXT)                                                       AS created,
       to_char(d.lastupdate, 'DD.MM.YYYY HH:MM'::TEXT)                                                    AS lastupdate,
       d.rekvid,
       luba.id                                                                                            AS lubaid,
       luba.asutusid,
       luba.number,
       luba.algkpv,
       luba.loppkpv,
       luba.summa,
       luba.jaak,
       luba.volg,
       a.nimetus                                                                                          AS asutus,
       a.regkood,
       (
           CASE
               WHEN (luba.staatus > 0) THEN ' Kehtiv'::TEXT
               ELSE 'Anulleritud'::TEXT
               END)::CHARACTER VARYING(20)                                                                AS status,
       luba.staatus,
       (SELECT sum(ettemaksud.summa) AS sum
        FROM rekl.ettemaksud
        WHERE (luba.parentid = luba.asutusid))                                                            AS ettemaks,
       luba.parentid,
       (SELECT sum((dekl_jaak.dekl - dekl_jaak.tasu)) AS sum
        FROM rekl.dekl_jaak
        WHERE ((dekl_jaak.asutusid = luba.asutusid) AND (dekl_jaak.tyyp = 'INTRESS'::REKL_TOIMING_LIIK))) AS intrjaak
FROM ((docs.doc d
    JOIN rekl.luba luba ON ((d.id = luba.parentid)))
         JOIN libs.asutus a ON ((a.id = luba.asutusid)));

ALTER TABLE cur_luba
    OWNER TO vlad;

