CREATE FUNCTION sp_eelproj_allkiri(integer, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
DECLARE tnId alias for $1;
	tnAmetnikId alias for $2;

	lnresult integer;
	tmpEelProj record; 
begin	

lnresult = 0;

SELECT * INTO tmpEelProj from eelproj WHERE id = tnid;
 
IF  tmpEelProj.staatus = 1 then
	--	* see tahendab et ainult uks voimas allkirjustada eelrve projekt kui staatus = 1

	UPDATE eelproj SET staatus = 2, kinnitaja = tnAmetnikId WHERE id = tnid;
	lnresult = sp_eelproj_kinnitamine(tnid);

ELSE
	lnresult = 0;
END IF;

RETURN lnresult;

end;

$$;

ALTER FUNCTION sp_eelproj_allkiri(INTEGER, INTEGER) OWNER TO vlad;

