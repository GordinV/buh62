CREATE VIEW cur_arvtasud(arvid, rekvid, number, arvkpv, arvsumma, tahtaeg, liik, asutus, kpv, summa, id, doc_tasu_id,
                         objekt, dok_type, dok, tasuliik, valuuta, kuurs, status) AS
SELECT arv.id                                               AS arvid,
       arv.rekvid,
       arv.number,
       arv.kpv                                              AS arvkpv,
       arv.summa                                            AS arvsumma,
       arv.tahtaeg,
       arv.liik,
       asutus.nimetus                                       AS asutus,
       arvtasu.kpv,
       arvtasu.summa,
       arvtasu.id,
       arvtasu.doc_tasu_id,
       COALESCE(arv.objekt, (space(20))::CHARACTER VARYING) AS objekt,
       CASE
           WHEN (arvtasu.pankkassa = 3) THEN 'JOURNAL'::TEXT
           WHEN (arvtasu.pankkassa = 1) THEN 'MK'::TEXT
           WHEN (arvtasu.pankkassa = 2) THEN 'KASSA'::TEXT
           ELSE NULL::TEXT
           END                                              AS dok_type,
       COALESCE(
               CASE
                   WHEN (arvtasu.pankkassa = 3) THEN ((jid.number)::TEXT ||
                                                      to_char((j.kpv)::TIMESTAMP WITH TIME ZONE, 'DD.MM.YYYY'::TEXT))
                   WHEN (arvtasu.pankkassa = 1) THEN ((m.number)::TEXT ||
                                                      to_char((m.kpv)::TIMESTAMP WITH TIME ZONE, 'DD.MM.YYYY'::TEXT))
                   WHEN (arvtasu.pankkassa = 2) THEN (k.number ||
                                                      to_char((k.kpv)::TIMESTAMP WITH TIME ZONE, 'DD.MM.YYYY'::TEXT))
                   ELSE NULL::TEXT
                   END, ''::TEXT)                           AS dok,
       CASE
           WHEN (arvtasu.pankkassa = 1) THEN 'MK'::CHARACTER VARYING
           WHEN (arvtasu.pankkassa = 2) THEN 'KASSA'::CHARACTER VARYING
           WHEN (arvtasu.pankkassa = 3) THEN 'RAAMAT'::CHARACTER VARYING
           ELSE 'MUUD'::CHARACTER VARYING
           END                                              AS tasuliik,
       'EUR'::CHARACTER VARYING(20)                         AS valuuta,
       (1)::NUMERIC                                         AS kuurs,
       arvtasu.status
FROM ((((((docs.arvtasu arvtasu
    JOIN docs.arv arv ON ((arvtasu.doc_arv_id = arv.id)))
    JOIN libs.asutus asutus ON ((asutus.id = arv.asutusid)))
    LEFT JOIN docs.journal j ON ((j.parentid = arvtasu.doc_tasu_id)))
    LEFT JOIN docs.journalid jid ON ((jid.journalid = j.id)))
    LEFT JOIN docs.mk m ON ((m.parentid = arvtasu.doc_tasu_id)))
         LEFT JOIN docs.korder1 k ON ((k.parentid = arvtasu.doc_tasu_id)))
WHERE (arvtasu.status <> 3);

ALTER TABLE cur_arvtasud
    OWNER TO vlad;

