CREATE VIEW com_asutused(id, regkood, nimetus, tp, email, kehtivus) AS
SELECT qry.id,
       qry.regkood,
       qry.nimetus,
       qry.tp,
       qry.email,
       qry.kehtivus
FROM (SELECT 0                                AS id,
             ''::CHARACTER VARYING(20)        AS regkood,
             ''::CHARACTER VARYING(254)       AS nimetus,
             ''::CHARACTER VARYING(20)        AS tp,
             ''::CHARACTER VARYING(254)       AS email,
             (date() + '100 years'::INTERVAL) AS kehtivus
      UNION
      SELECT asutus.id,
             btrim((asutus.regkood)::TEXT)                           AS regkood,
             (btrim((asutus.nimetus)::TEXT))::CHARACTER VARYING(254) AS nimetus,
             asutus.tp,
             asutus.email,
             COALESCE((((asutus.properties ->> 'kehtivus'::TEXT))::DATE)::TIMESTAMP WITHOUT TIME ZONE,
                      (date() + '10 years'::INTERVAL))               AS kehtivus
      FROM libs.asutus asutus
      WHERE (asutus.staatus <> 3)) qry
ORDER BY qry.nimetus;

ALTER TABLE com_asutused
    OWNER TO vlad;

