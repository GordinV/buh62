CREATE FUNCTION sp_kinni_aasta(integer, integer, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	tnRekvId alias for $1;
	tnKuu alias for $2;
	tnAasta alias for $3;
	lnId int; 

	lnKinni int;

	v_rekv record;
begin

	delete from tmpRekv;
	insert into tmpRekv
		SELECT id, parentid, fnc_get_asutuse_staatus(rekv.id, tnrekvid)::int as tase FROM rekv where parentid <> 9999;
	delete from tmpRekv where tase < 3;

	select kinni into lnKinni from aasta where rekvid = tnrekvid and aasta = tnAasta and kuu = tnKuu;
	lnKinni = ifnull(lnKinni,0);

	if lnKinni = 0 then
-- muuda 
		update aasta set 
			default_ = 0,
			kinni = 1
			where kuu = tnKuu 
			and aasta = tnAasta 
			and rekvid in (select id from tmpRekv);
	else
		-- ava
		update aasta set kinni = 0 where rekvid = tnrekvid and aasta = tnAasta and kuu = tnKuu;
	end if;

        return  1;
end;
$$;

ALTER FUNCTION sp_kinni_aasta(INTEGER, INTEGER, INTEGER) OWNER TO vlad;

