CREATE FUNCTION fnc_arv_volg(integer, date, integer) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
declare 
	tnrekvId ALIAS FOR $1;
	tdKpv	ALIAS FOR $2;
	tnAsutusId	ALIAS FOR $3;
	lnJaak numeric;
BEGIN

select sum(jaak*ifnull(dokvaluuta1.kuurs,1)) into lnJaak 
	from arv left outer join  dokvaluuta1 on (arv.id = dokvaluuta1.dokid and dokvaluuta1.dokliik = 3)  
	where arv.rekvid = tnRekvId and arv.asutusId = tnAsutusId and ifnull(arv.tasud,tdKpv) <= tdKpv;


RETURN lnJaak;


end;


$$;

ALTER FUNCTION fnc_arv_volg(INTEGER, DATE, INTEGER) OWNER TO vlad;

