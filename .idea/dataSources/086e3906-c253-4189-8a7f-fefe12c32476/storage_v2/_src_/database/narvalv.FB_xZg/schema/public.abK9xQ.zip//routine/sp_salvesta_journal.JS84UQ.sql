CREATE FUNCTION sp_salvesta_journal(integer, integer, integer, date, integer, text, character varying, text) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	tnId alias for $1;
	tnRekvId alias for $2;
	tnUserId alias for $3;
	tdKpv alias for $4;
	tnAsutusid alias for $5;
	ttSelg alias for $6;
	tcDok alias for $7;
	ttMuud alias for $8;
	lnId int;
begin

if tnId = 0 then
	-- uus kiri
	insert into journal (rekvid, userid , kpv, asutusid,selg,dok, muud) 
		values (tnrekvId, tnuserid , tdkpv, tnasutusid,ttselg,tcdok, ttmuud);

	lnId:= cast(CURRVAL('public.journal_id_seq') as int4);

else
	-- muuda
	update journal set 
		rekvid = tnRekvid, 
		userid = tnUserId, 
		kpv = tdKpv, 
		asutusid = tnAsutusid,
		selg = ttSelg,
		dok = tcDok,
		muud = ttMuud
		where id = tnId;

	lnId := tnId;
end if;

         return  lnId;
end;
$$;

ALTER FUNCTION sp_salvesta_journal(INTEGER, INTEGER, INTEGER, DATE, INTEGER, TEXT, VARCHAR, TEXT) OWNER TO vlad;

