CREATE VIEW cur_pohivara(id, kood, nimetus, rekvid, vastisik, vastisikid, algkulum, kulum, soetmaks, parhind, soetkpv,
                         konto, tunnus, mahakantud, rentnik, liik, selgitus, parent_id, pindala, valuuta, kuurs,
                         gruppid, grupp, parent_kood, parent_nimetus, aadress, status) AS
SELECT l.id,
       l.kood,
       l.nimetus,
       l.rekvid,
       (COALESCE(a.nimetus, ''::BPCHAR))::CHARACTER VARYING(254)                                               AS vastisik,
       (((l.properties)::JSONB ->> 'vastisikid'::TEXT))::INTEGER                                               AS vastisikid,
       (((l.properties)::JSONB ->> 'algkulum'::TEXT))::NUMERIC(12, 2)                                          AS algkulum,
       (((l.properties)::JSONB ->> 'kulum'::TEXT))::NUMERIC(12, 2)                                             AS kulum,
       (((l.properties)::JSONB ->> 'soetmaks'::TEXT))::NUMERIC(12, 2)                                          AS soetmaks,
       COALESCE((((l.properties)::JSONB ->> 'parhind'::TEXT))::NUMERIC(12, 2),
                (((l.properties)::JSONB ->> 'soetmaks'::TEXT))::NUMERIC(12, 2))                                AS parhind,
       COALESCE((((l.properties)::JSONB ->> 'soetkpv'::TEXT))::DATE,
                date(1900, 1, 1))                                                                              AS soetkpv,
       (COALESCE(((l.properties)::JSONB ->> 'konto'::TEXT), ''::TEXT))::CHARACTER VARYING(20)                  AS konto,
       (COALESCE(((l.properties)::JSONB ->> 'tunnus'::TEXT), ''::TEXT))::CHARACTER VARYING(20)                 AS tunnus,
       (((l.properties)::JSONB ->> 'mahakantud'::TEXT))::DATE                                                  AS mahakantud,
       (COALESCE(((l.properties)::JSONB ->> 'rentnik'::TEXT), ''::TEXT))::CHARACTER VARYING(120)               AS rentnik,
       (((l.properties)::JSONB ->> 'liik'::TEXT))::CHARACTER VARYING(120)                                      AS liik,
       (COALESCE(((l.properties)::JSONB ->> 'selg'::TEXT), ''::TEXT))::CHARACTER VARYING(120)                  AS selgitus,
       (((l.properties)::JSONB ->> 'parent_id'::TEXT))::INTEGER                                                AS parent_id,
       (COALESCE((((l.properties)::JSONB ->> 'pindala'::TEXT))::NUMERIC(12, 4),
                 (0)::NUMERIC))::NUMERIC(12, 4)                                                                AS pindala,
       'EUR'::CHARACTER VARYING                                                                                AS valuuta,
       (1)::NUMERIC                                                                                            AS kuurs,
       grupp.id                                                                                                AS gruppid,
       grupp.nimetus                                                                                           AS grupp,
       COALESCE(p.kood, ''::BPCHAR)                                                                            AS parent_kood,
       COALESCE(p.nimetus, ''::BPCHAR)                                                                         AS parent_nimetus,
       (COALESCE(((l.properties)::JSONB ->> 'aadress'::TEXT), ''::TEXT))::CHARACTER VARYING(254)               AS aadress,
       l.status
FROM (((libs.library l
    JOIN libs.library grupp ON ((((l.properties)::JSONB -> 'gruppid'::TEXT) = to_jsonb(grupp.id))))
    LEFT JOIN libs.asutus a ON ((((l.properties)::JSONB -> 'vastisikid'::TEXT) = to_jsonb(a.id))))
         LEFT JOIN libs.library p ON ((((l.properties)::JSONB -> 'parent_id'::TEXT) = to_jsonb(p.id))))
WHERE (l.status <> 3);

ALTER TABLE cur_pohivara
    OWNER TO vlad;

