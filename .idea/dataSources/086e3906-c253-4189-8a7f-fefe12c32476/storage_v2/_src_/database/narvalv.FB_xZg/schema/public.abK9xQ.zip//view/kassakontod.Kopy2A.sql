CREATE VIEW kassakontod(kood) AS
SELECT DISTINCT "left"(((ltrim(rtrim((library.kood)::TEXT)))::BPCHAR + '%'::BPCHAR), 20) AS kood
FROM library
WHERE (library.library = 'KASSAKONTOD'::BPCHAR)
ORDER BY ("left"(((ltrim(rtrim((library.kood)::TEXT)))::BPCHAR + '%'::BPCHAR), 20));

ALTER TABLE kassakontod
    OWNER TO vlad;

