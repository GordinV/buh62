CREATE VIEW curnomjaak(nomid, kogus) AS
SELECT ladu_jaak.nomid,
       sum(ladu_jaak.jaak) AS kogus
FROM ladu_jaak
GROUP BY ladu_jaak.nomid;

ALTER TABLE curnomjaak
    OWNER TO vlad;

