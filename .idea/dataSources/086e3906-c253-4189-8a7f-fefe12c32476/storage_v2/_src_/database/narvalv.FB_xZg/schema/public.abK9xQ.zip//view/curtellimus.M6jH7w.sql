CREATE VIEW curtellimus(id, rekvid, kpv, tund, minute, aeg, regnum, omanik, too, meister, status) AS
SELECT tellimus.id,
       tellimus.rekvid,
       tellimus.kpv,
       date_part('hour'::TEXT, tellimus.kpv)      AS tund,
       date_part('minute'::TEXT, tellimus.kpv)    AS minute,
       tellimus.aeg,
       tellimus.regnum,
       tellimus.omanik,
       tellimus.too,
       (tellimus.meister)::CHARACTER VARYING(120) AS meister,
       tellimus.status
FROM tellimus;

ALTER TABLE curtellimus
    OWNER TO vlad;

