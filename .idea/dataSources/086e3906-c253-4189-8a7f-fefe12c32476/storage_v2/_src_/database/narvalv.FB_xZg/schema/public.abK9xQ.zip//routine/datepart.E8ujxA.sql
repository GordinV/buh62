CREATE FUNCTION datepart(character, time without time zone) RETURNS integer
    LANGUAGE plpgsql
AS
$$
begin
         return  date_part($1,$2);
end;
$$;

ALTER FUNCTION datepart(CHAR, TIME) OWNER TO vlad;

