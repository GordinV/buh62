CREATE FUNCTION tmp_arvnumber() RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare v_arved record;
	v_journal record;
begin

	for v_arved in select * from arv where rekvid = 28 and journalid > 0
	loop	
		perform gen_lausend_arv(v_arved.id);
	End loop;

	return 1;
end;
$$;

ALTER FUNCTION tmp_arvnumber() OWNER TO vlad;

