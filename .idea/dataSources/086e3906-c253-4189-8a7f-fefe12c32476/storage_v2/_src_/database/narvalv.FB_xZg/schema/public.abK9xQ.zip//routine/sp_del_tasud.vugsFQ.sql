CREATE FUNCTION sp_del_tasud(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 
	tnId alias for $1;
begin
	delete from arvtasu where id = tnid;

	if found then

		return 1;

	else

		return 0;

	end if;

end;
$$;

ALTER FUNCTION sp_del_tasud(INTEGER, INTEGER) OWNER TO vlad;

