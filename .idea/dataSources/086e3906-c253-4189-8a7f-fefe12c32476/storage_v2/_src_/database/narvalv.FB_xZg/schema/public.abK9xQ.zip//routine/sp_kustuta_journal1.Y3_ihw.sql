CREATE FUNCTION sp_kustuta_journal1() RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare 
	v_journal1 record;
	v_journal record;
	v_journal2 record;
	lnCount int;
begin
	lnCount = 0;
-- restoring kustutatud andmed
	for v_journal2 in
		select journal2.id from journal2 inner join journal on journal.id = journal2.parentid where year(journal.kpv) = 2009
	loop
		if (select count(id) from journal1 where id = v_journal2.id) = 0 then
			-- restore
			raise notice ' Salvestan .. %',v_journal2.id;
		
			insert into journal1  (id, parentid,summa, dokument,muud, kood1,kood2, kood3, kood4, kood5,deebet,lisa_k, kreedit,lisa_d, 
				valuuta,kuurs, valsumma, tunnus, proj)
			select id, parentid,summa, dokument,muud, kood1,kood2, kood3, kood4, kood5,deebet,lisa_k, kreedit,lisa_d, 
				valuuta,kuurs, valsumma, tunnus, proj from journal2 where id = v_journal2.id;
		end if;
	end loop;

	for v_journal1 in 
		select distinct parentid from journal1 order by parentid 
	loop
		if (select count(id) from journal where id = v_journal1.parentid) = 0 then
			lnCount = lnCount + 1;
			raise notice ' Kustutan.. %',lnCount;

--			ALTER TABLE journal1 DISABLE TRIGGER ALL;
			delete from journal1 where parentid = v_journal1.parentid;
			delete from journalid where journalid = v_journal1.parentid;
--			ALTER TABLE journal1 enABLE TRIGGER ALL;
		end if;
	end loop;


	return 1;
end;
$$;

ALTER FUNCTION sp_kustuta_journal1() OWNER TO vlad;

