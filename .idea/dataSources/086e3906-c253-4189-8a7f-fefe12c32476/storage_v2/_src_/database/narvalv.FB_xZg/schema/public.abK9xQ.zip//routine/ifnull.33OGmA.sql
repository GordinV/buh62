CREATE FUNCTION ifnull(date, date) RETURNS date
    LANGUAGE plpgsql
AS
$$
begin
	if $1 is null then
		 return  $2;
	else
		 return  $1;
	end if;
end;
$$;

ALTER FUNCTION ifnull(DATE, DATE) OWNER TO vlad;

