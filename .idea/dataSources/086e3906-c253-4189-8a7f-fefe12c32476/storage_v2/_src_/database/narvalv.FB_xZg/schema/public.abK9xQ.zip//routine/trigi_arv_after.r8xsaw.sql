CREATE FUNCTION trigi_arv_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin
	UPDATE DBASE SET LASTNUM = NEW.ID WHERE id = 82;	 
	return NULL;
end;
$$;

ALTER FUNCTION trigi_arv_after() OWNER TO vlad;

