CREATE VIEW cur_korder(id, rekvid, kpv, number, nimi, dokument, created, lastupdate, tyyp, deebet, kreedit, status,
                       lausend, akonto, kassa, db, kr, valuuta, kuurs, journalid) AS
SELECT d.id,
       d.rekvid,
       k.kpv,
       (btrim(k.number))::CHARACTER VARYING(20)        AS number,
       (
           CASE
               WHEN empty((k.nimi)::CHARACTER VARYING) THEN (COALESCE(a.nimetus, ''::BPCHAR))::TEXT
               ELSE k.nimi
               END)::CHARACTER VARYING(254)            AS nimi,
       btrim(k.dokument)                               AS dokument,
       to_char(d.created, 'DD.MM.YYYY HH:MM'::TEXT)    AS created,
       to_char(d.lastupdate, 'DD.MM.YYYY HH:MM'::TEXT) AS lastupdate,
       k.tyyp,
       (
           CASE
               WHEN (k.tyyp = 1) THEN k2.summa
               ELSE (0)::NUMERIC
               END)::NUMERIC(14, 2)                    AS deebet,
       (
           CASE
               WHEN (k.tyyp = 2) THEN k2.summa
               ELSE (0)::NUMERIC
               END)::NUMERIC(14, 2)                    AS kreedit,
       s.nimetus                                       AS status,
       COALESCE(jid.number, 0)                         AS lausend,
       aa.konto                                        AS akonto,
       aa.nimetus                                      AS kassa,
       (
           CASE
               WHEN (k.tyyp = 1) THEN (aa.konto)::CHARACTER VARYING
               ELSE k2.konto
               END)::CHARACTER VARYING(20)             AS db,
       (
           CASE
               WHEN (k.tyyp = 1) THEN (k2.konto)::BPCHAR
               ELSE aa.konto
               END)::CHARACTER VARYING(20)             AS kr,
       'EUR'::CHARACTER VARYING(20)                    AS valuuta,
       (1)::NUMERIC(12, 4)                             AS kuurs,
       k.journalid
FROM (((((((docs.doc d
    JOIN docs.korder1 k ON ((d.id = k.parentid)))
    JOIN docs.korder2 k2 ON ((k.id = k2.parentid)))
    JOIN libs.library s ON ((((s.kood)::TEXT = (d.status)::TEXT) AND (s.library = 'STATUS'::BPCHAR))))
    LEFT JOIN ou.aa aa ON (((k.kassaid = aa.id) AND (aa.parentid = k.rekvid))))
    LEFT JOIN libs.asutus a ON ((k.asutusid = a.id)))
    LEFT JOIN docs.journal j ON ((j.parentid = k.journalid)))
         LEFT JOIN docs.journalid jid ON ((jid.journalid = j.id)));

ALTER TABLE cur_korder
    OWNER TO vlad;

