CREATE FUNCTION ask(character varying, integer, integer, date) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
DECLARE tcKontogrupp alias for $1;
	tnasutusid alias for $2;
	tnrekvid alias for $3;
	tdKpv alias for $4;
begin	

	return -1 * asd(tckontogrupp,tnAsutusId, tnrekvid,tdKpv);

end;
$$;

ALTER FUNCTION ask(VARCHAR, INTEGER, INTEGER, DATE) OWNER TO vlad;

