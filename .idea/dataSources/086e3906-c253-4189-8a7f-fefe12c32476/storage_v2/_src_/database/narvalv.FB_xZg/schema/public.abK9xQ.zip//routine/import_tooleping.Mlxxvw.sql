CREATE FUNCTION import_tooleping(in_old_id integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
DECLARE
  leping_id    INTEGER;
  log_id       INTEGER;
  v_leping     RECORD;
  json_object  JSONB;
  hist_object  JSONB;
  v_params     RECORD;
  l_count      INTEGER = 0;
  l_osakond_id INTEGER;
  l_amet_id    INTEGER;
  l_asutus_id  INTEGER;
BEGIN
  -- выборка из "старого меню"

  FOR v_leping IN
  SELECT t.*
  FROM tooleping t
    INNER JOIN rekv ON rekv.id = t.rekvid AND rekv.parentid < 999 and rekvid not in (15)
  WHERE (t.id = in_old_id OR in_old_id IS NULL)
        and t.osakondid in (select id from library where library = 'OSAKOND')
        and t.ametid in (select id from library where library = 'AMET')

  LIMIT ALL
  LOOP

    -- поиск и проверка на ранее сделанный импорт
    SELECT
      new_id,
      id
    INTO leping_id, log_id
    FROM import_log
    WHERE old_id = v_leping.id
          AND upper(ltrim(rtrim(lib_name :: TEXT))) = 'TOOLEPING';

    RAISE NOTICE 'check for lib.. v_lib.id -> %, found -> % log_id -> %', v_leping.id, leping_id, log_id;

    l_osakond_id = (SELECT new_id
                    FROM import_log
                    WHERE old_id = v_leping.osakondid AND lib_name = 'OSAKOND');
    l_amet_id = (SELECT new_id
                 FROM import_log
                 WHERE old_id = v_leping.ametid AND lib_name = 'AMET');

    l_asutus_id = (SELECT new_id
                   FROM import_log
                   WHERE old_id = v_leping.parentid AND lib_name = 'ASUTUS');

    IF l_osakond_id IS NULL OR l_amet_id IS NULL or l_asutus_id is null
    THEN
      RAISE EXCEPTION 'amet or osakond not found v_leping.osakondid %,l_osakond_id %, v_leping.ametid %, l_amet_id %, v_leping.parentid %,  l_asutus_id %', v_leping.osakondid, l_osakond_id, v_leping.ametid, l_amet_id, v_leping.parentid,  l_asutus_id;
    END IF;
    -- преобразование и получение параметров

    -- сохранение
    SELECT
      coalesce(leping_id, 0) AS id,
      l_asutus_id as parentid,
      l_osakond_id as osakondid,
      l_amet_id as ametid,
      v_leping.algab,
      v_leping.lopp,
      v_leping.palk,
      v_leping.palgamaar,
      v_leping.resident,
      v_leping.riik,
      v_leping.toend,
      v_leping.koormus,
      v_leping.toopaev,
      v_leping.ametnik,
      v_leping.tasuliik,
      v_leping.muud          AS muud
    INTO v_params;

    SELECT row_to_json(row)
    INTO json_object
    FROM (SELECT
            coalesce(leping_id, 0) AS id,
            TRUE                   AS import,
            v_params               AS data) row;

    SELECT palk.sp_salvesta_tooleping(json_object :: JSON, 1, v_leping.rekvid)
    INTO leping_id;
    RAISE NOTICE 'leping_id %, l_count %', leping_id, l_count;

    -- salvestame log info
    SELECT row_to_json(row)
    INTO hist_object
    FROM (SELECT now() AS timestamp) row;

    IF log_id IS NULL
    THEN
      INSERT INTO import_log (new_id, old_id, lib_name, params, history)
      VALUES (leping_id, v_leping.id, 'TOOLEPING', json_object :: JSON, hist_object :: JSON)
      RETURNING id
        INTO log_id;

    ELSE
      UPDATE import_log
      SET
        params  = json_object :: JSON,
        history = (history :: JSONB || hist_object :: JSONB) :: JSON
      WHERE id = log_id;
    END IF;

    IF empty(log_id)
    THEN
      RAISE EXCEPTION 'log save failed';
    END IF;
    l_count = l_count + 1;
  END LOOP;


  RETURN l_count;

  EXCEPTION WHEN OTHERS
  THEN
    RAISE NOTICE 'error % %', SQLERRM, SQLSTATE;
    RETURN 0;

END;
$$;

ALTER FUNCTION import_tooleping(INTEGER) OWNER TO vlad;

