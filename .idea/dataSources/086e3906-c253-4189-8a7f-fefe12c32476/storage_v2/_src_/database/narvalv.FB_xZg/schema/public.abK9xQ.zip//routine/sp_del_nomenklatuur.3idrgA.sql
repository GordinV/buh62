CREATE FUNCTION sp_del_nomenklatuur(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 
	tnId alias for $1;
begin


	DELETE FROM nomenklatuur WHERE id = tnId;


	Return 1;


end;


$$;

ALTER FUNCTION sp_del_nomenklatuur(INTEGER, INTEGER) OWNER TO vlad;

