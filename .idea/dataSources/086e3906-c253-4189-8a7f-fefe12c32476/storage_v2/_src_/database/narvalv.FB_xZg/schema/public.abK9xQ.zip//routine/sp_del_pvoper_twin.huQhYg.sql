CREATE FUNCTION sp_del_pvoper_twin(integer, integer, date) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 

	tnParentid alias for $1;

	tnNomid alias for $2; 

	tdKpv alias for $3;

	v_pv_oper record;

begin
	for v_pv_oper in SELECT Pv_oper.id, Pv_oper.kpv, pv_oper.journalid 

		FROM Pv_oper WHERE Pv_oper.nomid = tnNomId   AND Pv_oper.parentid = tnParentId 

		AND MONTH(Pv_oper.kpv) = month(tdKpv)   AND YEAR(Pv_oper.kpv) = year(tdKpv)

	loop

      		perform sp_del_pv_oper(v_pv_oper.id,1);

	END Loop;

	return 1;

end;
$$;

ALTER FUNCTION sp_del_pvoper_twin(INTEGER, INTEGER, DATE) OWNER TO vlad;

