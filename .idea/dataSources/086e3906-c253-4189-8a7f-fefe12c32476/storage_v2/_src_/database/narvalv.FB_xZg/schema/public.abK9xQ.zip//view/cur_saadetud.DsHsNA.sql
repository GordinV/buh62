CREATE VIEW cur_saadetud(id, rekvid, number, asutusid, lubaid, kpv, tahtaeg, summa, tyyp, jaak, nimetus, regkood) AS
SELECT d.id,
       d.rekvid,
       (((ltrim(rtrim((l.number)::TEXT)))::BPCHAR + '-'::BPCHAR) +
        ((ltrim(rtrim(((t.number)::CHARACTER VARYING)::TEXT)))::CHARACTER VARYING)::BPCHAR) AS number,
       t.asutusid,
       t.lubaid,
       t.kpv,
       t.tahtaeg,
       t.summa,
       t.tyyp,
       COALESCE(rekl.fnc_dekl_jaak(d.id), (0)::NUMERIC)                                     AS jaak,
       a.nimetus,
       a.regkood
FROM (((docs.doc d
    JOIN rekl.toiming t ON ((t.parentid = d.id)))
    JOIN rekl.luba l ON ((t.lubaid = l.parentid)))
         JOIN libs.asutus a ON ((a.id = t.asutusid)))
WHERE ((COALESCE((t.staatus)::TEXT, ''::TEXT) <> 'deleted'::TEXT) AND (t.tyyp = 'DEKL'::REKL_TOIMING_LIIK) AND
       (t.saadetud IS NULL));

ALTER TABLE cur_saadetud
    OWNER TO vlad;

