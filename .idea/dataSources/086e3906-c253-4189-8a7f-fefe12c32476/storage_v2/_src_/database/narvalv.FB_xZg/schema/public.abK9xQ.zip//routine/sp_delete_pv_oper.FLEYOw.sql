CREATE FUNCTION sp_delete_pv_oper(userid integer, doc_id integer, OUT error_code integer, OUT result integer, OUT error_message text) RETURNS record
    LANGUAGE plpgsql
AS
$$
DECLARE
  v_doc           RECORD;
  v_dependid_docs RECORD;
  ids             INTEGER [];
  pv_oper_history JSONB;
  arvtasu_history JSONB;
  new_history     JSONB;
  DOC_STATUS      INTEGER = 3; -- документ удален
  v_pv_oper       RECORD;
  v_soetmaks      RECORD;
  a_pv_opers      TEXT [] = enum_range(NULL :: PV_OPERATSIOONID);
  json_props      JSONB;

BEGIN

  SELECT
    d.*,
    u.ametnik AS user_name,
    l.id      AS pv_kaart_id,
    l.status,
    po.liik   AS liik

  INTO v_doc
  FROM docs.doc d
    INNER JOIN docs.pv_oper po ON po.parentid = d.id
    INNER JOIN libs.library l ON l.id = po.pv_kaart_id
    LEFT OUTER JOIN ou.userid u ON u.id = userid
  WHERE d.id = doc_id;

  -- проверка на пользователя и его соответствие учреждению

  IF v_doc IS NULL
  THEN
    error_code = 6;
    error_message = 'Dokument ei leitud, docId: ' || coalesce(doc_id, 0) :: TEXT;
    result = 0;
    RETURN;

  END IF;

  IF NOT exists(SELECT id
                FROM ou.userid u
                WHERE id = userid
                      AND u.rekvid = v_doc.rekvid
  )
  THEN

    error_code = 5;
    error_message = 'Kasutaja ei leitud, rekvId: ' || coalesce(v_doc.rekvid, 0) :: TEXT || ', userId:' ||
                    coalesce(userid, 0) :: TEXT;
    result = 0;
    RETURN;

  END IF;

  -- проверка на права. Предполагает наличие прописанных прав на удаление для данного пользователя в поле rigths


  --	ids =  v_doc.rigths->'delete';
  IF NOT v_doc.rigths -> 'delete' @> jsonb_build_array(userid)
  THEN
    RAISE NOTICE 'У пользователя нет прав на удаление';
    error_code = 4;
    error_message = 'Ei saa kustuta dokument. Puudub õigused';
    result = 0;
    RETURN;

  END IF;

  -- Проверка на наличие связанных документов и их типов (если тип не проводка, то удалять нельзя)

  IF exists(
      SELECT d.id
      FROM docs.doc d
        INNER JOIN libs.library l ON l.id = d.doc_type_id
      WHERE d.id IN (SELECT unnest(v_doc.docs_ids))
            AND l.kood IN ('ARV', 'MK', 'SORDER', 'KORDER'))
  THEN

    error_code = 3; -- Ei saa kustuta dokument. Kustuta enne kõik seotud dokumendid
    error_message = 'Ei saa kustuta dokument. Kustuta enne kõik seotud dokumendid';
    result = 0;
    RETURN;
  END IF;

  IF v_doc.liik = array_position(a_pv_opers, 'paigutus')
  THEN
    error_code = 3; -- Ei saa kustuta dokument. Kustuta enne kõik seotud dokumendid
    error_message = 'Paigutus.Ei saa kustuta dokument';
    result = 0;
    RETURN;

  END IF;

  -- Логгирование удаленного документа
  -- docs.arv

  pv_oper_history = row_to_json(row.*) FROM ( SELECT a.*
  FROM docs.pv_oper a WHERE a.parentid = doc_id) ROW;

  SELECT row_to_json(row)
  INTO new_history
  FROM (SELECT
          now()           AS deleted,
          v_doc.user_name AS user,
          pv_oper_history AS pv_oper) row;

  -- Удаление данных из связанных таблиц (удаляем проводки)

  IF (v_doc.docs_ids IS NOT NULL)
  THEN
    DELETE FROM docs.journal
    WHERE id IN (SELECT unnest(v_doc.docs_ids)); -- @todo процедура удаления
    DELETE FROM docs.journal1
    WHERE parentid IN (SELECT unnest(v_doc.docs_ids)); -- @todo констрейн на удаление
  END IF;

  DELETE FROM docs.pv_oper
  WHERE parentid = v_doc.id; --@todo констрейн на удаление

  -- Установка статуса ("Удален")  и сохранение истории

  UPDATE docs.doc
  SET lastupdate = now(),
    history      = coalesce(history, '[]') :: JSONB || new_history,
    rekvid       = v_doc.rekvid,
    status       = DOC_STATUS
  WHERE id = doc_id;

  RAISE NOTICE 'v_doc.liik %, %, v_doc.pv_kaart_id %', v_doc.liik, array_position(a_pv_opers,
                                                                                  'mahakandmine'), v_doc.pv_kaart_id;

  IF v_doc.status = 2
  THEN
    -- set status to 1 (active)
    UPDATE libs.library
    SET status = 1
    WHERE id = v_doc.pv_kaart_id;

  END IF;

  CASE
    WHEN v_doc.liik = array_position(a_pv_opers, 'mahakandmine')
    THEN
      -- set status to 1 (active)
      UPDATE libs.library
      SET status = 1
      WHERE id = v_doc.pv_kaart_id;

    WHEN v_doc.liik = array_position(a_pv_opers, 'umberhindamine') OR
         v_doc.liik = array_position(a_pv_opers, 'parandus')
    THEN
      -- recalc parhind value
      -- load the card
      SELECT
        sum(po.summa)
          FILTER (WHERE liik = array_position(a_pv_opers, 'paigutus')) AS soetmaks,
        sum(po.summa)
          FILTER (WHERE liik = array_position(a_pv_opers, 'parandus')) AS parandus
      INTO v_pv_oper
      FROM docs.pv_oper po
      WHERE po.pv_kaart_id = v_doc.pv_kaart_id;

      -- change soetmaks in the card
      SELECT (coalesce(v_pv_oper.soetmaks, 0) + coalesce(v_pv_oper.parandus, 0)) :: NUMERIC(12, 2) AS parhind
      INTO v_soetmaks;
      json_props = v_pv_kaart.properties :: JSONB || row_to_json(v_soetmaks) :: JSONB;

      UPDATE libs.library
      SET properties = json_props, status = 1
      WHERE id = v_doc.pv_kaart_id;
  END CASE;

  PERFORM docs.sp_recalc_pv_jaak(v_doc.pv_kaart_id);

  result = 1;
  RETURN;
END;
$$;

ALTER FUNCTION sp_delete_pv_oper(INTEGER, INTEGER, OUT INTEGER, OUT INTEGER, OUT TEXT) OWNER TO vlad;

