CREATE FUNCTION fncviivisearvekpv(integer) RETURNS date
    LANGUAGE plpgsql
AS
$$
declare 
	tnArveId ALIAS FOR $1;
	ldKpv date;
	v_arv record;
	
BEGIN

	select id, rekvid, number, asutusId into v_arv from arv where id = tnArveId;

-- otsime enne valjastatud viivise arved

	select kpv into ldKpv from arv inner join arv1 on arv.id = arv1.parentid 
		where rekvid = v_arv.RekvId 
		and asutusId = v_arv.asutusId 
		and arv1.muud like '%Arve nr.:'+ltrim(rtrim(v_Arv.number))+'%' 
		and arv1.muud like '%viivis%'
		order by arv.kpv desc limit 1; 
									


	return ldKpv;
end;

$$;

ALTER FUNCTION fncviivisearvekpv(INTEGER) OWNER TO vlad;

