CREATE VIEW curtasud(rekvid, arvid, kpv, summa, number, asutusid, regkood, nimetus, tasud, arvsumma) AS
SELECT arv.rekvid,
       arv.id                                AS arvid,
       "isnull"(arvtasu.kpv, arv.kpv)        AS kpv,
       "isnull"(arvtasu.summa, (0)::NUMERIC) AS summa,
       arv.number,
       arv.asutusid,
       asutus.regkood,
       asutus.nimetus,
       arv.tasud,
       arv.summa                             AS arvsumma
FROM ((arv
    LEFT JOIN arvtasu ON ((arvtasu.arvid = arv.id)))
         JOIN asutus ON ((arv.asutusid = asutus.id)));

ALTER TABLE curtasud
    OWNER TO vlad;

