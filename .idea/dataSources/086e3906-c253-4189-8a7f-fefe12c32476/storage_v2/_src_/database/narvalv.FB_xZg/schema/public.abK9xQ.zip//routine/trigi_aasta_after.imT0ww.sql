CREATE FUNCTION trigi_aasta_after() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin
	UPDATE DBASE SET LASTNUM = NEW.ID WHERE id = 81;	 
	return NULL;
end;
$$;

ALTER FUNCTION trigi_aasta_after() OWNER TO vlad;

