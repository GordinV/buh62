CREATE FUNCTION sp_del_taabel_twin(integer, integer, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare

	tnTooleping alias for $1;

	tnKuu alias for $2;

	tnAasta alias for $3;

begin

	DELETE FROM Palk_taabel1 WHERE toolepingId = tnTooleping   AND kuu = tnKuu and aasta = tnAasta;

	if found then

		return 1;

	else

		return 0;

	end if;

end;
$$;

ALTER FUNCTION sp_del_taabel_twin(INTEGER, INTEGER, INTEGER) OWNER TO vlad;

