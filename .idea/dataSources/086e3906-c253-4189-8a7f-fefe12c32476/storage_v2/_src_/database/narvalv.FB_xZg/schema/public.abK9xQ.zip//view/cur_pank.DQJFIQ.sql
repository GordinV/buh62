CREATE VIEW cur_pank(id, rekvid, journalid, kpv, number, selg, opt, deebet, kreedit, regkood, nimetus, kood, aa,
                     journalnr, valuuta, kuurs) AS
SELECT d.id,
       mk.rekvid,
       mk1.journalid,
       mk.kpv,
       mk.number,
       mk.selg,
       mk.opt,
       CASE
           WHEN (mk.opt = 2) THEN mk1.summa
           ELSE (0)::NUMERIC(14, 2)
           END                                                   AS deebet,
       CASE
           WHEN ((mk.opt = 1) OR (COALESCE(mk.opt, 0) = 0)) THEN mk1.summa
           ELSE (0)::NUMERIC(14, 2)
           END                                                   AS kreedit,
       (COALESCE(a.regkood, ''::BPCHAR))::CHARACTER VARYING(20)  AS regkood,
       (COALESCE(a.nimetus, ''::BPCHAR))::CHARACTER VARYING(254) AS nimetus,
       (COALESCE(n.kood, ''::BPCHAR))::CHARACTER VARYING(20)     AS kood,
       (COALESCE(aa.arve, ''::BPCHAR))::CHARACTER VARYING(20)    AS aa,
       COALESCE(jid.number, 0)                                   AS journalnr,
       'EUR'::CHARACTER VARYING                                  AS valuuta,
       (1)::NUMERIC                                              AS kuurs
FROM ((((((docs.doc d
    JOIN docs.mk mk ON ((mk.parentid = d.id)))
    JOIN docs.mk1 mk1 ON ((mk.id = mk1.parentid)))
    LEFT JOIN libs.asutus a ON ((mk1.asutusid = a.id)))
    LEFT JOIN libs.nomenklatuur n ON ((mk1.nomid = n.id)))
    LEFT JOIN ou.aa aa ON ((mk.aaid = aa.id)))
         LEFT JOIN docs.journalid jid ON ((mk1.journalid = jid.journalid)));

ALTER TABLE cur_pank
    OWNER TO vlad;

