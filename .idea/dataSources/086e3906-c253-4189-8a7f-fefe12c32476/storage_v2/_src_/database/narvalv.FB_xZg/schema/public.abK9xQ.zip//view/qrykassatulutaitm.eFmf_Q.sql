CREATE VIEW qrykassatulutaitm(kpv, rekvid, nimetus, tun, summa, kood, eelarve, tegev) AS
SELECT curjournal.kpv,
       curjournal.rekvid,
       rekv.nimetus,
       curjournal.tunnus                     AS tun,
       (curjournal.summa * curjournal.kuurs) AS summa,
       curjournal.kood5                      AS kood,
       space(1)                              AS eelarve,
       curjournal.kood1                      AS tegev
FROM (((curjournal
    JOIN kassatulud ON ((ltrim(rtrim((curjournal.kreedit)::TEXT)) ~~ ltrim(rtrim((kassatulud.kood)::TEXT)))))
    JOIN kassakontod ON ((ltrim(rtrim((curjournal.deebet)::TEXT)) ~~ ltrim(rtrim((kassakontod.kood)::TEXT)))))
         JOIN rekv ON ((curjournal.rekvid = rekv.id)));

ALTER TABLE qrykassatulutaitm
    OWNER TO vlad;

