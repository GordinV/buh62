CREATE VIEW com_ladu(id, kood, nimetus, konto, rekvid) AS
SELECT qry.id,
       qry.kood,
       qry.nimetus,
       qry.konto,
       qry.rekvid
FROM (SELECT 0                         AS id,
             ''::CHARACTER VARYING(20) AS kood,
             ''::CHARACTER VARYING(20) AS nimetus,
             ''::CHARACTER VARYING(20) AS konto,
             NULL::INTEGER             AS rekvid
      UNION
      SELECT l.id,
             l.kood,
             l.nimetus,
             (((l.properties)::JSON ->> 'konto'::TEXT))::CHARACTER VARYING(20) AS konto,
             l.rekvid
      FROM libs.library l
      WHERE ((l.library = 'LADU'::BPCHAR) AND (l.status <> 3))) qry
ORDER BY qry.kood;

ALTER TABLE com_ladu
    OWNER TO vlad;

