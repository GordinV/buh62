CREATE FUNCTION sp_del_lahetuskulud(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 

	tnId alias for $1;

begin
	DELETE FROM avans1 WHERE id = tnid;

	Return 1;

end;

$$;

ALTER FUNCTION sp_del_lahetuskulud(INTEGER, INTEGER) OWNER TO vlad;

