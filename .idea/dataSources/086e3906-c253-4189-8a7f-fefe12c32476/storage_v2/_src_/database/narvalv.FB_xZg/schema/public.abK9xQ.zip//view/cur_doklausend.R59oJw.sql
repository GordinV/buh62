CREATE VIEW cur_doklausend(id, rekvid, dok, selg, deebet, kreedit, summa, tegev, allikas, rahavoog, artikkel, lisa_d,
                           lisa_k, lausend) AS
SELECT d.id,
       d.rekvid,
       d.dok,
       d.selg,
       d1.deebet,
       d1.kreedit,
       d1.summa,
       d1.kood1                                  AS tegev,
       d1.kood2                                  AS allikas,
       d1.kood3                                  AS rahavoog,
       d1.kood5                                  AS artikkel,
       d1.lisa_d,
       d1.lisa_k,
       ((d1.deebet)::TEXT || (d1.kreedit)::TEXT) AS lausend
FROM (docs.doklausheader d
         JOIN docs.doklausend d1 ON ((d.id = d1.parentid)))
WHERE (d.status <> 3);

ALTER TABLE cur_doklausend
    OWNER TO vlad;

