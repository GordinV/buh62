CREATE FUNCTION sp_koosta_hooettemaks(integer, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	tnid alias for $1;
	tnLiik alias for $2;
	lnId int; 
	lnisikId int; 
	v_journal record;
	lnSumma numeric(18,6);
	lcSelg text;
	lcAllikas varchar(20);
begin
lnId = 0;
lcAllikas = '';
if tnLiik = 1 then
-- journal
	raise notice 'journal';
	for v_journal in 
		SELECT journal.id, ifnull(asutus.nimetus,'')::varchar(154) as asutus, journal1.id as journal1Id, journal.rekvid, journal.kpv, journal.dok,
			journal.asutusid, journal.selg, journal1.summa, journalid.number, journal1.kood5
			FROM journal left outer join asutus on journal.asutusid = asutus.id
			JOIN journal1 ON journal.id = journal1.parentid
			JOIN journalid ON journal.id = journalid.journalid
			where journal.id = tnId and journal1.kreedit = '203630'
	loop 
-- kontrollime kas ettemaks juba koostatud
		-- konto like 203630

		select sum(summa) into lnSumma from hooettemaksud where dokid = v_journal.Id and doktyyp = 'LAUSEND';

		if ifnull(lnSumma,0) < (select sum(summa) from Journal1 where parentid =  v_journal.Id and kreedit = '203630')  then
			-- otsime isik
			raise notice 'Otsime isik';
			raise notice 'v_journal.selg %',v_journal.selg;
			lnIsikId = fnc_LeiaIsikuKood(v_journal.selg);
			if lnIsikId = 0 then
				RAISE NOTICE 'Isik ei leidnud';
				return 0;
			end if;
			-- koostame uus ettemaks
			lcSelg = ltrim(rtrim(v_journal.asutus))+',';
			if len(v_journal.dok) > 0 then
				lcSelg = lcSelg + ' Dok.nr.'+ltrim(rtrim(v_journal.dok));
			end if;
			lcSelg=lcSelg + ',' + v_journal.selg;
			lcAllikas = case when v_journal.kood5 = '3888' then 'PENSION15' when v_journal.kood5 = '3224' then 'PENSION85' else '' end;
			insert into hooettemaksud (isikid, kpv, summa, dokid , doktyyp, selg , staatus, muud)
				values (lnIsikId, v_journal.kpv, v_journal.summa, v_journal.id, 'LAUSEND', lcSelg,1,lcAllikas);
			lnId:= cast(CURRVAL('public.hooettemaksud_id_seq') as int4);	

			if lnId > 0 then
				update journal set dokid = lnId where id = tnId;
			end if;		
		end if;
			
	end loop;

end if;
return  lnId;

end;
$$;

ALTER FUNCTION sp_koosta_hooettemaks(INTEGER, INTEGER) OWNER TO vlad;

