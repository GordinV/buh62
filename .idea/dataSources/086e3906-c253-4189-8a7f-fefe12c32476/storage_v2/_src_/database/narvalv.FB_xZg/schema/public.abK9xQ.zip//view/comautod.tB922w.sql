CREATE VIEW comautod(id, regnum, nimetus, omanikid, rekvid) AS
SELECT autod.id,
       autod.regnum,
       asutus.nimetus,
       autod.omanikid,
       asutus.rekvid
FROM (autod
         JOIN asutus ON ((autod.omanikid = asutus.id)));

ALTER TABLE comautod
    OWNER TO vlad;

