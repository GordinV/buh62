CREATE FUNCTION check_muud(integer, integer, integer) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
declare
	tnId alias for $1;
	tnKuu alias for $2;
	tnAasta alias for $3;
	lnStartKpv int;
	lnLoppKpv int;
	lnResult numeric(12,8);
	lnTunnid numeric;
	qryPuhkused record;
	l_str text;
begin

lnresult := 0;

for qryPuhkused in 
	SELECT puudumine.*, toopaev 
		from puudumine 
		inner join tooleping on tooleping.id = puudumine.lepingid
	WHERE lepingid = tnId 
	and ((month(kpv1) = tnKuu and year (kpv1) = tnAasta) 
	or  (month(kpv2) = tnKuu and year (kpv2) = tnAasta))
	AND TUNNUS = 4 and tyyp > 1
loop
	If month (qryPuhkused.kpv1) = tnKuu and year (qryPuhkused.kpv1) = tnAasta then
		lnStartKpv := day (qryPuhkused.kpv1);
	Else
		lnStartKpv := 1;
	End if;
	If month (qryPuhkused.kpv2) = tnKuu and year (qryPuhkused.kpv2) = tnAasta then
		lnLoppKpv := day (qryPuhkused.kpv2);
	Else
		lnLoppKpv := day(gomonth(date(tnAasta, tnKuu,1),1) - 1);
	End if;
	-- arvestame tunnid
	select sum(summa) into lnTunnid from puudumine 
		WHERE lepingid = tnId 
		and ((month(kpv1) = tnKuu and year (kpv1) = tnAasta) 
		or  (month(kpv2) = tnKuu and year (kpv2) = tnAasta))
		AND TUNNUS = 4 and tyyp > 1;
	if lnTunnid > 0 then		
--		lnTunnid = lnTunnid / 10 ^ (position('.' in lnTunnid::text) - 1);
		lnResult = lnResult + (lnTunnid /  qryPuhkused.toopaev);
	else
		-- paevad
		lnresult := lnresult + sp_workdays(lnStartKpv, tnKuu, tnAasta, lnLoppKpv, tnid);
	
	end if;
End loop;

Return lnresult;

end;
$$;

ALTER FUNCTION check_muud(INTEGER, INTEGER, INTEGER) OWNER TO vlad;

