CREATE VIEW cur_tulude_kassa_taitmine(kuu, aasta, rekvid, asutus, parentid, tunnus, summa, artikkel, tegev, allikas,
                                      nimetus, docs_ids) AS
SELECT month(j.kpv)    AS kuu,
       year(j.kpv)     AS aasta,
       j.rekvid,
       rekv.nimetus    AS asutus,
       rekv.parentid,
       j1.tunnus,
       sum(j1.summa)   AS summa,
       j1.kood5        AS artikkel,
       j1.kood1        AS tegev,
       j1.kood2        AS allikas,
       l.nimetus,
       array_agg(d.id) AS docs_ids
FROM ((((((docs.doc d
    JOIN docs.journal j ON ((j.parentid = d.id)))
    JOIN docs.journal1 j1 ON ((j.id = j1.parentid)))
    JOIN ou.rekv rekv ON ((j.rekvid = rekv.id)))
    LEFT JOIN libs.library l ON (((l.kood = (j1.kood5)::BPCHAR) AND (l.library = 'TULUDEALLIKAD'::BPCHAR))))
    JOIN eelarve.kassa_tulud kassatulud ON ((ltrim(rtrim((j1.kreedit)::TEXT)) ~~ ltrim(rtrim(kassatulud.kood)))))
         JOIN eelarve.kassa_kontod kassakontod ON ((ltrim(rtrim((j1.deebet)::TEXT)) ~~ ltrim(rtrim(kassakontod.kood)))))
WHERE (l.tun5 = 1)
GROUP BY (year(j.kpv)), (month(j.kpv)), j.rekvid, rekv.parentid, rekv.nimetus, j1.kreedit, j1.kood1, j1.kood5, j1.kood2,
         j1.tunnus, l.nimetus
ORDER BY (year(j.kpv)), (month(j.kpv)), j.rekvid, rekv.parentid, rekv.nimetus, j1.kreedit, j1.kood1, j1.kood5, j1.kood2,
         j1.tunnus;

ALTER TABLE cur_tulude_kassa_taitmine
    OWNER TO vlad;

