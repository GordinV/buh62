CREATE FUNCTION fnc_valuutakuurs(character varying) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
DECLARE 
	tcValuuta alias for $1;
	lnKuurs numeric(14,4);
	lnPohiKuurs numeric(14,4);
	inId int;
begin
	-- pohi tingimused

	select valuuta1.kuurs into lnPohiKuurs 
		from library inner join valuuta1 on library.id = valuuta1.parentid
		where library.kood = tcValuuta;

	lnKuurs = ifnull(lnPohiKuurs,lnKuurs);
	
	return lnKuurs;
end;
$$;

ALTER FUNCTION fnc_valuutakuurs(VARCHAR) OWNER TO vlad;

