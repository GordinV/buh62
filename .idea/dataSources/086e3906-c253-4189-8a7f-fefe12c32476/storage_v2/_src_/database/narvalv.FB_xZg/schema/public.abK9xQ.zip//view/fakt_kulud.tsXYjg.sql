CREATE VIEW fakt_kulud(kood) AS
SELECT DISTINCT (ltrim(rtrim((l.kood)::TEXT)) || '%'::TEXT) AS kood
FROM libs.library l
WHERE (l.library = 'KULUKONTOD'::BPCHAR)
ORDER BY (ltrim(rtrim((l.kood)::TEXT)) || '%'::TEXT);

ALTER TABLE fakt_kulud
    OWNER TO vlad;

