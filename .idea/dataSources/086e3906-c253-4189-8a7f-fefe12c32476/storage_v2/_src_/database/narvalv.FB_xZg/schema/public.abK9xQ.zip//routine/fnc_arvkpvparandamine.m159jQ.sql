CREATE FUNCTION fnc_arvkpvparandamine(integer) RETURNS date
    LANGUAGE plpgsql
AS
$$
DECLARE tnArvId alias for $1;
	ldKpv date;
	lnJournalId int;
	v_arv record;
begin
	select journalid, kpv into v_arv from arv where id = tnArvId;
	ldKpv = v_arv.kpv;
	if v_arv.journalId > 0 then
		select kpv into ldKpv from journal where id = v_arv.journalid;
		ldKpv = ifnull(ldKpv,v_arv.kpv);
	end if;

        return  ldKpv;

end;

$$;

ALTER FUNCTION fnc_arvkpvparandamine(INTEGER) OWNER TO vlad;

