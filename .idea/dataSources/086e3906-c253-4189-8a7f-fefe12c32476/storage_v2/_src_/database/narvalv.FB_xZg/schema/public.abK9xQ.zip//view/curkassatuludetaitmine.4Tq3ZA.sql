CREATE VIEW curkassatuludetaitmine(kuu, aasta, rekvid, nimetus, asutus, tun, summa, kood, eelarve, tegev, kood2) AS
SELECT month(journal.kpv)                                              AS kuu,
       year(journal.kpv)                                               AS aasta,
       journal.rekvid,
       rekv.nimetus,
       rekv.nimetus                                                    AS asutus,
       journal1.tunnus                                                 AS tun,
       sum((journal1.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))) AS summa,
       journal1.kood5                                                  AS kood,
       space(1)                                                        AS eelarve,
       journal1.kood1                                                  AS tegev,
       journal1.kood2
FROM (((((journal
    JOIN journal1 ON ((journal.id = journal1.parentid)))
    LEFT JOIN dokvaluuta1 ON (((dokvaluuta1.dokid = journal1.id) AND (dokvaluuta1.dokliik = 1))))
    JOIN kassatulud ON ((ltrim(rtrim((journal1.kreedit)::TEXT)) ~~ ltrim(rtrim((kassatulud.kood)::TEXT)))))
    JOIN kassakontod ON ((ltrim(rtrim((journal1.deebet)::TEXT)) ~~ ltrim(rtrim((kassakontod.kood)::TEXT)))))
         JOIN rekv ON ((journal.rekvid = rekv.id)))
GROUP BY (year(journal.kpv)), (month(journal.kpv)), journal.rekvid, rekv.nimetus, journal1.kreedit, journal1.kood1,
         journal1.kood5, journal1.kood2, journal1.tunnus
ORDER BY (year(journal.kpv)), (month(journal.kpv)), journal.rekvid, rekv.nimetus, journal1.kreedit, journal1.kood1,
         journal1.kood5, journal1.kood2, journal1.tunnus;

ALTER TABLE curkassatuludetaitmine
    OWNER TO vlad;

