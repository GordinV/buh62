CREATE FUNCTION sp_salvesta_luba1(integer, integer, integer, numeric, numeric, integer, numeric, numeric, integer, text) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	tnid alias for $1;
	tnParentid alias for $2;
	tnNomid alias for $3;
	tnMaksumaar alias for $4;
	tnKogus alias for $5;
	tnSoodus_tyyp alias for $6;
	tnSoodus alias for $7;
	tnSumma alias for $8;
	tnStaatus alias for $9;
	ttMuud alias for $10;
	lnId int; 
begin

if tnId = 0 then
	-- uus kiri
	insert into luba1 (parentid, nomid, maksumaar, kogus, soodus_tyyp, soodus, summa, staatus, muud) 
		values (tnparentid, tnnomid, tnmaksumaar, tnkogus, tnsoodus_tyyp, tnsoodus, tnsumma, tnstaatus, ttmuud);

	lnId:= cast(CURRVAL('public.luba1_id_seq') as int4);

else
	-- muuda 
	update luba1 set 
		parentid = tnparentid,
		nomid = tnNomid,
                maksumaar = tnMaksumaar, 
                kogus = tnKogus, 
                soodus_tyyp = tnsoodus_tyyp, 
                soodus = tnSoodus, 
                summa = tnSumma, 
		staatus = tnStaatus,
		muud = ttMuud
	where id = tnId;

	lnId := tnId;

end if;

         return  lnId;
end;
$$;

ALTER FUNCTION sp_salvesta_luba1(INTEGER, INTEGER, INTEGER, NUMERIC, NUMERIC, INTEGER, NUMERIC, NUMERIC, INTEGER, TEXT) OWNER TO vlad;

