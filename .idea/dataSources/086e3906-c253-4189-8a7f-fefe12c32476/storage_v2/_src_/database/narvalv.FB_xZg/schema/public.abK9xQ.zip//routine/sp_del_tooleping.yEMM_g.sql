CREATE FUNCTION sp_del_tooleping(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 

	tnId alias for $1;

	tnOpt alias for $2;
	lnCount int;

begin

-- kontrolin kas on palgaoperatsioonid

	if (select count(*) from palk_oper where lepingId = tnId) = 0 then
		-- palgakaart
		delete from palk_kaart where lepingid = tnid;
		-- taabel
		delete from palk_taabel1 where toolepingid = tnid;
		-- toograafik
		delete from toograf where lepingid = tnid;
		-- puudumine
		delete from puudumine where lepingId = tnid;

		-- palk_kaart

		delete from palk_kaart where lepingId = tnid;
		-- leping
		delete from tooleping where id = tnid;

		if found then
			Return 1;
		else
			Return 0;
		end if;

	end if;
	
	return 0;



end;

$$;

ALTER FUNCTION sp_del_tooleping(INTEGER, INTEGER) OWNER TO vlad;

