CREATE FUNCTION sp_palkstat_aruanne21(integer, date, date, integer) RETURNS character varying
    LANGUAGE plpgsql
AS
$$
DECLARE tnrekvid alias for $1;

	tnOsakond alias for $4;

	tdKpv1 alias for $2;
	tdKpv2 alias for $3;
	lcReturn varchar;
	lcString varchar;
	ln1 numeric(14,2);
	ln2 numeric (14,2);
	ln3 numeric(14,2);
	ln4 numeric (14,2);
	ln5 numeric(14,2);
	ln6 numeric (14,2);
	ln7 numeric(14,2);
	ln8 numeric (14,2);
	ln9 numeric(14,2);
	ln10 numeric (14,2);
	ln11 numeric(14,2);
	ln12 numeric (14,2);
	ln13 numeric(14,2);
	ln14 numeric (14,2);
	ln15 numeric(14,2);
	ln16 numeric (14,2);
	ln17 numeric(14,2);
	ln18 numeric (14,2);
	ln19 numeric(14,2);
	ln20 numeric (14,2);
	ln21 numeric(14,2);
	ln22 numeric (14,2);
	ln23 numeric(14,2);
	ln2_ numeric(14,2);
	ln3_ numeric (14,2);
	LNcOUNT int;
	ldKpv1 date;
	ldKpv2 date;
	lnOsakond1 int;
	lnOsakond2 int;
begin

	raise notice ' start  ';

	if tnOsakond > 0 then
		lnOsakond1 := tnOsakond;
		lnOsakond2 := tnOsakond;
	else
		lnOsakond1 := 0;
		lnOsakond2 := 999999999;
	end if;

	select count(*) into lnCount from pg_stat_all_tables where UPPER(relname) = 'TMP_PALKSTAT2';

	raise notice ' count  ';


	if ifnull(lnCount,0) < 1 then

		raise notice ' lisamine  ';

		create table tmp_palkstat2 (nimetus varchar(254) default space(1), rea varchar(20) default space(1), 
			tbl varchar (254) default space(1),
			col1 numeric(14,2) default 0, col2 numeric(14,2) default 0, col3 numeric(14,2) default 0,
			col4 numeric(14,2) default 0, col5 numeric(14,2) default 0, col6 numeric(14,2) default 0,
			col7 numeric(14,2) default 0, col8 numeric(14,2) default 0, col9 numeric(14,2) default 0,
			col10 numeric(14,2) default 0, col11 numeric(14,2) default 0, col12 numeric(14,2) default 0,
			col13 numeric(14,2) default 0, col14 numeric(14,2) default 0, col15 numeric(14,2) default 0,
			col16 numeric(14,2) default 0, col17 numeric(14,2) default 0, col18 numeric(14,2) default 0,
			col19 numeric(14,2) default 0, col20 numeric(14,2) default 0, col21 numeric(14,2) default 0,
			col22 numeric(14,2) default 0, col23 numeric(14,2) default 0, col24 numeric(14,2) default 0,
			col25 numeric(14,2) default 0, col26 numeric(14,2) default 0, col27 numeric(14,2) default 0,
			timestamp varchar(20), kpv date default date(), rekvid int, ametikood int)  ;
	
		CREATE INDEX timestamp_tmp_palkstat2 ON tmp_palkstat2  USING btree (timestamp);
		CREATE INDEX vana_tmp_palkstat2 ON tmp_palkstat2  USING btree (rekvid, kpv);


		GRANT ALL ON TABLE tmp_palkstat2 TO GROUP public;

--	else
--		delete from tmp_palkstat2 where kpv < date() and rekvid = tnrekvId;

	end if;

	lcreturn := to_char(now(), 'YYYYMMDDMISS');

	raise notice ' rea 1 tbl 1  ';

	
	select count(*) into ln1 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 15 and sp_vanus(asutus.regkood,date())  <= 19
		and left(asutus.regkood,1) in ('3','5')
		and id in (
		select distinct tooleping.parentid from tooleping inner join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId 
			where tooleping.rekvId = tnRekvid 
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and (algab <= tdKpv1 and (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 1)
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and (tooleping.toopaev * sp_workdays(1, month(tdKpv2), year(tdKpv2), 31, tooleping.id)) <=  palk_taabel1.kokku ;


	select count(*) into ln2 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 15 and sp_vanus(asutus.regkood,date())  <= 19
		and left(asutus.regkood,1) in ('3','5')
		and id in (
		select distinct parentid from tooleping inner join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId 
			where tooleping.rekvId = tnRekvid 
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and (algab <= tdKpv1 and (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 0)
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and (tooleping.toopaev * sp_workdays(1, month(tdKpv2), year(tdKpv2), 31, tooleping.id)) <=  palk_taabel1.kokku ;			

	select count(*) into ln3 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 15 and sp_vanus(asutus.regkood,date())  <= 19
		and left(asutus.regkood,1) in ('4','6')
		and id in (
		select distinct parentid from tooleping inner join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId 
			where rekvId = tnRekvid 
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and (tooleping.toopaev * sp_workdays(1, month(tdKpv2), year(tdKpv2), 31, tooleping.id)) <=  palk_taabel1.kokku 			
			and (algab <= tdKpv1 and (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 1 and rekvid = tnrekvid);


	select count(*) into ln4 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 15 and sp_vanus(asutus.regkood,date())  <= 19
		and left(asutus.regkood,1) in ('4','6')
		and id in (
		select distinct parentid from tooleping inner join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId 
			where rekvId = tnRekvid 
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and (tooleping.toopaev * sp_workdays(1, month(tdKpv2), year(tdKpv2), 31, tooleping.id)) <=  palk_taabel1.kokku 			
			and (algab <= tdKpv1 and (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 0 and rekvid = tnrekvid);




	insert into tmp_palkstat2 (tbl, nimetus, rea, timestamp,rekvid,col1, col2, col3, col4)
		values ('1. Tootajate arv soo ja vanusruhmade jargi 2003.aasta oktoobri lopul.',
		'15-19','01',
		lcreturn, tnRekvid, ifnull(ln1,0), ifnull(ln2,0), ifnull(ln3,0),ifnull(ln4,0));




	raise notice ' rea 2 tbl 1  ';
	
	
	select count(*) into ln1 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 20 and sp_vanus(asutus.regkood,date())  <= 24
		and left(asutus.regkood,1) in ('3','5')
		and id in (
		select distinct parentid from tooleping join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId 
			where rekvId = tnRekvid 
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and (tooleping.toopaev * sp_workdays(1, month(tdKpv2), year(tdKpv2), 31, tooleping.id)) <=  palk_taabel1.kokku 			
			and (algab <= tdKpv1 or (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 1 and rekvid = tnrekvid);


	select count(*) into ln2 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 20 and sp_vanus(asutus.regkood,date())  <= 24
		and left(asutus.regkood,1) in ('3','5')
		and id in (
		select distinct parentid from tooleping join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId
		where rekvId = tnRekvid 
			and palk_taabel1.kuu = month(tdKpv2)
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and palk_taabel1.aasta = year(tdKpv2)
			and (tooleping.toopaev * sp_workdays(1, month(tdKpv2), year(tdKpv2), 31, tooleping.id)) <=  palk_taabel1.kokku 
			and (algab <= tdKpv1 or (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 0 and rekvid = tnrekvid);

	select count(*) into ln3 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 20 and sp_vanus(asutus.regkood,date())  <= 24
		and left(asutus.regkood,1) in ('4','6')
		and id in (
		select distinct parentid from tooleping join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId 
			where rekvId = tnRekvid 
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and (tooleping.toopaev * sp_workdays(1, month(tdKpv2), year(tdKpv2), 31, tooleping.id)) <=  palk_taabel1.kokku 			
			and (algab <= tdKpv1 or (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 1 and rekvid = tnrekvid);


	select count(*) into ln4 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 20 and sp_vanus(asutus.regkood,date())  <= 24
		and left(asutus.regkood,1) in ('4','6')
		and id in (
		select distinct parentid from tooleping join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId
			 where rekvId = tnRekvid 
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and (tooleping.toopaev * sp_workdays(1, month(tdKpv2), year(tdKpv2), 31, tooleping.id)) <=  palk_taabel1.kokku			
			and (algab <= tdKpv1 or (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 0 and rekvid = tnrekvid);


	insert into tmp_palkstat2 (tbl, nimetus, rea, timestamp,rekvid,col1, col2, col3, col4)
		values ('1. Tootajate arv soo ja vanusruhmade jargi 2003.aasta oktoobri lopul.',
		'20-24','02',
		lcreturn, tnRekvid, ifnull(ln1,0), ifnull(ln2,0), ifnull(ln3,0),ifnull(ln4,0));



	raise notice ' rea 3 tbl 1  ';
	
	
	select count(*) into ln1 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 25 and sp_vanus(asutus.regkood,date())  <= 54
		and left(asutus.regkood,1) in ('3','5')
		and id in (
		select distinct parentid from tooleping join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId
			where rekvId = tnRekvid 
			and palk_taabel1.kuu = month(tdKpv2)
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and palk_taabel1.aasta = year(tdKpv2)
			and (tooleping.toopaev * sp_workdays(1, month(tdKpv2), year(tdKpv2), 31, tooleping.id)) <=  palk_taabel1.kokku
			and (algab <= tdKpv1 or (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 1 and rekvid = tnrekvid);


	select count(*) into ln2 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 25 and sp_vanus(asutus.regkood,date())  <= 54
		and left(asutus.regkood,1) in ('3','5')
		and id in (
		select distinct parentid from tooleping join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId
			where rekvId = tnRekvid 
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and (tooleping.toopaev * sp_workdays(1, month(tdKpv2), year(tdKpv2), 31, tooleping.id)) <=  palk_taabel1.kokku			
			and (algab <= tdKpv1 or (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 0 and rekvid = tnrekvid);

	select count(*) into ln3 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 25 and sp_vanus(asutus.regkood,date())  <= 54
		and left(asutus.regkood,1) in ('4','6')
		and id in (
		select distinct parentid from tooleping join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId
			where rekvId = tnRekvid 
			and palk_taabel1.kuu = month(tdKpv2)
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and palk_taabel1.aasta = year(tdKpv2)
			and (tooleping.toopaev * sp_workdays(1, month(tdKpv2), year(tdKpv2), 31, tooleping.id)) <=  palk_taabel1.kokku
			and (algab <= tdKpv1 or (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 1 and rekvid = tnrekvid);


	select count(*) into ln4 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 25 and sp_vanus(asutus.regkood,date())  <= 54
		and left(asutus.regkood,1) in ('4','6')
		and id in (
		select distinct parentid from tooleping join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId
			where rekvId = tnRekvid 
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and (tooleping.toopaev * sp_workdays(1, month(tdKpv2), year(tdKpv2), 31, tooleping.id)) <=  palk_taabel1.kokku
			and (algab <= tdKpv1 or (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 0 and rekvid = tnrekvid);


	insert into tmp_palkstat2 (tbl, nimetus, rea, timestamp,rekvid,col1, col2, col3, col4)
		values ('1. Tootajate arv soo ja vanusruhmade jargi 2003.aasta oktoobri lopul.',
		'25-54','03',
		lcreturn, tnRekvid, ifnull(ln1,0), ifnull(ln2,0), ifnull(ln3,0),ifnull(ln4,0));




	raise notice ' rea 4 tbl 1  ';
	
	
	select count(*) into ln1 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 54 and sp_vanus(asutus.regkood,date())  <= 59
		and left(asutus.regkood,1) in ('3','5')
		and id in (
		select distinct parentid from tooleping join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId
			where rekvId = tnRekvid 
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and (tooleping.toopaev * sp_workdays(1, month(tdKpv2), year(tdKpv2), 31, tooleping.id)) <=  palk_taabel1.kokku
			and (algab <= tdKpv1 or (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 1 and rekvid = tnrekvid);


	select count(*) into ln2 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 54 and sp_vanus(asutus.regkood,date())  <= 59
		and left(asutus.regkood,1) in ('3','5')
		and id in (
		select distinct parentid from tooleping where rekvId = tnRekvid 
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and (algab <= tdKpv1 or (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 0 and rekvid = tnrekvid);

	select count(*) into ln3 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 54 and sp_vanus(asutus.regkood,date())  <= 59
		and left(asutus.regkood,1) in ('4','6')
		and id in (
		select distinct parentid from tooleping join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId
			where rekvId = tnRekvid 
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and (tooleping.toopaev * sp_workdays(1, month(tdKpv2), year(tdKpv2), 31, tooleping.id)) <=  palk_taabel1.kokku
			and (algab <= tdKpv1 or (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 1 and rekvid = tnrekvid);


	select count(*) into ln4 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 54 and sp_vanus(asutus.regkood,date())  <= 59
		and left(asutus.regkood,1) in ('4','6')
		and id in (
		select distinct parentid from tooleping join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId 
			where rekvId = tnRekvid
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and (tooleping.toopaev * sp_workdays(1, month(tdKpv2), year(tdKpv2), 31, tooleping.id)) <=  palk_taabel1.kokku 
			and (algab <= tdKpv1 or (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 0 and rekvid = tnrekvid);

	insert into tmp_palkstat2 (tbl, nimetus, rea, timestamp,rekvid,col1, col2, col3, col4)
		values ('1. Tootajate arv soo ja vanusruhmade jargi 2003.aasta oktoobri lopul.',
		'54-59','04',
		lcreturn, tnRekvid, ifnull(ln1,0), ifnull(ln2,0), ifnull(ln3,0),ifnull(ln4,0));


	raise notice ' rea 5 tbl 1  ';
	
	
	select count(*) into ln1 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 60
		and left(asutus.regkood,1) in ('3','5')
		and id in (
		select distinct parentid from tooleping join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId
			where rekvId = tnRekvid 
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and (tooleping.toopaev * sp_workdays(1, month(tdKpv2), year(tdKpv2), 31, tooleping.id)) <=  palk_taabel1.kokku
			and (algab <= tdKpv1 or (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 1 and rekvid = tnrekvid);


	select count(*) into ln2 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 60 
		and left(asutus.regkood,1) in ('3','5')
		and id in (
		select distinct parentid from tooleping join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId
			where rekvId = tnRekvid 
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and (tooleping.toopaev * sp_workdays(1, month(tdKpv2), year(tdKpv2), 31, tooleping.id)) <=  palk_taabel1.kokku
			and (algab <= tdKpv1 or (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 0 and rekvid = tnrekvid);

	select count(*) into ln3 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 60 
		and left(asutus.regkood,1) in ('4','6')
		and id in (
		select distinct parentid from tooleping 
			where rekvId = tnRekvid 
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and (algab <= tdKpv1 or (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 1 and rekvid = tnrekvid);


	select count(*) into ln4 from asutus 
		where sp_vanus(asutus.regkood,date())  >= 60 
		and left(asutus.regkood,1) in ('4','6')
		and id in (
		select distinct parentid from tooleping join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId
			where rekvId = tnRekvid 
			and osakondId >= lnOsakond1 and osakondId <= lnOsakond2
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and (tooleping.toopaev * sp_workdays(1, month(tdKpv2), year(tdKpv2), 31, tooleping.id)) <=  palk_taabel1.kokku
			and (algab <= tdKpv1 or (empty(lopp) or lopp >= tdKpv2)) and pohikoht = 0 and rekvid = tnrekvid);

	insert into tmp_palkstat2 (tbl, nimetus, rea, timestamp,rekvid,col1, col2, col3, col4)
		values ('1. Tootajate arv soo ja vanusruhmade jargi 2003.aasta oktoobri lopul.',
		'60 ja enam','05',
		lcreturn, tnRekvid, ifnull(ln1,0), ifnull(ln2,0), ifnull(ln3,0),ifnull(ln4,0));

	raise notice ' rea 6 tbl 1  ';

	insert into tmp_palkstat2 (tbl, nimetus, rea, timestamp,rekvid,col1, col2, col3, col4)
		select '1. Tootajate arv soo ja vanusruhmade jargi 2003.aasta oktoobri lopul.',
		'KOKKU','06',
		lcreturn, tnRekvid, sum(col1), sum(col2), sum(col3), sum(col4) from tmp_palkstat2 where timestamp = lcReturn and rea <> '06' and rekvid = tnrekvid;




	return LCRETURN;

end;

$$;

ALTER FUNCTION sp_palkstat_aruanne21(INTEGER, DATE, DATE, INTEGER) OWNER TO vlad;

