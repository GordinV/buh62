CREATE FUNCTION fncreklettemaksjaak(integer) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
declare
	tnAsutusId alias for $1;
	lnSumma numeric(18,6);
	
begin
lnSumma = 0;

select sum(summa) into lnSumma from ettemaksud where asutusId = tnAsutusId ;
lnSumma = ifnull(lnSumma,0);

return lnSumma;
end;


$$;

ALTER FUNCTION fncreklettemaksjaak(INTEGER) OWNER TO vlad;

