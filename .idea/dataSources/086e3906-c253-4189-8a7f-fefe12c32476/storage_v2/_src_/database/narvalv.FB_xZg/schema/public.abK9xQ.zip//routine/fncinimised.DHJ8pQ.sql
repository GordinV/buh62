CREATE FUNCTION fncinimised(integer, integer) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
DECLARE tnObjektId alias for $1;
	tnUhis alias for $2;


	lnKogus numeric;
	lnParentObjektId integer;

begin	

	lnKogus = 0;

	if tnUhis = 0 then
		select nait02 into lnKogus
			from objekt where libid = tnObjektId;
	else

		--otsime parent objekt
			
		select objekt.parentid into lnParentObjektId from objekt where libid = tnObjektId;
		lnParentObjektId = ifnull(lnParentObjektId,0);

--		raise notice 'Parent %',lnParentObjektId;
		
		select sum(nait02) into lnKogus
			from objekt
			where objekt.libid = lnParentObjektId;

	end if;

	lnKogus = ifnull(lnKogus,0);



	return lnKogus;

end;

$$;

ALTER FUNCTION fncinimised(INTEGER, INTEGER) OWNER TO vlad;

