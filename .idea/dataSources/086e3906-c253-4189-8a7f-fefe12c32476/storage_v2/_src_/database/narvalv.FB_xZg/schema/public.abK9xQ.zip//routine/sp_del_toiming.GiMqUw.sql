CREATE FUNCTION sp_del_toiming(integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 


	tnId alias for $1;
	v_toiming record;

begin
	select * into v_toiming from toiming where id = tnId;
	
	Delete From toiming Where Id = tnid;
	-- kustutame viivise info
	delete from viiviseinfo where intressId = tnId;
	-- kustutame dekl info
--	delete from viiviseinfo where dokId = tnId and dokliik = 1;
	-- lausend
	perform sp_del_journal(v_toiming.journalid, 1);

	Return 1;


end;

$$;

ALTER FUNCTION sp_del_toiming(INTEGER) OWNER TO vlad;

