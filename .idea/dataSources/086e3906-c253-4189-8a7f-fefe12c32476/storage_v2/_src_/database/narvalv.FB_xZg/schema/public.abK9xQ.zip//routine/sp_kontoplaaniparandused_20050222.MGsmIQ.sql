CREATE FUNCTION sp_kontoplaaniparandused_20050222(character varying, character varying, character varying, text) RETURNS character varying
    LANGUAGE plpgsql
AS
$$
declare
	tcKood ALIAS for $1;
	tcRegkood ALIAS for $2;
	tcNimetus ALIAS for $3;
	ttMuud ALIAS for $4;
	lrLibr record;
	lrAsutus record;
	lcRet varchar;
	lcId int;	
begin
--Library
	SELECT  * into lrLibr FROM library 
		WHERE (ltrim(rtrim(upper(Nimetus)))=ltrim(rtrim(upper(tcNimetus))) 
		or ltrim(rtrim(upper(Kood))) = ltrim(rtrim(upper(tcKood))))
		and library = 'TP';
	
	IF found then
		raise notice 'found';
		IF ltrim(rtrim(upper(lrLibr.Kood))) <> ltrim(rtrim(upper(tcKood))) then
			raise notice 'updateKood';
			UPDATE library SET Kood = tcKood WHERE Id=LrLibr.id;
			lcRet:='UPD library:' + lrLibr.id::varchar;
		End if;
	else
		raise notice 'insert';
		INSERT INTO library (rekvid,kood,nimetus,library,muud) VALUES (1,tcKood,tcNimetus,'TP',ttMuud);
		SELECT id INTO LcId FROM library WHERE kood=TcKood;
		lcRet:='INS library:' + lcId::varchar;
	end if;
	
--ASUTUS
	SELECT * into lrAsutus FROM asutus
		WHERE Regkood = tcRegkood;
	if found then
		raise notice 'Asustus found';
		IF lrAsutus.tp <> tcKood then
			raise notice 'Asustus update';
			UPDATE asutus SET tp=tcKood WHERE Id=LrAsutus.id;
--			lcRet:=lcRet + 'UPD library:' + LrAsustus.id::varchar;
		end if;
	end if;
	return lcRet;
end;
$$;

ALTER FUNCTION sp_kontoplaaniparandused_20050222(VARCHAR, VARCHAR, VARCHAR, TEXT) OWNER TO vlad;

