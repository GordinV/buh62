CREATE VIEW cur_ettemaksud(id, rekvid, asutusid, number, summa, kpv, dokid, doktyyp, dokument, selg, asutus, regkood,
                           staatus) AS
SELECT e.id,
       e.rekvid,
       e.asutusid,
       e.number,
       e.summa,
       e.kpv,
       e.dokid,
       e.doktyyp,
       (
           CASE
               WHEN (e.doktyyp = 'DEEBET'::REKL_ETTEMAKS_LIIK) THEN 'LAUSEND'::TEXT
               ELSE 'TASU'::TEXT
               END)::CHARACTER VARYING(40) AS dokument,
       (e.selg)::CHARACTER VARYING(254)    AS selg,
       a.nimetus                           AS asutus,
       a.regkood,
       e.staatus
FROM (rekl.ettemaksud e
         JOIN libs.asutus a ON ((e.asutusid = a.id)))
WHERE (e.staatus <> 'deleted'::DOK_STATUS);

ALTER TABLE cur_ettemaksud
    OWNER TO vlad;

