CREATE FUNCTION sp_salvesta_asutus(integer, integer, character, character, character, text, text, character, character, character, text, character varying) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare

	tnid alias for $1;

	tnrekvid alias for $2;

	tcregkood alias for $3;

	tcnimetus alias for $4;

	tcomvorm alias for $5;

	ttaadress alias for $6;

	ttkontakt alias for $7;

	tctel alias for $8;

	tcfaks alias for $9;

	tcemail alias for $10;

	ttmuud alias for $11;

	tctp alias for $12;

	lnasutusId int;

	lnId int; 

	lrCurRec record;

begin



if tnId = 0 then

	-- uus kiri

	insert into asutus (rekvid,regkood,nimetus,omvorm,aadress,kontakt,tel,faks,email,muud,tp) 

		values (tnrekvid,tcregkood,tcnimetus,tcomvorm,ttaadress,ttkontakt,tctel,tcfaks,tcemail,ttmuud,tctp);



	lnasutusId:= cast(CURRVAL('public.asutus_id_seq') as int4);



else

	-- muuda 

	select * into lrCurRec from asutus where id = tnId;

	if lrCurRec.rekvid <> tnrekvid or lrCurRec.regkood <> tcregkood or lrCurRec.nimetus <> tcnimetus or lrCurRec.omvorm <> tcomvorm or lrCurRec.aadress <> ttaadress or lrCurRec.kontakt <> ttkontakt or lrCurRec.tel <> tctel or lrCurRec.faks <> tcfaks or lrCurRec.email <> tcemail or ifnull(lrCurRec.muud,space(1)) <> ifnull(ttmuud,space(1)) or lrCurRec.tp <> tctp then 

	update asutus set 

		rekvid = tnrekvid,

		regkood = tcregkood,

		nimetus = tcnimetus,

		omvorm = tcomvorm,

		aadress = ttaadress,

		kontakt = ttkontakt,

		tel = tctel,

		faks = tcfaks,

		email = tcemail,

		muud = ttmuud,

		tp = tctp

	where id = tnId;

	end if;

	lnasutusId := tnId;

end if;



         return  lnasutusId;

end;
$$;

ALTER FUNCTION sp_salvesta_asutus(INTEGER, INTEGER, CHAR, CHAR, CHAR, TEXT, TEXT, CHAR, CHAR, CHAR, TEXT, VARCHAR) OWNER TO vlad;

