CREATE FUNCTION "isnull"(date, date) RETURNS date
    LANGUAGE plpgsql
AS
$$
begin
	if $1 is null then
		 return  $2;
	end if;
end;
$$;

ALTER FUNCTION "isnull"(DATE, DATE) OWNER TO vlad;

