CREATE FUNCTION str(numeric, integer) RETURNS character
    LANGUAGE plpgsql
AS
$$
begin
         return  left(ltrim(rtrim(cast($1 as bpchar))),$2);
end;
$$;

ALTER FUNCTION str(NUMERIC, INTEGER) OWNER TO vlad;

