CREATE FUNCTION sp_get_number(integer, character varying, integer, integer) RETURNS character varying
    LANGUAGE plpgsql
AS
$$
DECLARE tnrekvid alias for $1;
	tcDok alias for $2;
	tnYear alias for $3;
	tnDokPropId alias for $4;
	lcNumber varchar(20);
	lcPref varchar(120);
begin
	select ltrim(rtrim(proc_)) into lcPref from dokprop where id = tnDokPropId;

	lcPref = ifnull(lcPref,'')+'%';
	raise notice 'lcPref %',lcPref;


	if lcPref = '%' then 
		raise notice 'Pref puudub..';
		lcNumber = sp_get_number(tnRekvId, tcDok);
		return lcNumber;
	end if;

	
	lcNumber := space(1);

	if tcDok = 'ARV' then
		select number into lcNumber from arv where rekvid = tnRekvId and liik = 0 and year(kpv) = tnYear and number like lcPref order by id desc limit 1;
	end if;
	if tcDok = 'SORDER' then
		select number into lcNumber from korder1 where rekvid = tnRekvId and tyyp = 1 and year(kpv) = tnYear and number like lcPref order by id desc limit 1;
	end if;
	if tcDok = 'VORDER' then
		select number into lcNumber from korder1 where rekvid = tnRekvId and tyyp = 2 and year(kpv) = tnYear and number like lcPref order by id desc limit 1;
	end if;
	if tcDok = 'MK' then
		select number into lcNumber from mk where rekvid = tnRekvId and OPT = 1 and year(kpv) = tnYear and number like lcPref order by id desc limit 1;
	end if;
	if tcDok = 'AVANS' then
		select number into lcNumber from avans1 where rekvid = tnRekvId  and year(kpv) = tnYear and number like lcPref order by id desc limit 1;
	end if;
        return lcNumber ;
end;
$$;

ALTER FUNCTION sp_get_number(INTEGER, VARCHAR, INTEGER, INTEGER) OWNER TO vlad;

