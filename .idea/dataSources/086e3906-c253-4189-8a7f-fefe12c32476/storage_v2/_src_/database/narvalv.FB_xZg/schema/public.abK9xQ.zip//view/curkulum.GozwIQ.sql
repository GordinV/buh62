CREATE VIEW curkulum(id, liik, summa, kpv, rekvid, grupp, kood, opernimi, soetmaks, soetkpv, kulum, algkulum, gruppid,
                     konto, tunnus, vastisik, ivnum, invnum, pohivara) AS
SELECT library.id,
       pv_oper.liik,
       ((pv_oper.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC)))::NUMERIC(12, 4) AS summa,
       pv_oper.kpv,
       library.rekvid,
       grupp.nimetus                                                               AS grupp,
       nomenklatuur.kood,
       nomenklatuur.nimetus                                                        AS opernimi,
       pv_kaart.soetmaks,
       pv_kaart.soetkpv,
       pv_kaart.kulum,
       pv_kaart.algkulum,
       pv_kaart.gruppid,
       pv_kaart.konto,
       pv_kaart.tunnus,
       ifnull(asutus.nimetus, space(254))                                          AS vastisik,
       library.kood                                                                AS ivnum,
       library.kood                                                                AS invnum,
       library.nimetus                                                             AS pohivara
FROM ((((((library
    JOIN pv_oper ON ((library.id = pv_oper.parentid)))
    JOIN pv_kaart ON ((library.id = pv_kaart.parentid)))
    JOIN library grupp ON ((pv_kaart.gruppid = grupp.id)))
    LEFT JOIN asutus ON ((pv_kaart.vastisikid = asutus.id)))
    LEFT JOIN dokvaluuta1 ON (((pv_oper.id = dokvaluuta1.dokid) AND (dokvaluuta1.dokliik = 13))))
         JOIN nomenklatuur ON ((pv_oper.nomid = nomenklatuur.id)));

ALTER TABLE curkulum
    OWNER TO vlad;

