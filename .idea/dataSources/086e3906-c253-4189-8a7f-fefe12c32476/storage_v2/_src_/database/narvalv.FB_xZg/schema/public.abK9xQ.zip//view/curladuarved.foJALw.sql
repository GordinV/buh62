CREATE VIEW curladuarved(id, kogus, hind, rekvid, number, kpv, summa, journalid, operatsioon, liik, kood, nomid,
                         nimetus, asutus, grupp) AS
SELECT arv.id,
       arv1.kogus,
       arv1.hind,
       arv.rekvid,
       arv.number,
       arv.kpv,
       arv1.summa,
       arv.journalid,
       ladu_oper.nimetus AS operatsioon,
       ladu_oper.liik,
       nomenklatuur.kood,
       nomenklatuur.id   AS nomid,
       nomenklatuur.nimetus,
       asutus.nimetus    AS asutus,
       grupp.nimetus     AS grupp
FROM ((((((arv
    JOIN arv1 ON ((arv.id = arv1.parentid)))
    JOIN ladu_oper ON ((arv.operid = ladu_oper.id)))
    JOIN nomenklatuur ON ((arv1.nomid = nomenklatuur.id)))
    JOIN asutus ON ((arv.asutusid = asutus.id)))
    JOIN ladu_grupp ON ((ladu_grupp.nomid = nomenklatuur.id)))
         JOIN library grupp ON ((grupp.id = ladu_grupp.parentid)));

ALTER TABLE curladuarved
    OWNER TO vlad;

