CREATE FUNCTION fncmotteviimanenait(integer) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
DECLARE tnParentId alias for $1;


	lnKogus numeric;
	lnParentObjektId integer;

begin	

	lnKogus = 0;

	select loppkogus into lnKogus from counter where parentid = tnParentId order by kpv desc limit 1;

	lnKogus = ifnull(lnKogus,0);


	return lnKogus;

end;

$$;

ALTER FUNCTION fncmotteviimanenait(INTEGER) OWNER TO vlad;

