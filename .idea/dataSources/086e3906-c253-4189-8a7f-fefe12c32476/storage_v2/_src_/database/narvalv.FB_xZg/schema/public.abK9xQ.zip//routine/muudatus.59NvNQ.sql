CREATE FUNCTION muudatus() RETURNS integer
    LANGUAGE plpgsql
AS
$$
begin

	if (select count(*) from pg_stat_all_tables where UPPER(relname) = 'UUENDUS') < 1 then

		raise notice ' lisamine tbl Uuendus ';
	
		create table uuendus ( id serial NOT NULL, aeg timestamp NOT NULL DEFAULT now(), userId int not null , 

			versia int not null default 0, sql varchar(254) not null default space(1), selg text not null default space(1), tulemus int not null default 0)  ;
		
		GRANT ALL ON TABLE uuendus TO GROUP public;

	end if;


	-- tbl struktuuri parandused

	-- palk_taabel1 





DROP VIEW public.curtaabel1;

alter table palk_taabel1 ADD TMP_kokku   numeric(12,4) ;

alter table palk_taabel1 ADD TMP_TOO   numeric(12,4)  ;

alter table palk_taabel1 ADD TMP_paev   numeric(12,4) ;

alter table palk_taabel1 ADD TMP_ohtu   numeric(12,4) ;

alter table palk_taabel1 ADD TMP_oo   numeric(12,4)  ;

alter table palk_taabel1 ADD TMP_tahtpaev   numeric(12,4)  ;

alter table palk_taabel1 ADD TMP_puhapaev   numeric(12,4)  ;

alter table palk_taabel1 ADD TMP_uleajatoo   numeric(12,4)  ;



update palk_taabel1 set TMP_kokku = kokku,

	TMP_TOO = too,

	TMP_paev = paev,

	TMP_ohtu = ohtu,

	TMP_oo = oo,

	TMP_tahtpaev = tahtpaev,

	TMP_puhapaev = puhapaev,

	TMP_uleajatoo = uleajatoo ;



alter table palk_taabel1 alter column TMP_kokku   set default 0 ;

alter table palk_taabel1 alter column  TMP_TOO   set default 0 ;

alter table palk_taabel1 alter column  TMP_paev   set default 0 ;

alter table palk_taabel1 alter column  TMP_ohtu   set default 0 ;

alter table palk_taabel1 alter column  TMP_oo   set default 0 ;

alter table palk_taabel1 alter column  TMP_tahtpaev  set default 0 ;

alter table palk_taabel1 alter column  TMP_puhapaev  set default 0 ;

alter table palk_taabel1 alter column  TMP_uleajatoo   set default 0 ;







ALTER TABLE  palk_taabel1 DROP COLUMN  kokku;

ALTER TABLE  palk_taabel1 DROP COLUMN  too;

ALTER TABLE  palk_taabel1 DROP COLUMN paev ;

ALTER TABLE  palk_taabel1 DROP COLUMN ohtu;

ALTER TABLE  palk_taabel1 DROP COLUMN oo;

ALTER TABLE  palk_taabel1 DROP COLUMN tahtpaev;

ALTER TABLE  palk_taabel1 DROP COLUMN puhapaev;

ALTER TABLE  palk_taabel1 DROP COLUMN uleajatoo;

	  

ALTER TABLE  palk_taabel1  RENAME COLUMN  TMP_kokku to kokku;

ALTER TABLE  palk_taabel1  RENAME COLUMN  TMP_too to too;

ALTER TABLE  palk_taabel1  RENAME COLUMN TMP_paev to paev;

ALTER TABLE  palk_taabel1  RENAME COLUMN TMP_ohtu to ohtu;

ALTER TABLE  palk_taabel1  RENAME COLUMN TMP_oo to oo;

ALTER TABLE  palk_taabel1  RENAME COLUMN TMP_tahtpaev to tahtpaev;

ALTER TABLE  palk_taabel1  RENAME COLUMN TMP_puhapaev to puhapaev;

ALTER TABLE  palk_taabel1  RENAME COLUMN TMP_uleajatoo to uleajatoo;



CREATE OR REPLACE VIEW public.curtaabel1 AS 
 SELECT palk_taabel1.id, palk_taabel1.kokku, palk_taabel1.toolepingid, palk_taabel1.ohtu, palk_taabel1.oo, palk_taabel1.too, palk_taabel1.paev, palk_taabel1.tahtpaev, palk_taabel1.puhapaev, palk_taabel1.kuu, palk_taabel1.aasta, amet.kood AS ametikood, amet.nimetus AS amet, osakond.kood AS osakonnakood, osakond.nimetus AS osakond, asutus.nimetus AS isik, asutus.regkood AS isikukood, tooleping.rekvid
   FROM palk_taabel1
   JOIN tooleping ON palk_taabel1.toolepingid = tooleping.id
   JOIN asutus ON tooleping.parentid = asutus.id
   JOIN library amet ON tooleping.ametid = amet.id
   JOIN library osakond ON tooleping.osakondid = osakond.id;

GRANT ALL ON TABLE public.curtaabel1 TO vlad WITH GRANT OPTION;
GRANT SELECT ON TABLE public.curtaabel1 TO GROUP dbpeakasutaja;
GRANT SELECT ON TABLE public.curtaabel1 TO GROUP dbkasutaja;
GRANT SELECT ON TABLE public.curtaabel1 TO GROUP dbadmin;
GRANT SELECT ON TABLE public.curtaabel1 TO GROUP dbvaatleja;


-- toograf



DROP VIEW public.curtoograafik;




alter table toograf ADD TMP_tund   numeric(12,4) ;

update toograf set TMP_tund = tund;

alter table toograf alter column TMP_tund   set default 0 ;

ALTER TABLE  toograf DROP COLUMN  tund;

ALTER TABLE  toograf  RENAME COLUMN  tmp_tund to tund;



CREATE OR REPLACE VIEW public.curtoograafik AS 
 SELECT comtooleping.isik, comtooleping.osakond, comtooleping.amet, toograf.id, toograf.lepingid, toograf.kuu, toograf.aasta, toograf.tund, comtooleping.rekvid, comtooleping.parentid AS asutusid
   FROM comtooleping
   JOIN toograf ON comtooleping.id = toograf.lepingid;

GRANT ALL ON TABLE public.curtoograafik TO vlad WITH GRANT OPTION;
GRANT SELECT ON TABLE public.curtoograafik TO GROUP dbpeakasutaja;
GRANT SELECT ON TABLE public.curtoograafik TO GROUP dbkasutaja;
GRANT SELECT ON TABLE public.curtoograafik TO GROUP dbadmin;
GRANT SELECT ON TABLE public.curtoograafik TO GROUP dbvaatleja;




-- nomenklatuur lisame kbm


/*
alter table nomenklatuur ADD kbm  numeric(12,4) ;

update nomenklatuur set kbm = 18;

alter table nomenklatuur alter column kbm   set default 18 ;

alter table nomenklatuur alter column kbm   set not null ;

*/

-- pv_kaart

DROP VIEW public.curpohivara;


alter table pv_kaart ADD parhind  numeric(12,4) ;

update pv_kaart set parhind = soetmaks;

alter table pv_kaart alter column parhind   set default 0 ;

alter table pv_kaart alter column parhind   set not null ;






CREATE OR REPLACE VIEW public.curpohivara AS 
SELECT library.id, library.kood, library.nimetus, library.rekvid, pv_kaart.vastisikid, 
ifnull(asutus.nimetus, space(254)) AS vastisik, pv_kaart.algkulum, pv_kaart.kulum, pv_kaart.soetmaks,  pv_kaart.parhind,
pv_kaart.soetkpv, grupp.nimetus AS grupp, pv_kaart.konto, pv_kaart.gruppid, pv_kaart.tunnus, 
pv_kaart.mahakantud, pv_kaart.muud::character varying(254) AS rentnik,  CASE
WHEN pv_kaart.kulum > 0::numeric THEN 'Pohivara'::text  ELSE 'Vaikevahendid'::text END AS liik
FROM library JOIN pv_kaart ON library.id = pv_kaart.parentid  
LEFT JOIN asutus ON pv_kaart.vastisikid = asutus.id   
JOIN library grupp ON pv_kaart.gruppid = grupp.id;

GRANT ALL ON TABLE public.curpohivara TO vlad WITH GRANT OPTION;
GRANT SELECT ON TABLE public.curpohivara TO GROUP dbpeakasutaja;
GRANT SELECT ON TABLE public.curpohivara TO GROUP dbkasutaja;
GRANT SELECT ON TABLE public.curpohivara TO GROUP dbadmin;
GRANT SELECT ON TABLE public.curpohivara TO GROUP dbvaatleja;




/*


if (select count(*) from pg_proc where UPPER(proname) = UPPER('trigiu_vanemtasu1_after') ) > 0 then
	DROP TRIGGER trigiu_vanemtasu1_after ON public.vanemtasu1 CASCADE;
end if;

if (select count(*) from pg_proc where UPPER(proname) = UPPER('trigd_vanemtasu1_after')) > 0 then
	DROP TRIGGER trigd_vanemtasu1_after ON public.vanemtasu1 CASCADE;
end if;

if (select count(*) from pg_proc where UPPER(proname) = UPPER('trigi_vanemtasu4_before')) > 0 then
	DROP TRIGGER trigi_vanemtasu4_before ON public.vanemtasu4 CASCADE;
end if;

if (select count(*) from pg_proc where UPPER(proname) = UPPER('trigd_pv_kaart_after')) > 0 then
	DROP TRIGGER trigd_pv_kaart_after ON public.pv_kaart CASCADE;
end if;


if (select count(*) from pg_proc where UPPER(proname) = UPPER('sp_subkontod_report')) > 0 then
	DROP FUNCTION sp_subkontod_report(varchar, int4, date, date, int, varchar, int);
END IF;

if (select count(*) from pg_proc where UPPER(proname) = UPPER('sp_calc_arv')) > 0 then
	DROP FUNCTION public.sp_calc_arv(int4, int4, date);
end if;

if (select count(*) from pg_proc where UPPER(proname) = UPPER('sp_del_lapsed')) > 0 then
	DROP FUNCTION public.sp_del_lapsed(int4, int4);
end if;

if (select count(*) from pg_proc where UPPER(proname) = UPPER('sp_calc_tasu')) > 0 then
	DROP FUNCTION public.sp_calc_tasu(int4, int4, date);
end if;

if (select count(*) from pg_proc where UPPER(proname) = UPPER('gen_lausend_mahakandmine')) > 0 then
	 DROP FUNCTION public.gen_lausend_mahakandmine(int4);
end if;

if (select count(*) from pg_proc where UPPER(proname) = UPPER('gen_lausend_koolitus')) > 0 then
	DROP FUNCTION public.gen_lausend_koolitus(int4);
end if;


if (select count(*) from pg_proc where UPPER(proname) = UPPER('sp_vanemtasu_aruanne2')) > 0 then
	DROP FUNCTION public.sp_vanemtasu_aruanne2(int4, varchar, varchar, varchar, date, date);
end if;


if (select count(*) from pg_proc where UPPER(proname) = UPPER('sp_calc_vanemtasu_jaak')) > 0 then
	DROP FUNCTION public.sp_calc_vanemtasu_jaak(int4, int4);

end if;

if (select count(*) from pg_proc where UPPER(proname) = UPPER('sp_vanemtasu_aruanne2')) > 0 then
	 DROP FUNCTION public.sp_vanemtasu_aruanne2(int4, varchar, varchar, varchar, date, date);
end if;



if (select count(*) from pg_proc where UPPER(proname) = UPPER('f_round')) > 0 then
	DROP FUNCTION public.f_round(numeric, numeric);
end if;
*/

	-- registreerime uuendus

	insert into uuendus (versia, sql, selg, tulemus,USERID) values (1,'muudatus20041022','Taabel, tbl struktuur, teised funktsioonid',1,1);







	RETURN 1;
END;
$$;

ALTER FUNCTION muudatus() OWNER TO vlad;

