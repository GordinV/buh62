CREATE VIEW cur_journal(created, lastupdate, status, id, kpv, number, journalid, rekvid, asutusid, kuu, aasta, selg,
                        dok, objekt, muud, deebet, lisa_d, kreedit, lisa_k, summa, valsumma, valuuta, kuurs, kood1,
                        kood2, kood3, kood4, kood5, proj, asutus, tunnus, kasutaja, rekvasutus) AS
SELECT to_char(d.created, 'DD.MM.YYYY HH:MM'::TEXT)                        AS created,
       to_char(d.lastupdate, 'DD.MM.YYYY HH:MM'::TEXT)                     AS lastupdate,
       s.nimetus                                                           AS status,
       d.id,
       j.kpv,
       jid.number,
       j.id                                                                AS journalid,
       j.rekvid,
       j.asutusid,
       month(j.kpv)                                                        AS kuu,
       year(j.kpv)                                                         AS aasta,
       (COALESCE(j.selg, ''::TEXT))::CHARACTER VARYING(254)                AS selg,
       (COALESCE(j.dok, ''::TEXT))::CHARACTER VARYING(20)                  AS dok,
       (COALESCE(j.objekt, ''::TEXT))::CHARACTER VARYING(20)               AS objekt,
       (j.muud)::CHARACTER VARYING(254)                                    AS muud,
       j1.deebet,
       (COALESCE(j1.lisa_d, ''::CHARACTER VARYING))::CHARACTER VARYING(20) AS lisa_d,
       j1.kreedit,
       (COALESCE(j1.lisa_k, ''::CHARACTER VARYING))::CHARACTER VARYING(20) AS lisa_k,
       j1.summa,
       j1.valsumma,
       'EUR'::CHARACTER VARYING(20)                                        AS valuuta,
       (1)::NUMERIC(12, 6)                                                 AS kuurs,
       (COALESCE(j1.kood1, ''::CHARACTER VARYING))::CHARACTER VARYING(20)  AS kood1,
       (COALESCE(j1.kood2, ''::CHARACTER VARYING))::CHARACTER VARYING(20)  AS kood2,
       (COALESCE(j1.kood3, ''::CHARACTER VARYING))::CHARACTER VARYING(20)  AS kood3,
       (COALESCE(j1.kood4, ''::CHARACTER VARYING))::CHARACTER VARYING(20)  AS kood4,
       (COALESCE(j1.kood5, ''::CHARACTER VARYING))::CHARACTER VARYING(20)  AS kood5,
       (COALESCE(j1.proj, ''::CHARACTER VARYING))::CHARACTER VARYING(20)   AS proj,
       (COALESCE(((ltrim(rtrim((a.nimetus)::TEXT)) || ' '::TEXT) || ltrim(rtrim((a.omvorm)::TEXT))),
                 ''::TEXT))::CHARACTER VARYING(120)                        AS asutus,
       (COALESCE(j1.tunnus, ''::CHARACTER VARYING))::CHARACTER VARYING(20) AS tunnus,
       (COALESCE(u.ametnik, ''::BPCHAR))::CHARACTER VARYING(120)           AS kasutaja,
       r.nimetus                                                           AS rekvasutus
FROM (((((((docs.journal j
    JOIN docs.doc d ON ((d.id = j.parentid)))
    JOIN libs.library s ON ((((s.kood)::TEXT = (d.status)::TEXT) AND (s.library = 'STATUS'::BPCHAR))))
    JOIN docs.journalid jid ON ((j.id = jid.journalid)))
    JOIN docs.journal1 j1 ON ((j.id = j1.parentid)))
    JOIN ou.rekv r ON ((r.id = j.rekvid)))
    LEFT JOIN libs.asutus a ON ((a.id = j.asutusid)))
         LEFT JOIN ou.userid u ON ((u.id = j.userid)));

ALTER TABLE cur_journal
    OWNER TO vlad;

