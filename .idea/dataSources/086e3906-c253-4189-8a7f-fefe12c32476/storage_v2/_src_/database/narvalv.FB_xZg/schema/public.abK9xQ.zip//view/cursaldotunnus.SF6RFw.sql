CREATE VIEW cursaldotunnus(kpv, rekvid, konto, deebet, kreedit, opt, tunnusid) AS
    SELECT date(2000, 1, 1) AS kpv,
           tunnusinf.rekvid,
           library.kood     AS konto,
           CASE
               WHEN (tunnusinf.algsaldo >= (0)::NUMERIC) THEN tunnusinf.algsaldo
               ELSE (0)::NUMERIC
               END          AS deebet,
           CASE
               WHEN (tunnusinf.algsaldo < (0)::NUMERIC) THEN ((- (1)::NUMERIC) * tunnusinf.algsaldo)
               ELSE (0)::NUMERIC
               END          AS kreedit,
           1                AS opt,
           tunnusinf.tunnusid
    FROM (library
             JOIN tunnusinf ON ((library.id = tunnusinf.kontoid)))
    UNION ALL
    SELECT curjournal.kpv,
           curjournal.rekvid,
           curjournal.deebet AS konto,
           curjournal.summa  AS deebet,
           0                 AS kreedit,
           4                 AS opt,
           t.id              AS tunnusid
    FROM (curjournal
             JOIN library t ON (((curjournal.tunnus)::BPCHAR = t.kood)))
    WHERE (len((ltrim(rtrim((curjournal.tunnus)::TEXT)))::CHARACTER VARYING) > 0)
    UNION ALL
    SELECT curjournal.kpv,
           curjournal.rekvid,
           curjournal.kreedit AS konto,
           0                  AS deebet,
           curjournal.summa   AS kreedit,
           4                  AS opt,
           t.id               AS tunnusid
    FROM (curjournal
             JOIN library t ON (((curjournal.tunnus)::BPCHAR = t.kood)))
    WHERE (len((ltrim(rtrim((curjournal.tunnus)::TEXT)))::CHARACTER VARYING) > 0);

ALTER TABLE cursaldotunnus
    OWNER TO vlad;

