CREATE VIEW cursaldo(kpv, rekvid, konto, deebet, kreedit, opt, asutusid) AS
    SELECT journal.kpv,
           journal.rekvid,
           journal1.deebet                                            AS konto,
           (journal1.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC)) AS deebet,
           (0)::NUMERIC(12, 4)                                        AS kreedit,
           4                                                          AS opt,
           journal.asutusid
    FROM (((journal
        JOIN journal1 ON ((journal.id = journal1.parentid)))
        JOIN journalid ON ((journal.id = journalid.journalid)))
             LEFT JOIN dokvaluuta1 ON (((journal1.id = dokvaluuta1.dokid) AND (dokvaluuta1.dokliik = 1))))
    UNION ALL
    SELECT journal.kpv,
           journal.rekvid,
           journal1.kreedit                                           AS konto,
           (0)::NUMERIC(12, 4)                                        AS deebet,
           (journal1.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC)) AS kreedit,
           4                                                          AS opt,
           journal.asutusid
    FROM (((journal
        JOIN journal1 ON ((journal.id = journal1.parentid)))
        JOIN journalid ON ((journal.id = journalid.journalid)))
             LEFT JOIN dokvaluuta1 ON (((journal1.id = dokvaluuta1.dokid) AND (dokvaluuta1.dokliik = 1))));

ALTER TABLE cursaldo
    OWNER TO vlad;

