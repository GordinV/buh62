CREATE FUNCTION fnc_valkehtivus(character varying, date) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
DECLARE 
	tcValuuta alias for $1;
	tdKpv alias for $2;
	lnreturn int;
	inId int;
begin
	-- pohi tingimused
	lnReturn = 0;
	
	if year(tdKpv) < 2011 and tcValuuta = 'EEK' then
		lnReturn = 1;
	else
		-- otsime valuuta
		if (select count(id) from library where library = 'VALUUTA' and kood = tcValuuta 
			and (empty(library.tun4) or library.tun4 <= dateasint(tdKpv)) 
			and  (empty(library.tun5) or library.tun5 >= dateasint(tdKpv))) > 0 then
			lnReturn = 1;
		end if;
	end if;	
	return lnReturn;
end;
$$;

ALTER FUNCTION fnc_valkehtivus(VARCHAR, DATE) OWNER TO vlad;

