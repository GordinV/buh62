CREATE VIEW com_artikkel(id, kood, nimetus, rekvid, is_kulud) AS
SELECT qry.id,
       qry.kood,
       qry.nimetus,
       qry.rekvid,
       qry.is_kulud
FROM (SELECT 0                         AS id,
             ''::CHARACTER VARYING(20) AS kood,
             ''::CHARACTER VARYING(20) AS nimetus,
             NULL::INTEGER             AS rekvid,
             TRUE                      AS is_kulud
      UNION
      SELECT l.id,
             l.kood,
             l.nimetus,
             l.rekvid,
             CASE
                 WHEN (l.tun5 = 1) THEN FALSE
                 ELSE TRUE
                 END AS is_kulud
      FROM libs.library l
      WHERE ((l.library = 'TULUDEALLIKAD'::BPCHAR) AND (l.status <> 3))) qry
ORDER BY qry.kood;

ALTER TABLE com_artikkel
    OWNER TO vlad;

