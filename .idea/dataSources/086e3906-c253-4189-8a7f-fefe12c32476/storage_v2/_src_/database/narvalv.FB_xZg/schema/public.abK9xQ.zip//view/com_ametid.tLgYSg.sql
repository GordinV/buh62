CREATE VIEW com_ametid(id, kood, nimetus, rekvid, osakondid) AS
SELECT qry.id,
       qry.kood,
       qry.nimetus,
       qry.rekvid,
       qry.osakondid
FROM (SELECT 0                         AS id,
             ''::CHARACTER VARYING(20) AS kood,
             ''::CHARACTER VARYING(20) AS nimetus,
             NULL::INTEGER             AS rekvid,
             NULL::INTEGER             AS osakondid
      UNION
      SELECT l.id,
             l.kood,
             l.nimetus,
             l.rekvid,
             (((l.properties)::JSONB ->> 'osakondid'::TEXT))::INTEGER AS osakondid
      FROM libs.library l
      WHERE ((l.library = 'AMET'::BPCHAR) AND (l.status <> 3))) qry
ORDER BY qry.kood;

ALTER TABLE com_ametid
    OWNER TO vlad;

