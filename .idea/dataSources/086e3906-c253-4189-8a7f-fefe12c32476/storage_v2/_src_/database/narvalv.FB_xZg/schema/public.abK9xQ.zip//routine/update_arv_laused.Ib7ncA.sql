CREATE FUNCTION update_arv_laused() RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare 
	lnId int;
	v_arv record;

BEGIN
	for v_arv in
		select id, number from arv where rekvid = 6 and month(kpv) = 2 and year(kpv) = 2005 and userid = 337
		loop
			raise notice 'Arve number %',v_arv.number;
			lnId := gen_lausend_arv(v_arv.id) ;
			raise notice 'Done %',lnId;
		end loop;

RETURN lnId;



end;


$$;

ALTER FUNCTION update_arv_laused() OWNER TO vlad;

