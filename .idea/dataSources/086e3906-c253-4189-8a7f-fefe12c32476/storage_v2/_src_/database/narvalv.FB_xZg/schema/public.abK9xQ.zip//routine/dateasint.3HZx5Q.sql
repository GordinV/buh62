CREATE FUNCTION dateasint(date) RETURNS integer
    LANGUAGE plpgsql
AS
$$
DECLARE 
	tdKpv alias for $1;
	lnDate int;
	lcKuu varchar(2);
	lcPaev varchar(2);
begin
	lnDate = 0;
	if month(tdKpv) < 10 then
		lcKuu = '0'+str(month(tdKpv),1); 
	else
		lcKuu = str(month(tdKpv),2); 
	end if;
	if day(tdKpv) < 10 then
		lcPaev = '0'+str(day(tdKpv),1);
	else
		lcPaev = str(day(tdKpv),2);
	end if;
	if not empty(tdKpv) then
		lnDate = val(str(year(tdKpv),4)+lcKuu+lcPaev);
	end if;

	
	return lnDate;
end;
$$;

ALTER FUNCTION dateasint(DATE) OWNER TO vlad;

