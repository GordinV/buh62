CREATE VIEW curkassakuludetaitmine(kuu, aasta, rekvid, summa, kood, eelarve, tegev, tun, kood2, asutus) AS
SELECT month(journal.kpv)                                              AS kuu,
       year(journal.kpv)                                               AS aasta,
       journal.rekvid,
       sum((journal1.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))) AS summa,
       journal1.kood5                                                  AS kood,
       space(1)                                                        AS eelarve,
       journal1.kood1                                                  AS tegev,
       journal1.tunnus                                                 AS tun,
       journal1.kood2,
       rekv.nimetus                                                    AS asutus
FROM (((((journal
    JOIN journal1 ON ((journal1.parentid = journal.id)))
    JOIN rekv ON ((rekv.id = journal.rekvid)))
    LEFT JOIN dokvaluuta1 ON (((journal1.id = dokvaluuta1.dokid) AND (dokvaluuta1.dokliik = 1))))
    JOIN kassakulud ON ((ltrim(rtrim((journal1.deebet)::TEXT)) ~~ ltrim(rtrim((kassakulud.kood)::TEXT)))))
         JOIN kassakontod ON ((ltrim(rtrim((journal1.kreedit)::TEXT)) ~~ ltrim(rtrim((kassakontod.kood)::TEXT)))))
GROUP BY (year(journal.kpv)), (month(journal.kpv)), journal.rekvid, journal1.deebet, journal1.kood1, journal1.tunnus,
         journal1.kood5, journal1.kood2, rekv.nimetus
ORDER BY (year(journal.kpv)), (month(journal.kpv)), journal.rekvid, journal1.deebet, journal1.kood1, journal1.tunnus,
         journal1.kood5, journal1.kood2;

ALTER TABLE curkassakuludetaitmine
    OWNER TO vlad;

