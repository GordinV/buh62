CREATE FUNCTION fnc_currentkuurs(date) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
DECLARE 
	tdKpv alias for $1;
	lnKuurs numeric(14,4);
	lnPohiKuurs numeric(14,4);
	inId int;
begin
	-- pohi tingimused
	
	if year(tdKpv) < 2011 then
		lnKuurs = 1;
	else
		lnKuurs = 15.6466;
	end if;
	-- otsime pohivaluuta

	select valuuta1.kuurs into lnPohiKuurs 
		from library inner join valuuta1 on library.id = valuuta1.parentid
		where valuuta1.alates <= tdKpv and valuuta1.kuni >= tdKpv and 
		library.kood = fnc_currentvaluuta(tdKpv);

	lnKuurs = ifnull(lnPohiKuurs,lnKuurs);
	
	return lnKuurs;
end;
$$;

ALTER FUNCTION fnc_currentkuurs(DATE) OWNER TO vlad;

