CREATE FUNCTION sp_calc_taabel1(integer, integer, integer) RETURNS integer
    LANGUAGE plpgsql
AS
$$
declare
	tnid alias for $1;
	tnkuu alias for $2;
	tnAasta alias for $3;
	lnHours int;
	lnreturn int;
	lnHoliday int;
	v_tooleping record;
	lnPuhkus int;
	lnHaigus int;
	lnWorkdays int;
	npaev int;
begin

lnHours := 0;
lnreturn := 0;
lnHoliday := 0;
raise notice 'start';
select * into v_tooleping  from tooleping where id = tnid;

If month (v_Tooleping.algab ) = TnKuu and year (v_Tooleping.algab) = Tnaasta then
	nPaev := day (v_Tooleping.algab);
Else
	nPaev := 1;
End if;

raise notice 'npaev %',npaev;

-- arv puhkuse paevad
lnPuhkus := check_puhkus(tnid, tnKuu, tnAasta);
raise notice 'lnPuhkus %',lnPuhkus;

-- arv haiguse paevad
lnHaigus := check_haigus(tnid, tnKuu, tnAasta);
raise notice 'lnHaigus %',lnHaigus;

lnWorkDays := sp_workdays(nPaev, tnKuu, tnAasta, 31, tnId)::INT4;
raise notice 'lnWorkDays %',lnWorkDays;
lnHours := ((lnworkdays - (lnpuhkus + lnhaigus)) * v_Tooleping.toopaev::int4)::int4;
Return lnHours;
end;
$$;

ALTER FUNCTION sp_calc_taabel1(INTEGER, INTEGER, INTEGER) OWNER TO vlad;

