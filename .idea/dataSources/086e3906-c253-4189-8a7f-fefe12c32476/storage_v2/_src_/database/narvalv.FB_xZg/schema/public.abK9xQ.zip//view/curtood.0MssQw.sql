CREATE VIEW curtood(id, asutusid, asutus, regkood, rekvid, kpv, isikid, nomid, isikukood, isik, kood, teenus, uhik,
                    tunda, tundl, mina, minl, hind, kogus, kokku, arvid, selg) AS
SELECT teenused.id,
       teenused.asutusid,
       "left"((((ltrim(rtrim((asutus.nimetus)::TEXT)))::BPCHAR + space(1)) +
               (ltrim(rtrim((asutus.omvorm)::TEXT)))::BPCHAR), 254) AS asutus,
       asutus.regkood,
       teenused.rekvid,
       teenused.kpv,
       teenused.isikid,
       teenused.nomid,
       isikud.regkood                                               AS isikukood,
       isikud.nimetus                                               AS isik,
       nomenklatuur.kood,
       nomenklatuur.nimetus                                         AS teenus,
       nomenklatuur.uhik,
       teenused.tunda,
       teenused.tundl,
       teenused.mina,
       teenused.minl,
       teenused.hind,
       teenused.kogus,
       teenused.kokku,
       teenused.arvid,
       (teenused.selg)::CHARACTER VARYING(254)                      AS selg
FROM (((teenused
    JOIN asutus ON ((teenused.asutusid = asutus.id)))
    JOIN asutus isikud ON ((teenused.isikid = isikud.id)))
         JOIN nomenklatuur ON ((teenused.nomid = nomenklatuur.id)));

ALTER TABLE curtood
    OWNER TO vlad;

