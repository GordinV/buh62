CREATE FUNCTION fncarvjaak2012(integer) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
declare 
	tnArvId ALIAS FOR $1;
	lnJaak numeric;
	lnArvSumma numeric;
	lnTasuSumma numeric;

BEGIN

	select sum(summa*ifnull(dokvaluuta1.kuurs,1)) into lnArvSumma 
		from arv left outer join  dokvaluuta1 on (arv.id = dokvaluuta1.dokid and dokvaluuta1.dokliik = 3)  
		where arv.id = tnArvId;

	select sum(summa * ifnull(dokvaluuta1.kuurs,1)) into lnTasuSumma 
		from arvtasu left outer join dokvaluuta1 on (arvtasu.id = dokvaluuta1.dokid and dokvaluuta1.dokliik = 21)
		where arvid = tnArvId and kpv < date(2012,01,01);

	lnJaak = ifnull(lnArvSumma,0) - ifnull(lnTasuSumma ,0);
		


RETURN lnJaak;


end;


$$;

ALTER FUNCTION fncarvjaak2012(INTEGER) OWNER TO vlad;

