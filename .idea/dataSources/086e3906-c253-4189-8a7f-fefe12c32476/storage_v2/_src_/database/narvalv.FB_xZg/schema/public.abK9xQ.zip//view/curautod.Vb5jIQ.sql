CREATE VIEW curautod(id, mark, regnum, mootor, aasta, voimsus, vinkood, idkood, tuubikood, rekvid, nimetus, omanikid) AS
SELECT autod.id,
       autod.mark,
       autod.regnum,
       autod.mootor,
       autod.aasta,
       autod.voimsus,
       autod.vinkood,
       autod.idkood,
       autod.tuubikood,
       asutus.rekvid,
       asutus.nimetus,
       autod.omanikid
FROM (autod
         JOIN asutus ON ((autod.omanikid = asutus.id)));

ALTER TABLE curautod
    OWNER TO vlad;

