CREATE VIEW cur_taotlused(id, rekvid, koostajaid, aktseptid, kpv, number, aasta, kuu, status, allkiri, kood1, kood2,
                          kood3, kood4, kood5, tunnus, summa, parentid, regkood, nimetus, ametnik) AS
SELECT d.id,
       t.rekvid,
       t.koostajaid,
       t.aktseptid,
       t.kpv,
       t.number,
       t.aasta,
       t.kuu,
       t.status,
       t.allkiri,
       (COALESCE(t1.kood1, ''::CHARACTER VARYING))::CHARACTER VARYING(20)  AS kood1,
       (COALESCE(t1.kood2, ''::CHARACTER VARYING))::CHARACTER VARYING(20)  AS kood2,
       (COALESCE(t1.kood3, ''::CHARACTER VARYING))::CHARACTER VARYING(20)  AS kood3,
       (COALESCE(t1.kood4, ''::CHARACTER VARYING))::CHARACTER VARYING(20)  AS kood4,
       (COALESCE(t1.kood5, ''::CHARACTER VARYING))::CHARACTER VARYING(20)  AS kood5,
       (COALESCE(t1.tunnus, ''::CHARACTER VARYING))::CHARACTER VARYING(20) AS tunnus,
       t1.summa,
       rekv.parentid,
       rekv.regkood,
       rekv.nimetus,
       userid.ametnik
FROM ((((docs.doc d
    JOIN eelarve.taotlus t ON ((d.id = t.parentid)))
    JOIN eelarve.taotlus1 t1 ON ((t.id = t1.parentid)))
    JOIN ou.rekv rekv ON ((t.rekvid = rekv.id)))
         LEFT JOIN ou.userid userid ON ((t.koostajaid = userid.id)));

ALTER TABLE cur_taotlused
    OWNER TO vlad;

