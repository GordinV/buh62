CREATE VIEW com_valuuta(id, kood, nimetus, rekvid, kuurs) AS
SELECT qry.id,
       qry.kood,
       qry.nimetus,
       qry.rekvid,
       qry.kuurs
FROM (SELECT 0                         AS id,
             ''::CHARACTER VARYING(20) AS kood,
             ''::CHARACTER VARYING(20) AS nimetus,
             NULL::INTEGER             AS rekvid,
             (1)::NUMERIC              AS kuurs
      UNION
      SELECT l.id,
             l.kood,
             l.nimetus,
             l.rekvid,
             COALESCE((SELECT v.kuurs
                       FROM libs.valuuta v
                       WHERE (v.parentid = l.id)
                       ORDER BY v.id DESC
                       LIMIT 1), (1)::NUMERIC) AS kuurs
      FROM libs.library l
      WHERE ((l.library = 'VALUUTA'::BPCHAR) AND (l.status <> 3))) qry
ORDER BY qry.kood;

ALTER TABLE com_valuuta
    OWNER TO vlad;

