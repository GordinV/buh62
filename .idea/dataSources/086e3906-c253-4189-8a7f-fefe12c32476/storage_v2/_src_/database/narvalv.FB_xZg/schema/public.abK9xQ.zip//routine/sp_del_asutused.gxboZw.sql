CREATE FUNCTION sp_del_asutused(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 	
	tnId alias for $1;
begin
	DELETE FROM asutus WHERE id = tnId;
	DELETE FROM asutusaa WHERE parentid = tnId;

	if found then
		Return 1;
	else

		Return 0;

	end if;

end;
$$;

ALTER FUNCTION sp_del_asutused(INTEGER, INTEGER) OWNER TO vlad;

