CREATE FUNCTION sp_calcrea_palkstat_aruanne23(integer, date, date, integer, character varying, character varying, integer, integer, character varying) RETURNS integer
    LANGUAGE plpgsql
AS
$$
DECLARE 
	tnrekvid alias for $1;
	tnOsakond alias for $4;
	tdKpv1 alias for $2;
	tdKpv2 alias for $3;
	tcrea alias for $5;
	tcNimetus alias for $6;
	tnAmetkood alias for $7;
	lnworkday alias for $8;
	lcreturn alias for $9;
	ln1 numeric;
	ln2 numeric;
	ln3 numeric;
	ln4 numeric;
	ln5 numeric;
	ln6 numeric;
	lnOsakond1 int;
	lnOsakond2 int;
	
begin
--	raise notice ' start  ';
	

	if tnOsakond > 0 then
		lnOsakond1 := tnOsakond;
		lnOsakond2 := tnOsakond;
	else
		lnOsakond1 := 0;
		lnOsakond2 := 999999999;
	end if;

	
	select count(*) into ln1 from asutus 
		where left(asutus.regkood,1) in ('3','5')
		and id in (
		select distinct tooleping.parentid from tooleping inner join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId
			 inner join palk_asutus on (palk_asutus.osakondId = tooleping.osakondId and palk_asutus.ametid = tooleping.ametid)
			where tooleping.rekvId = tnRekvid 
			and tooleping.osakondId >= lnOsakond1 and tooleping.osakondId <= lnOsakond2
			and algab <= tdKpv1 and (empty(lopp) or lopp >= tdKpv2) and pohikoht = 1
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and palk_asutus.vaba = tnAmetkood
			and tooleping.toopaev * lnworkday <=  palk_taabel1.kokku
			) ;

	select count(*) into ln4 from asutus 
		where left(asutus.regkood,1) in ('4','6')
		and id in (
		select distinct tooleping.parentid from tooleping inner join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId 
			 inner join palk_asutus on (palk_asutus.osakondId = tooleping.osakondId and palk_asutus.ametid = tooleping.ametid)
			where tooleping.rekvId = tnRekvid 
			and tooleping.osakondId >= lnOsakond1 and tooleping.osakondId <= lnOsakond2
			and algab <= tdKpv1 and (empty(lopp) or lopp >= tdKpv2) and pohikoht = 1
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and palk_asutus.vaba = tnAmetkood
			and tooleping.toopaev * lnworkday <=  palk_taabel1.kokku
			) ;


	select sum(palk_taabel1.kokku) into ln2 from tooleping inner join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId 
			 inner join palk_asutus on (palk_asutus.osakondId = tooleping.osakondId and palk_asutus.ametid = tooleping.ametid)
			where tooleping.rekvId = tnRekvid 
			and tooleping.osakondId >= lnOsakond1 and tooleping.osakondId <= lnOsakond2
			and algab <= tdKpv1 and (empty(lopp) or lopp >= tdKpv2) and pohikoht = 1
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and tooleping.toopaev * lnworkday <=  palk_taabel1.kokku 
			and palk_asutus.vaba = tnAmetkood
			and tooleping.parentid in (select id from asutus 
			where left(asutus.regkood,1) in ('3','5')
			);


	select sum(palk_taabel1.kokku) into ln5 from tooleping inner join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId 
			 inner join palk_asutus on (palk_asutus.osakondId = tooleping.osakondId and palk_asutus.ametid = tooleping.ametid)
			where tooleping.rekvId = tnRekvid 
			and tooleping.osakondId >= lnOsakond1 and tooleping.osakondId <= lnOsakond2
			and algab <= tdKpv1 and (empty(lopp) or lopp >= tdKpv2) and pohikoht = 1
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and tooleping.toopaev * lnworkday <=  palk_taabel1.kokku 

			and palk_asutus.vaba = tnAmetkood
			and tooleping.parentid in (select id from asutus 
			where left(asutus.regkood,1) in ('4','6')
			);

	select sum(palk_jaak.arvestatud) into ln3 from tooleping inner join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId 
			 inner join palk_asutus on (palk_asutus.osakondId = tooleping.osakondId and palk_asutus.ametid = tooleping.ametid)
			inner join palk_jaak on tooleping.id = palk_jaak.lepingId
			where tooleping.rekvId = tnRekvid 
			and tooleping.osakondId >= lnOsakond1 and tooleping.osakondId <= lnOsakond2
			and algab <= tdKpv1 and (empty(lopp) or lopp >= tdKpv2) and pohikoht = 1
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and palk_jaak.kuu = month(tdKpv2)
			and palk_jaak.aasta = year(tdKpv2)
			and tooleping.toopaev * lnworkday <=  palk_taabel1.kokku 

			and palk_asutus.vaba = tnAmetkood
			and tooleping.parentid in (select id from asutus 
			where left(asutus.regkood,1) in ('3','5')
			);

	select sum(palk_jaak.arvestatud) into ln6 from tooleping inner join palk_taabel1 on tooleping.id = palk_taabel1.toolepingId 
			 inner join palk_asutus on (palk_asutus.osakondId = tooleping.osakondId and palk_asutus.ametid = tooleping.ametid)
			inner join palk_jaak on tooleping.id = palk_jaak.lepingId
			where tooleping.rekvId = tnRekvid 
			and tooleping.osakondId >= lnOsakond1 and tooleping.osakondId <= lnOsakond2
			and algab <= tdKpv1 and (empty(lopp) or lopp >= tdKpv2) and pohikoht = 1
			and palk_taabel1.kuu = month(tdKpv2)
			and palk_taabel1.aasta = year(tdKpv2)
			and palk_jaak.kuu = month(tdKpv2)
			and palk_jaak.aasta = year(tdKpv2)
			and tooleping.toopaev * lnworkday <=  palk_taabel1.kokku 
			and palk_asutus.vaba = tnAmetkood
			and tooleping.parentid in (select id from asutus 
			where left(asutus.regkood,1) in ('4','6')
			);



	insert into tmp_palkstat2 (tbl, nimetus, rea, timestamp,rekvid,col1, col2, col3, col4, col5, col6)
		values (tcNimetus,str(tnAmetkood),tcRea,
		lcreturn, tnRekvid, ifnull(ln1,0), ifnull(ln2,0), ifnull(ln3,0),ifnull(ln4,0), ifnull(ln5,0), ifnull(ln6,0));


	return 1;

end;

$$;

ALTER FUNCTION sp_calcrea_palkstat_aruanne23(INTEGER, DATE, DATE, INTEGER, VARCHAR, VARCHAR, INTEGER, INTEGER, VARCHAR) OWNER TO vlad;

