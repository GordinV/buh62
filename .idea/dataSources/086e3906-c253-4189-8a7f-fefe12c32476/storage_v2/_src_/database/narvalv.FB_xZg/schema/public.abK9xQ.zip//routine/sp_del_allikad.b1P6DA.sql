CREATE FUNCTION sp_del_allikad(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 


	tnId alias for $1;


	tnOpt alias for $2;


begin

	Delete From library Where Id = tnid;


	Return 1;


end;

$$;

ALTER FUNCTION sp_del_allikad(INTEGER, INTEGER) OWNER TO vlad;

