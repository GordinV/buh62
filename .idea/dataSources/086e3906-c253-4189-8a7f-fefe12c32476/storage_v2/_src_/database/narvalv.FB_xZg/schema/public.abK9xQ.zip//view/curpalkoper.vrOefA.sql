CREATE VIEW curpalkoper(tun1, tun2, tun3, tun4, tun5, nimetus, isik, isikid, journalid, journal1id, kpv, summa, id,
                        libid, rekvid, pank, aa, osakondid, liik, tund, maks, valuuta, kuurs) AS
SELECT library.tun1,
       library.tun2,
       library.tun3,
       library.tun4,
       library.tun5,
       library.nimetus,
       asutus.nimetus                                                            AS isik,
       asutus.id                                                                 AS isikid,
       ifnull(journalid.number, 0)                                               AS journalid,
       palk_oper.journal1id,
       palk_oper.kpv,
       palk_oper.summa,
       palk_oper.id,
       palk_oper.libid,
       palk_oper.rekvid,
       tooleping.pank,
       tooleping.aa,
       tooleping.osakondid,
       CASE
           WHEN (((alltrim((to_char((palk_lib.liik)::DOUBLE PRECISION, '9'::TEXT))::BPCHAR) + '-'::BPCHAR) +
                  alltrim((to_char((palk_lib.asutusest)::DOUBLE PRECISION, '9'::TEXT))::BPCHAR)) = '1-0'::BPCHAR)
               THEN ('+'::TEXT)::BPCHAR
           WHEN (((alltrim((to_char((palk_lib.liik)::DOUBLE PRECISION, '9'::TEXT))::BPCHAR) + '-'::BPCHAR) +
                  alltrim((to_char((palk_lib.asutusest)::DOUBLE PRECISION, '9'::TEXT))::BPCHAR)) = '2-0'::BPCHAR)
               THEN ('-'::TEXT)::BPCHAR
           WHEN (((alltrim((to_char((palk_lib.liik)::DOUBLE PRECISION, '9'::TEXT))::BPCHAR) + '-'::BPCHAR) +
                  alltrim((to_char((palk_lib.asutusest)::DOUBLE PRECISION, '9'::TEXT))::BPCHAR)) = '6-0'::BPCHAR)
               THEN ('-'::TEXT)::BPCHAR
           WHEN (((alltrim((to_char((palk_lib.liik)::DOUBLE PRECISION, '9'::TEXT))::BPCHAR) + '-'::BPCHAR) +
                  alltrim((to_char((palk_lib.asutusest)::DOUBLE PRECISION, '9'::TEXT))::BPCHAR)) = '4-0'::BPCHAR)
               THEN ('-'::TEXT)::BPCHAR
           WHEN (((alltrim((to_char((palk_lib.liik)::DOUBLE PRECISION, '9'::TEXT))::BPCHAR) + '-'::BPCHAR) +
                  alltrim((to_char((palk_lib.asutusest)::DOUBLE PRECISION, '9'::TEXT))::BPCHAR)) = '8-0'::BPCHAR)
               THEN ('-'::TEXT)::BPCHAR
           WHEN (((alltrim((to_char((palk_lib.liik)::DOUBLE PRECISION, '9'::TEXT))::BPCHAR) + '-'::BPCHAR) +
                  alltrim((to_char((palk_lib.asutusest)::DOUBLE PRECISION, '9'::TEXT))::BPCHAR)) = '7-0'::BPCHAR)
               THEN ('-'::TEXT)::BPCHAR
           ELSE '%'::BPCHAR
           END                                                                   AS liik,
       CASE
           WHEN (palk_lib.tund = 1) THEN 'KOIK'::TEXT
           WHEN (palk_lib.tund = 2) THEN 'PAEV'::TEXT
           WHEN (palk_lib.tund = 3) THEN 'OHT'::TEXT
           WHEN (palk_lib.tund = 4) THEN 'OO'::TEXT
           WHEN (palk_lib.tund = 5) THEN 'PUHKUS'::TEXT
           WHEN (palk_lib.tund = 6) THEN 'PUHA'::TEXT
           WHEN (palk_lib.tund = 7) THEN 'ULETOO'::TEXT
           ELSE NULL::TEXT
           END                                                                   AS tund,
       CASE
           WHEN (palk_lib.maks = 1) THEN 'JAH'::TEXT
           ELSE 'EI'::TEXT
           END                                                                   AS maks,
       (ifnull((dokvaluuta1.valuuta)::BPCHAR, 'EEK'::BPCHAR))::CHARACTER VARYING AS valuuta,
       ifnull(dokvaluuta1.kuurs, (1)::NUMERIC)                                   AS kuurs
FROM ((((((palk_oper
    JOIN library ON ((palk_oper.libid = library.id)))
    JOIN palk_lib ON ((palk_lib.parentid = library.id)))
    JOIN tooleping ON ((palk_oper.lepingid = tooleping.id)))
    JOIN asutus ON ((tooleping.parentid = asutus.id)))
    LEFT JOIN journalid ON ((palk_oper.journalid = journalid.journalid)))
         LEFT JOIN dokvaluuta1 ON (((palk_oper.id = dokvaluuta1.dokid) AND (dokvaluuta1.dokliik = 12))));

ALTER TABLE curpalkoper
    OWNER TO vlad;

