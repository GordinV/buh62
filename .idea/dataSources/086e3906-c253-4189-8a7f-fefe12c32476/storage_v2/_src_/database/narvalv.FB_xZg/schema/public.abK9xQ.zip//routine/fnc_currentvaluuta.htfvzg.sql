CREATE FUNCTION fnc_currentvaluuta(date) RETURNS character varying
    LANGUAGE plpgsql
AS
$$
DECLARE 
	tdKpv alias for $1;
	lcValuuta varchar(20);
	lcPohiValuuta varchar(20);
begin
	-- pohi tingimused
	
	if year(tdKpv) < 2011 then
		lcValuuta = 'EEK';
	else
		lcValuuta = 'EUR';
	end if;
	-- otsime pohivaluuta
	select kood into lcPohiValuuta from library where library = 'VALUUTA' and tun1 = 1 
		and (tun4 <= dateasint(tdKpv) or empty(tun4)) 
		and (tun5 >= dateasint(tdKpv) or empty(tun5));

	lcValuuta = ifnull(lcPohiValuuta,lcValuuta);
	
	return lcValuuta;
end;
$$;

ALTER FUNCTION fnc_currentvaluuta(DATE) OWNER TO vlad;

