CREATE FUNCTION check_haigus(integer, integer, integer) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
declare
	tnId alias for $1;
	tnKuu alias for $2;
	tnAasta alias for $3;
	lnStartKpv int;
	lnLoppKpv int;
	lResult numeric(18,6)=0;
	qryPuhkused record;
	lnTunnid numeric;
begin

lresult := 0;

for qryPuhkused in 	
	SELECT puudumine.*, toopaev 
		from puudumine 
		inner join tooleping on tooleping.id = puudumine.lepingid
	WHERE lepingid = tnId 
	and ((month(kpv1) = tnKuu and year (kpv1) = tnAasta) 
	or  (month(kpv2) = tnKuu and year (kpv2) = tnAasta))
	AND TUNNUS = 2
loop

	If month (qryPuhkused.kpv1) = tnKuu and year (qryPuhkused.kpv1) = tnAasta then
		lnStartKpv := day (qryPuhkused.kpv1);
	Else
		lnStartKpv := 1;
	End if;
	If month (qryPuhkused.kpv2) = tnKuu and year (qryPuhkused.kpv2) = tnAasta then
		lnLoppKpv := day (qryPuhkused.kpv2);
	Else
		lnLoppKpv := day(gomonth(date(tnAasta, tnKuu,1),1) - 1);
	End if;
--	raise notice 'lnStartKpv %',lnStartKpv;
--	raise notice 'lnLoppKpv %',lnLoppKpv;
	-- arvestame tunnid
	select sum(summa) into lnTunnid from puudumine 
		WHERE lepingid = tnId 
		and ((month(kpv1) = tnKuu and year (kpv1) = tnAasta) 
		or  (month(kpv2) = tnKuu and year (kpv2) = tnAasta))
		AND TUNNUS = 2;
		
	if lnTunnid > 0 then		
--		lnTunnid = lnTunnid / 10 ^ (position('.' in lnTunnid::text) - 1);
		lResult = lResult + (lnTunnid /  qryPuhkused.toopaev);
	else
		lresult := lresult + sp_workdays(lnStartKpv, tnKuu, tnAasta, lnLoppKpv, tnid);
	end if;

--	raise notice 'lresult %',lresult;
End loop;
Return lresult;

end;
$$;

ALTER FUNCTION check_haigus(INTEGER, INTEGER, INTEGER) OWNER TO vlad;

