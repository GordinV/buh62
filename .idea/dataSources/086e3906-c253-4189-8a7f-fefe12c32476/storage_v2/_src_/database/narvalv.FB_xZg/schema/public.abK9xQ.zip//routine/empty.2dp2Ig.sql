CREATE FUNCTION empty(character varying) RETURNS boolean
    LANGUAGE plpgsql
AS
$$
begin

	if $1 is null or len(ltrim(rtrim($1))) < 1 then

		return true;

	else

		return false;

	end if;

end;

$$;

ALTER FUNCTION empty(VARCHAR) OWNER TO vlad;

