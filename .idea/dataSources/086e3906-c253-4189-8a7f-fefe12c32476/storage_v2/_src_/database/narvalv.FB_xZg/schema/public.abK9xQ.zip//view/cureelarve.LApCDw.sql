CREATE VIEW cureelarve(id, rekvid, aasta, summa, kood1, kood2, kood3, kood4, kood5, tun, nimetus, asutus, regkood,
                       parentid, tunnus, parasutus, parregkood, kuu, kpv, muud, valuuta, kuurs) AS
SELECT eelarve.id,
       eelarve.rekvid,
       eelarve.aasta,
       eelarve.summa,
       eelarve.kood1,
       eelarve.kood2,
       eelarve.kood3,
       eelarve.kood4,
       eelarve.kood5,
       eelarve.tunnus                                                            AS tun,
       rekv.nimetus,
       rekv.nimetus                                                              AS asutus,
       rekv.regkood,
       rekv.parentid,
       ifnull(tunnus.kood, space(20))                                            AS tunnus,
       ifnull(parent.nimetus, space(254))                                        AS parasutus,
       ifnull(parent.regkood, space(20))                                         AS parregkood,
       eelarve.kuu,
       eelarve.kpv,
       eelarve.muud,
       (ifnull((dokvaluuta1.valuuta)::BPCHAR, 'EEK'::BPCHAR))::CHARACTER VARYING AS valuuta,
       ifnull(dokvaluuta1.kuurs, (1)::NUMERIC)                                   AS kuurs
FROM (((((eelarve
    JOIN rekv ON ((eelarve.rekvid = rekv.id)))
    JOIN library ON ((((eelarve.kood5)::BPCHAR = library.kood) AND (library.library = 'TULUDEALLIKAD'::BPCHAR))))
    LEFT JOIN rekv parent ON ((parent.id = rekv.parentid)))
    LEFT JOIN library tunnus ON ((eelarve.tunnusid = tunnus.id)))
         LEFT JOIN dokvaluuta1 ON (((dokvaluuta1.dokid = eelarve.id) AND (dokvaluuta1.dokliik = 8))))
WHERE (library.tun5 = 1);

ALTER TABLE cureelarve
    OWNER TO vlad;

