CREATE VIEW curvastisikud(isikid, rekvid, regkood, nimetus, id, vastisikid) AS
SELECT vastisikud.isikid,
       asutus.rekvid,
       asutus.regkood,
       asutus.nimetus,
       asutus.id,
       vastisikud.id AS vastisikid
FROM (vastisikud
         JOIN asutus ON ((vastisikud.isikid = asutus.id)));

ALTER TABLE curvastisikud
    OWNER TO vlad;

