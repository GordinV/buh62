CREATE FUNCTION sk(character varying, integer, date) RETURNS numeric
    LANGUAGE plpgsql
AS
$$
DECLARE tcKontogrupp alias for $1;
	tnrekvid alias for $2;
	tdKpv alias for $3;
begin
	return -1 * sd(tckontogrupp,tnrekvid,tdKpv);
end;

$$;

ALTER FUNCTION sk(VARCHAR, INTEGER, DATE) OWNER TO vlad;

