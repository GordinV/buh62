CREATE VIEW kontodematrix(kuu, konto, rekvid) AS
SELECT curkuud.kuu,
       kontod.konto,
       kontod.rekvid
FROM (SELECT library.rekvid,
             library.kood AS konto
      FROM library
      WHERE (library.library = 'KONTOD'::BPCHAR)) kontod,
     (SELECT 1 AS kuu
      UNION ALL
      SELECT 2 AS kuu
      UNION ALL
      SELECT 3 AS kuu
      UNION ALL
      SELECT 4 AS kuu
      UNION ALL
      SELECT 5 AS kuu
      UNION ALL
      SELECT 6 AS kuu
      UNION ALL
      SELECT 7 AS kuu
      UNION ALL
      SELECT 8 AS kuu
      UNION ALL
      SELECT 9 AS kuu
      UNION ALL
      SELECT 10 AS kuu
      UNION ALL
      SELECT 11 AS kuu
      UNION ALL
      SELECT 12 AS kuu) curkuud;

ALTER TABLE kontodematrix
    OWNER TO vlad;

