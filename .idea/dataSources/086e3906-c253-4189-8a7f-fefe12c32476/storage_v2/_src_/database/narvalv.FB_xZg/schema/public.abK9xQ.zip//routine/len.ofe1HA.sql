CREATE FUNCTION len(character varying) RETURNS integer
    LANGUAGE plpgsql
AS
$$
begin
		return char_length($1);
end;
$$;

ALTER FUNCTION len(VARCHAR) OWNER TO vlad;

