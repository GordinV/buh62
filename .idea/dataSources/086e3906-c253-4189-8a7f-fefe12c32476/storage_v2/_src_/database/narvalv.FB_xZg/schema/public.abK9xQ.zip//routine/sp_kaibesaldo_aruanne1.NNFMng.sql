CREATE FUNCTION sp_kaibesaldo_aruanne1(integer, date, date, integer, character varying, character varying) RETURNS character varying
    LANGUAGE plpgsql
AS
$$
DECLARE 
	tnrekvid alias for $1;
	tdKpv1 alias for $2;
	tdKpv2 alias for $3;
	tnLiik alias for $4;
	tcAsutus alias for $5;
	tcNumber alias for $6;


	lcReturn varchar;
	lcString varchar;

	LNcOUNT int;
	lnSumma numeric(12,4);
	v_arved record;
	lcKonto varchar(20);
	lnId int;
	lnJaakDb numeric(12,2);
	lnJaakKr numeric(12,2);

begin

	

	select count(*) into lnCount from pg_stat_all_tables where UPPER(relname) = 'TMP_KAIBESALDO_ARUANNE1';



	if ifnull(lnCount,0) < 1 then



	raise notice ' lisamine  ';

	

		create table tmp_kaibesaldo_aruanne1 ( id int, konto varchar(20), regkood varchar(20), asutus varchar(254),
			number varchar(20), arvkpv date, 
			algdb numeric(12,2), algkr numeric(12,2), db numeric(12,2), kr numeric(12,2),loppdb numeric(12,2), loppkr numeric(12,2), 
			timestamp varchar(20), kpv date default date(), rekvid int )  ;

		

		GRANT ALL ON TABLE tmp_kaibesaldo_aruanne1 TO GROUP public;



	else
		delete from tmp_kaibesaldo_aruanne1 where kpv < date() and rekvid = tnrekvId;

	end if;


	lcreturn := to_char(now(), 'YYYYMMDDMISSSS');


	-- algsaldo 

	for v_arved in 

	select arv.id, arv.number, arv.kpv, arv.summa, arv.doklausid,arv.tasud,
		asutus.regkood, asutus.nimetus as asutus
		from arv inner join asutus on arv.asutusid = asutus.id
		where arv.rekvid = tnrekvId
		and arv.kpv < tdKpv1
		and arv.liik = tnLiik
		and upper(asutus.nimetus) like upper(tcAsutus)
		and upper(arv.number) like upper(tcNumber)

		order by arv.asutusid

	loop
		
		--arvete inf 

		lcKonto = space(1);

		if v_arved.doklausid > 0 then
			select konto into lcKonto from dokprop where id = v_arved.doklausid;
			lcKonto = ifnull(lcKonto,space(1));
		end if;		

		-- tasuinf

		lnSumma = 0;
		if not empty (v_arved.tasud) then
			-- meil on tasud
			select sum(summa) into lnSumma from arvtasu where arvid = v_arved.id and arvtasu.kpv < tdKpv1;
			lnSumma = ifnull(lnSumma,0);
		end if;

		lnJaakDb = v_arved.summa - lnSumma;
		if lnJaakDb >= 0 then
			lnJaakKr = 0;
		else
			lnJaakDb = 0;
			lnJaakKr = lnSumma -v_arved.summa; 
		end if;
		if lnJaakDb <> 0 or lnJaakKr <> 0 then 
			insert into tmp_kaibesaldo_aruanne1 (id, konto, regkood, asutus ,number , arvkpv,algdb, algkr,db, kr,loppdb, loppkr, timestamp , rekvid )
				values (v_arved.id, lcKonto, v_arved.regkood, v_arved.asutus, v_arved.number, v_arved.kpv, 
				lnJaakDb, lnJaakKr,0,0,lnJaakDb, lnJaakKr, lcreturn, tnrekvid);  
		end if;
	end loop;

	-- kaibed 

	for v_arved in 

	select arv.id, arv.number, arv.kpv, arv.summa, arv.doklausid,arv.tasud,
		asutus.regkood, asutus.nimetus as asutus
		from arv inner join asutus on arv.asutusid = asutus.id
		where arv.rekvid = tnrekvId
		and arv.kpv >= tdKpv1
		and arv.kpv <= tdKpv2
		and arv.liik = tnLiik
		and upper(asutus.nimetus) like upper(tcAsutus)
		and upper(arv.number) like upper(tcNumber)

	loop
		-- otsime olevad kirjad

		select id, algdb, algkr into lnId,lnJaakDb, lnJaakKr  from tmp_kaibesaldo_aruanne1 where id = v_arved.id and timestamp = lcreturn;
		lnId = ifnull(lnId,0);

		if lnId = 0 then
			-- uut arve
			lcKonto = space(1);

			if v_arved.doklausid > 0 then
				select konto into lcKonto from dokprop where id = v_arved.doklausid;
				lcKonto = ifnull(lcKonto,space(1));
			end if;	
		end if;

		-- tasuinf

		lnSumma = 0;
		if not empty (v_arved.tasud) then
			-- meil on tasud
			select sum(summa) into lnSumma from arvtasu 
				where arvid = v_arved.id 
				and arvtasu.kpv >= tdKpv1 
				and arvtasu.kpv <= tdKpv2;
			lnSumma = ifnull(lnSumma,0);
		end if;

		if lnId = 0 then
			lnJaakDb = v_arved.summa - lnSumma;
			if lnJaakDb >= 0 then
				lnJaakKr = 0;
			else
				lnJaakDb = 0;
				lnJaakKr = lnSumma -v_arved.summa; 
			end if;
			insert into tmp_kaibesaldo_aruanne1 ( id, konto, regkood, asutus , number , arvkpv,algdb, algkr, db, kr,LoppDb, loppKr, timestamp , rekvid )
				values (v_arved.id, lcKonto, v_arved.regkood, v_arved.asutus, v_arved.number, v_arved.kpv,0,0, lnjaakdb, lnJaakKr, v_arved.summa, lnSumma, lcreturn, tnrekvid);  
		else
			lnJaakDb = (lnJaakDb-lnJaakKr) + v_arved.summa - lnSumma;
			if lnJaakDb >= 0 then
				lnJaakKr = 0;
			else
				lnJaakDb = 0;
				lnJaakKr = -1 * lnJaakdb ; 
			end if;


			update tmp_kaibesaldo_aruanne1 set 
				db = v_arved.summa,
				kr = lnSumma,
				loppDb = lnJaakDb,
				loppKr = lnJaakKr
				where id = v_arved.id and timestamp = lcreturn;
		end if;

	end loop;

	return LCRETURN;

end;

$$;

ALTER FUNCTION sp_kaibesaldo_aruanne1(INTEGER, DATE, DATE, INTEGER, VARCHAR, VARCHAR) OWNER TO vlad;

