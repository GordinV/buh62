CREATE FUNCTION sp_saada_luba_arhiivisse(integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 
	tnRekvId alias for $1;
	v_luba record;
	lnresult int;
	lnDeklId int;
begin

	lnresult = 0;
	for v_luba in 
		select luba.id from luba 
			where luba.rekvId = tnRekvId 
			and luba.staatus > 0
			and luba.loppkpv < date()
			and id in (select distinct lubaid from toiming where tyyp = 'PIKENDAMA' 
			and tahtaeg < date() and staatus > 0)
	loop
		raise notice 'v_luba.id %',v_luba.id;
		lnDeklId =  sp_luba_annuleri(v_luba.id);
		if ifnull(lnDeklId,0) > 0 then
			lnresult = lnresult + 1;
		end if;
	end loop;

	Return lnresult;

end;

$$;

ALTER FUNCTION sp_saada_luba_arhiivisse(INTEGER) OWNER TO vlad;

