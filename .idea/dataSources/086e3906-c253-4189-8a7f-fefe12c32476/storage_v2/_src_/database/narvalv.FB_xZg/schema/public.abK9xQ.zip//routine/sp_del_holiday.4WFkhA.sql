CREATE FUNCTION sp_del_holiday(integer, integer) RETURNS smallint
    LANGUAGE plpgsql
AS
$$
declare 	

	tnId alias for $1;

	lnError int2;

begin

	DELETE FROM holidays WHERE id = tnId;


	if found then

		return 1;

	else


		return 0;


	end if;


end;

$$;

ALTER FUNCTION sp_del_holiday(INTEGER, INTEGER) OWNER TO vlad;

