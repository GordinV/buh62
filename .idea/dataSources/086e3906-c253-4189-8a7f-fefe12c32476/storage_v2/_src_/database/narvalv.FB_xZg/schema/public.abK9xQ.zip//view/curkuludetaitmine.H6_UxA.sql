CREATE VIEW curkuludetaitmine(kuu, aasta, rekvid, summa, kood, eelarve, tegev, tun, kood2) AS
SELECT month(journal.kpv)                                              AS kuu,
       year(journal.kpv)                                               AS aasta,
       journal.rekvid,
       sum((journal1.summa * ifnull(dokvaluuta1.kuurs, (1)::NUMERIC))) AS summa,
       journal1.kood5                                                  AS kood,
       space(1)                                                        AS eelarve,
       journal1.kood1                                                  AS tegev,
       journal1.tunnus                                                 AS tun,
       journal1.kood2
FROM (((journal
    JOIN journal1 ON ((journal.id = journal1.parentid)))
    LEFT JOIN dokvaluuta1 ON (((dokvaluuta1.dokid = journal1.id) AND (dokvaluuta1.dokliik = 1))))
         JOIN faktkulud ON ((ltrim(rtrim((journal1.deebet)::TEXT)) ~~ ltrim(rtrim((faktkulud.kood)::TEXT)))))
GROUP BY (year(journal.kpv)), (month(journal.kpv)), journal.rekvid, journal1.deebet, journal1.kood1, journal1.tunnus,
         journal1.kood5, journal1.kood2
ORDER BY (year(journal.kpv)), (month(journal.kpv)), journal.rekvid, journal1.deebet, journal1.kood1, journal1.tunnus,
         journal1.kood5, journal1.kood2;

ALTER TABLE curkuludetaitmine
    OWNER TO vlad;

